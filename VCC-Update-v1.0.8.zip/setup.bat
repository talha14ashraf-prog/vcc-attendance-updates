@echo off
title VCC Attendance System — First Time Setup
color 0E
cd /d "%~dp0"

echo ============================================
echo   VCC Attendance System - First Time Setup
echo ============================================
echo.

:: Check Node.js is installed
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed on this PC.
    echo Please install it first from https://nodejs.org
    echo Then run this setup.bat again.
    echo.
    pause
    exit /b 1
)

echo [OK] Node.js found:
node -v
echo.

:: Check .env exists
if not exist ".env" (
    echo [WARNING] No .env file found in this folder.
    echo.
    echo You must create a .env file before the system will work.
    echo See SETUP.md for the full list of values needed
    echo ^(TURSO_URL, TURSO_TOKEN, PUPPETEER_EXECUTABLE_PATH, etc.^)
    echo.
    echo Copy the .env file from an already-working PC, or create
    echo a new one now, then run this setup.bat again.
    echo.
    pause
    exit /b 1
)

echo [OK] .env file found.
echo.

:: If a brand-new PC previously timed out during its first cloud download,
:: make sure the next launch resumes the longer bootstrap retry flow instead
:: of mistaking the partial replica for a completed offline database.
if exist "local-replica.db" if not exist "local-replica.bootstrap-complete" (
    >"local-replica.bootstrap-pending" echo retry
)

:: Install dependencies. VCC uses the Chrome/Edge already installed on
:: this PC; downloading Puppeteer's separate 150+ MB browser is unnecessary
:: and can fail when its cache contains an incomplete download.
set "PUPPETEER_SKIP_DOWNLOAD=true"
echo Installing dependencies... this may take a few minutes.
echo.
call npm ci --no-audit --no-fund

if %errorlevel% neq 0 (
    echo.
    echo [ERROR] npm install failed. Check the messages above.
    echo.
    pause
    exit /b 1
)

echo.
echo ============================================
echo   Setup complete!
echo ============================================
echo.
echo Next steps:
echo   1. Double-click start.bat to launch the system
echo   2. Open http://localhost:3000 in your browser
echo   3. Click "Connect" and scan the WhatsApp QR code
echo.
pause
