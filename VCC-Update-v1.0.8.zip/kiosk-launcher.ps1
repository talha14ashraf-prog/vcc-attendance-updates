param([switch]$InstallShortcut, [switch]$CheckOnly)
$ErrorActionPreference = 'Stop'
$appRoot = $PSScriptRoot
$kioskUrl = 'http://localhost:3000/kiosk?theme=light'
function Show-Notice([string]$message) {
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show($message,'VCC Kiosk','OK','Information') | Out-Null
}
try {
    $browserPaths = @(
        (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
        (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe'),
        (Join-Path ${env:ProgramFiles(x86)} 'Microsoft\Edge\Application\msedge.exe'),
        (Join-Path $env:ProgramFiles 'Microsoft\Edge\Application\msedge.exe')
    )
    $browserPath = $browserPaths | Where-Object { Test-Path -LiteralPath $_ -PathType Leaf } | Select-Object -First 1
    if (-not $browserPath) { throw 'Install Google Chrome or Microsoft Edge first.' }
    $nodePath = (Get-Command node.exe -ErrorAction Stop).Source
    foreach ($required in @('.env','backend\server.js','node_modules')) {
        if (-not (Test-Path -LiteralPath (Join-Path $appRoot $required))) { throw 'Installation is incomplete. Run setup.bat and check the .env file first.' }
    }
    if ($InstallShortcut) {
        $shell = New-Object -ComObject WScript.Shell
        $desktopPath = [Environment]::GetFolderPath('Desktop')
        $shortcut = $shell.CreateShortcut((Join-Path $desktopPath 'VCC Kiosk.lnk'))
        $shortcut.TargetPath = (Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe')
        $shortcut.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $appRoot 'kiosk-launcher.ps1') + '"'
        $shortcut.WorkingDirectory = $appRoot
        $shortcut.IconLocation = $browserPath + ',0'
        $shortcut.Description = 'Start VCC server and open the entrance kiosk'
        $shortcut.Save()
        Write-Output 'VCC Kiosk shortcut created on your desktop.'
        return
    }
    if ($CheckOnly) { Write-Output 'Kiosk launcher prerequisites OK. No server or browser started.'; return }
    $launchMutex = New-Object System.Threading.Mutex($false,'Local\VCC_Kiosk_Launcher')
    if (-not $launchMutex.WaitOne(0)) { return }
    try {
        function Test-KioskReady {
            try {
                $response=Invoke-WebRequest -UseBasicParsing -Uri $kioskUrl -TimeoutSec 2
                return ($response.StatusCode -eq 200 -and $response.Content -match 'id="kiosk-lock-button"')
            } catch { return $false }
        }
        $serverProcess=$null
        if (-not (Test-KioskReady)) {
            $listeners=Get-NetTCPConnection -LocalPort 3000 -State Listen -ErrorAction SilentlyContinue
            if ($listeners) { throw 'Port 3000 is occupied but VCC Kiosk is not ready. Check the running VCC server; do not start a second server.' }
            # Keep the actual server terminal visible for live logs and errors.
            # start.bat also pauses on failure, so diagnostic output stays readable.
            $startCommand='""'+(Join-Path $appRoot 'start.bat')+'""'
            $serverProcess=Start-Process -FilePath $env:ComSpec -ArgumentList @('/c',$startCommand) -WorkingDirectory $appRoot -WindowStyle Normal -PassThru
        }
        $ready=Test-KioskReady
        $deadline=(Get-Date).AddSeconds(120)
        while (-not $ready -and (Get-Date) -lt $deadline) {
            if ($serverProcess -and $serverProcess.HasExited) { throw 'VCC server could not start. Open start.bat and check its terminal error.' }
            Start-Sleep -Milliseconds 750
            $ready=Test-KioskReady
        }
        if (-not $ready) { throw 'Server startup is taking longer than expected. Check the visible VCC terminal. Do not delete database files.' }
        # Reuse an existing kiosk window instead of opening duplicates.
        $profilePath=Join-Path $appRoot 'kiosk-browser-profile'
        $existing=Get-CimInstance Win32_Process -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '^(chrome|msedge)\.exe$' -and $_.CommandLine -like ('*'+$profilePath+'*') -and $_.CommandLine -notmatch '--type=' } | Select-Object -First 1
        if ($existing) {
            $shell=New-Object -ComObject WScript.Shell
            if ($shell.AppActivate([int]$existing.ProcessId)) { return }
        }
        $browserArgs=@(('--user-data-dir="'+$profilePath+'"'),'--no-first-run','--no-default-browser-check','--start-maximized',('--app='+$kioskUrl))
        Start-Process -FilePath $browserPath -ArgumentList $browserArgs -WindowStyle Normal
    } finally { $launchMutex.ReleaseMutex(); $launchMutex.Dispose() }
} catch {
    if ($CheckOnly -or $InstallShortcut) { Write-Error $_.Exception.Message; exit 1 }
    Show-Notice $_.Exception.Message
    exit 1
}
