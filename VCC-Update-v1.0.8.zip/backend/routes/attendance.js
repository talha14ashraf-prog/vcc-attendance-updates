const express = require('express');
const router = express.Router();
const { query, run, batchRun, todayPKT } = require('../database');
const { smartSend } = require('../whatsapp');

// Lazy-load db object for smartSend
function getDb() { return require('../database'); }

function formatTime(date) {
  return date.toLocaleTimeString('en-PK', { timeZone:'Asia/Karachi', hour: '2-digit', minute: '2-digit', hour12: true });
}

function formatDate(date) {
  return date.toLocaleDateString('en-PK', { timeZone:'Asia/Karachi', day: '2-digit', month: 'long', year: 'numeric' });
}

function buildMessage(template, student, contact, now = new Date()) {
  return (template || '')
    .replace(/{name}/g, student.name)
    .replace(/{time}/g, formatTime(now))
    .replace(/{date}/g, formatDate(now))
    .replace(/{contact}/g, contact)
    .replace(/{class}/g, student.class)
    .replace(/{section}/g, student.section || '');
}

// Scan QR/barcode or RFID card - mark attendance
// `uid` may be the student's own barcode UID (VCC-xxxxxxxx) OR a linked RFID
// card UID — both resolve to the same student and mark the same attendance.
router.post('/scan', async (req, res) => {
  try {
    const { uid, request_id, tapped_at } = req.body;
    const scanDb = require('../database');
    scanDb.noteScanActivity?.();
    const receipts = require('../scan-receipts');
    if (request_id && !receipts.validId(request_id)) return res.status(400).json({success:false,error:'Invalid scan request ID'});
    const reply = async data => res.json(await receipts.remember(scanDb,request_id,uid,data));
    const previous = await receipts.read(scanDb,request_id,uid);
    if (previous) return await reply(previous);
    let tap;
    try { tap = require('../scan-time').resolve(tapped_at); }
    catch(error) { return res.status(400).json({success:false,review_required:true,error:error.message}); }
    if (!uid) return res.status(400).json({ success: false, error: 'No UID provided' });

    const students = await query('SELECT * FROM students WHERE student_uid = ? OR rfid_uid = ?', [uid, uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const student = students[0];
    // From here on, always use the student's own student_uid — attendance and
    // whatsapp_log are keyed on student_uid regardless of which card was scanned.
    const uidForRecords = student.student_uid;

    // ── FROZEN / DEFAULTER CHECK ─────────────────────────────────────────────
    if (student.is_frozen === 1 || student.is_frozen === '1') {
      return await reply({
        success: false,
        frozen: true,
        student: student.name,
        class: student.class,
        gr_number: student.gr_number || '',
        freeze_reason: student.freeze_reason || '',
        error: `DEFAULTER — Please submit fees. ${student.name}'s attendance cannot be marked.`
      });
    }

    const today = tap.day;
    const todayRecords = await query(
      'SELECT * FROM attendance WHERE student_uid = ? AND date(timestamp) = ? ORDER BY timestamp DESC LIMIT 1',
      [uidForRecords, today]
    );

    // 2-minute cooldown
    if (todayRecords.length) {
      const lastTs = new Date(todayRecords[0].timestamp.replace(' ', 'T') + '+05:00');
      const diffMs = tap.date.getTime() - lastTs.getTime();
      if (diffMs < 2 * 60 * 1000) {
        const secsLeft = Math.ceil((2 * 60) - (diffMs / 1000));
        const minsLeft = Math.floor(secsLeft / 60);
        const sLeft = secsLeft % 60;
        return await reply({
          success: false,
          duplicate: true,
          student: student.name,
          class: student.class,
          lastType: todayRecords[0].type,
          cooldown: true,
          secsLeft: secsLeft,
          error: 'Already scanned (' + todayRecords[0].type + '). Wait ' + minsLeft + 'm ' + sLeft + 's before scanning again.'
        });
      }
    }

    // If last record today is OUT — block further scans
    if (todayRecords.length && todayRecords[0].type === 'OUT') {
      return await reply({
        success: false,
        duplicate: true,
        student: student.name,
        class: student.class,
        lastType: 'OUT',
        error: 'Attendance already marked. OUT already recorded for today.'
      });
    }

    let type = 'IN';
    if (todayRecords.length && todayRecords[0].type === 'IN') type = 'OUT';

    const pktNow = tap.timestamp;
    const scanResult = {
      success:true,student:student.name,class:student.class,type,whatsapp_sent:null,
      student_uid:student.student_uid,student_photo:student.student_photo || null,via_rfid:uid===student.rfid_uid,timestamp:pktNow
    };
    const saved = await receipts.save(scanDb,request_id,uid,scanResult,pktNow);
    if (saved.replayed) return await reply(saved.result);

    const settings = await query('SELECT * FROM settings');
    const settingsMap = {};
    settings.forEach(s => settingsMap[s.key] = s.value);

    const viaSms = settingsMap.attendance_channel === 'sms';
    const template = viaSms
      ? (type === 'IN' ? settingsMap.sms_in_message : settingsMap.sms_out_message)
      : (type === 'IN' ? settingsMap.in_message : settingsMap.out_message);
    const message = buildMessage(template, student, settingsMap['contact'], tap.date);

    // ── Respond IMMEDIATELY — don't wait for WhatsApp ──────────────────────
    await reply({
      success: true, student: student.name, class: student.class, type, message, whatsapp_sent: null,
      student_uid: student.student_uid, student_photo: student.student_photo || null,
      via_rfid: uid === student.rfid_uid, timestamp:pktNow
    });

    // ── Send WhatsApp in background (after response already sent) ────────
    if (!require('../sender-role').enabled()) return;
    if (viaSms) {
      require('../sms').enqueue(student, message, type).catch(e => console.warn('[SMS]', e.message));
      return;
    }
    require('../whatsapp').smartSendWhatsApp(student, message, getDb()).then(result => {
      const retryUntil = (result.sent || result.queued) ? null : new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
      run('INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [student.name, student.class, result.phone, message, type, result.queued ? 'queued' : result.sent ? 'sent' : 'failed', retryUntil, result.msgId || null, result.usedFallback ? 1 : 0, student.student_uid || null, result.sent ? null : result.reason]
      ).catch(() => {});
    }).catch(() => {});
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get today's attendance
router.get('/today', async (req, res) => {
  try {
    const today = todayPKT();
    const records = await query(
      'SELECT a.*, s.name, s.class, s.parent_phone FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) = ? ORDER BY a.timestamp DESC',
      [today]
    );
    res.json({ success: true, records });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get attendance by date
router.get('/date/:date', async (req, res) => {
  try {
    const records = await query(
      'SELECT a.*, s.name, s.class FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) = ? ORDER BY a.timestamp DESC',
      [req.params.date]
    );
    res.json({ success: true, records });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get student attendance history
router.get('/student/:uid', async (req, res) => {
  try {
    const records = await query(
      'SELECT * FROM attendance WHERE student_uid = ? ORDER BY timestamp DESC LIMIT 30',
      [req.params.uid]
    );
    res.json({ success: true, records });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get all unique classes
router.get('/classes', async (req, res) => {
  try {
    const classes = await query('SELECT DISTINCT class FROM students ORDER BY class');
    res.json({ success: true, classes: classes.map(c => c.class) });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Attendance Entries workspace — filtered student register with one row per
// student and the selected day's first IN / last OUT values.
router.get('/entries', async (req, res) => {
  try {
    const date = String(req.query.date || todayPKT()).trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'A valid date is required' });
    }

    const cls = String(req.query.class || '').trim();
    const section = String(req.query.section || '').trim();
    const group = String(req.query.group || '').trim();
    const gr = String(req.query.gr || '').trim();
    const name = String(req.query.name || '').trim().toLowerCase();

    let where = "WHERE (s.status IS NULL OR s.status != 'inactive')";
    const params = [date];
    if (cls) { where += ' AND s.class = ?'; params.push(cls); }
    if (section) { where += ' AND s.section = ?'; params.push(section); }
    if (group) { where += ' AND s.group_name = ?'; params.push(group); }
    if (gr) { where += ' AND s.gr_number LIKE ?'; params.push('%' + gr + '%'); }
    if (name) { where += ' AND LOWER(s.name) LIKE ?'; params.push('%' + name + '%'); }

    const students = await query(
      `SELECT s.student_uid, s.gr_number, s.name, s.father_name,
              s.class, s.section, s.group_name,
              MIN(CASE WHEN a.type = 'IN' THEN time(a.timestamp) END) AS in_time,
              MAX(CASE WHEN a.type = 'OUT' THEN time(a.timestamp) END) AS out_time,
              MAX(CASE WHEN a.type = 'IN' THEN 1 ELSE 0 END) AS is_present,
              MAX(es.state) AS saved_state
       FROM students s
       LEFT JOIN attendance a
         ON a.student_uid = s.student_uid AND date(a.timestamp) = ?
       LEFT JOIN attendance_entry_states es
         ON es.student_uid = s.student_uid AND es.attendance_date = ?
       ${where}
       GROUP BY s.student_uid, s.gr_number, s.name, s.father_name,
                s.class, s.section, s.group_name
       ORDER BY s.class, s.section, CAST(s.gr_number AS INTEGER), s.name
       LIMIT 1000`,
      [date, ...params]
    );

    const filterRows = await query(
      `SELECT DISTINCT class, section, group_name
       FROM students
       WHERE status IS NULL OR status != 'inactive'
       ORDER BY class, section, group_name`
    );

    res.json({
      success: true,
      date,
      students: students.map(s => ({
        ...s,
        // Only an IN scan or an explicitly saved Present state counts as P.
        // Students with no attendance for this date start as Absent.
        state: Number(s.is_present) || s.saved_state === 'P' ? 'P' : 'A',
        state_saved: Boolean(Number(s.is_present) || s.saved_state),
        in_time: s.in_time ? String(s.in_time).slice(0, 5) : '',
        out_time: s.out_time ? String(s.out_time).slice(0, 5) : '',
      })),
      filters: {
        classes: [...new Set(filterRows.map(r => r.class).filter(Boolean))],
        sections: [...new Set(filterRows.map(r => r.section).filter(Boolean))],
        groups: [...new Set(filterRows.map(r => r.group_name).filter(Boolean))],
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Date-wise attendance rows used by the Attendance Report detail view.
router.get('/report-detail', async (req, res) => {
  try {
    const from = String(req.query.from || '').trim();
    const to = String(req.query.to || '').trim();
    if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) {
      return res.status(400).json({ success: false, error: 'A valid date range is required' });
    }

    const start = new Date(from + 'T00:00:00Z');
    const end = new Date(to + 'T00:00:00Z');
    const dayCount = Math.floor((end - start) / 86400000) + 1;
    if (dayCount > 366) {
      return res.status(400).json({ success: false, error: 'Detail Report date range cannot exceed 366 days' });
    }

    const cls = String(req.query.class || '').trim();
    const section = String(req.query.section || '').trim();
    const searchType = req.query.search_type === 'name' ? 'name' : 'gr';
    const search = String(req.query.search || '').trim().toLowerCase();
    const status = ['P', 'A'].includes(String(req.query.status || '').toUpperCase())
      ? String(req.query.status).toUpperCase() : '';

    let studentWhere = "WHERE (s.status IS NULL OR s.status = '' OR s.status = 'active')";
    const studentParams = [];
    if (cls) { studentWhere += ' AND s.class = ?'; studentParams.push(cls); }
    if (section) { studentWhere += ' AND s.section = ?'; studentParams.push(section); }
    if (search) {
      studentWhere += searchType === 'name' ? ' AND LOWER(s.name) LIKE ?' : ' AND LOWER(s.gr_number) LIKE ?';
      studentParams.push('%' + search + '%');
    }

    const students = await query(
      `SELECT s.student_uid, s.gr_number, s.name, s.father_name,
              s.class, s.section, s.group_name
       FROM students s ${studentWhere}
       ORDER BY s.class, s.section, CAST(s.gr_number AS INTEGER), s.name
       LIMIT 1000`,
      studentParams
    );

    if (!students.length) {
      return res.json({ success: true, rows: [], totals: { records: 0, present: 0, absent: 0, unmarked: 0 } });
    }

    const attendance = await query(
      `SELECT a.student_uid, date(a.timestamp) AS attendance_date, a.type,
              time(a.timestamp) AS attendance_time, COALESCE(a.manual_no_time, 0) AS manual_no_time
       FROM attendance a
       JOIN students s ON s.student_uid = a.student_uid
       ${studentWhere} AND date(a.timestamp) BETWEEN ? AND ? AND a.type IN ('IN', 'OUT')
       ORDER BY a.timestamp`,
      [...studentParams, from, to]
    );
    const savedStates = await query(
      `SELECT es.student_uid, es.attendance_date, es.state
       FROM attendance_entry_states es
       JOIN students s ON s.student_uid = es.student_uid
       ${studentWhere} AND es.attendance_date BETWEEN ? AND ?`,
      [...studentParams, from, to]
    );

    const studentByUid = new Map(students.map(student => [student.student_uid, student]));
    const scopeDayKey = (student, date) => [date, student?.class || '', student?.section || ''].join('|');
    const activeScopeDays = new Set();
    const attendanceByDay = new Map();
    for (const item of attendance) {
      const key = item.student_uid + '|' + item.attendance_date;
      activeScopeDays.add(scopeDayKey(studentByUid.get(item.student_uid), item.attendance_date));
      const current = attendanceByDay.get(key) || { present: false, in_time: '', out_time: '' };
      const time = item.manual_no_time ? '' : String(item.attendance_time || '').slice(0, 5);
      if (item.type === 'IN') {
        current.present = true;
        if (time && (!current.in_time || time < current.in_time)) current.in_time = time;
      } else if (item.type === 'OUT' && time && (!current.out_time || time > current.out_time)) {
        current.out_time = time;
      }
      attendanceByDay.set(key, current);
    }
    const stateByDay = new Map();
    for (const item of savedStates) {
      stateByDay.set(item.student_uid + '|' + item.attendance_date, item.state === 'P' ? 'P' : 'A');
      activeScopeDays.add(scopeDayKey(studentByUid.get(item.student_uid), item.attendance_date));
    }

    const dates = [];
    for (let date = new Date(start); date <= end; date.setUTCDate(date.getUTCDate() + 1)) {
      dates.push(date.toISOString().slice(0, 10));
    }

    const rows = [];
    let sourceIndex = 0;
    for (const student of students) {
      for (const date of dates) {
        const key = student.student_uid + '|' + date;
        const times = attendanceByDay.get(key) || { present: false, in_time: '', out_time: '' };
        const savedState = stateByDay.get(key);
        const state = times.present || savedState === 'P'
          ? 'P'
          : savedState === 'A'
            ? 'A'
            : activeScopeDays.has(scopeDayKey(student, date)) ? 'A' : '-';
        if (status && state !== status) continue;
        rows.push({
          source_index: sourceIndex++,
          date,
          gr_number: student.gr_number || '',
          name: student.name || '',
          father_name: student.father_name || '',
          class: student.class || '',
          section: student.section || '',
          group_name: student.group_name || '',
          state,
          in_time: times.in_time,
          out_time: times.out_time,
        });
      }
    }

    const present = rows.filter(row => row.state === 'P').length;
    const absent = rows.filter(row => row.state === 'A').length;
    res.json({
      success: true,
      rows,
      totals: { records: rows.length, present, absent, unmarked: rows.length - present - absent },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// One-row-per-student monthly attendance matrix (days 1-31 + totals).
router.get('/report-monthly', async (req, res) => {
  try {
    const month = String(req.query.month || '').trim();
    if (!/^\d{4}-\d{2}$/.test(month)) {
      return res.status(400).json({ success: false, error: 'A valid month is required' });
    }
    const [year, monthNumber] = month.split('-').map(Number);
    const daysInMonth = new Date(Date.UTC(year, monthNumber, 0)).getUTCDate();
    const from = month + '-01';
    const to = month + '-' + String(daysInMonth).padStart(2, '0');
    const cls = String(req.query.class || '').trim();
    const section = String(req.query.section || '').trim();
    const searchType = req.query.search_type === 'name' ? 'name' : 'gr';
    const search = String(req.query.search || '').trim().toLowerCase();

    let studentWhere = "WHERE (s.status IS NULL OR s.status = '' OR s.status = 'active')";
    const studentParams = [];
    if (cls) { studentWhere += ' AND s.class = ?'; studentParams.push(cls); }
    if (section) { studentWhere += ' AND s.section = ?'; studentParams.push(section); }
    if (search) {
      studentWhere += searchType === 'name' ? ' AND LOWER(s.name) LIKE ?' : ' AND LOWER(s.gr_number) LIKE ?';
      studentParams.push('%' + search + '%');
    }

    const students = await query(
      `SELECT s.student_uid, s.gr_number, s.name, s.father_name,
              s.class, s.section, s.group_name
       FROM students s ${studentWhere}
       ORDER BY s.class, s.section, CAST(s.gr_number AS INTEGER), s.name
       LIMIT 1000`,
      studentParams
    );
    if (!students.length) {
      return res.json({ success: true, month, days_in_month: daysInMonth, rows: [] });
    }

    const attendance = await query(
      `SELECT a.student_uid, date(a.timestamp) AS attendance_date, a.type
       FROM attendance a
       JOIN students s ON s.student_uid = a.student_uid
       ${studentWhere} AND date(a.timestamp) BETWEEN ? AND ? AND a.type IN ('IN', 'OUT')`,
      [...studentParams, from, to]
    );
    const savedStates = await query(
      `SELECT es.student_uid, es.attendance_date, es.state
       FROM attendance_entry_states es
       JOIN students s ON s.student_uid = es.student_uid
       ${studentWhere} AND es.attendance_date BETWEEN ? AND ?`,
      [...studentParams, from, to]
    );

    const studentByUid = new Map(students.map(student => [student.student_uid, student]));
    const scopeDayKey = (student, date) => [date, student?.class || '', student?.section || ''].join('|');
    const activeScopeDays = new Set();
    const presentByDay = new Set();
    for (const item of attendance) {
      activeScopeDays.add(scopeDayKey(studentByUid.get(item.student_uid), item.attendance_date));
      if (item.type === 'IN') presentByDay.add(item.student_uid + '|' + item.attendance_date);
    }
    const stateByDay = new Map();
    for (const item of savedStates) {
      stateByDay.set(item.student_uid + '|' + item.attendance_date, item.state === 'P' ? 'P' : 'A');
      activeScopeDays.add(scopeDayKey(studentByUid.get(item.student_uid), item.attendance_date));
    }

    const rows = students.map((student, sourceIndex) => {
      const days = {};
      let present = 0;
      let absent = 0;
      for (let day = 1; day <= daysInMonth; day++) {
        const date = month + '-' + String(day).padStart(2, '0');
        const key = student.student_uid + '|' + date;
        const savedState = stateByDay.get(key);
        const state = presentByDay.has(key) || savedState === 'P'
          ? 'P'
          : savedState === 'A'
            ? 'A'
            : activeScopeDays.has(scopeDayKey(student, date)) ? 'A' : '-';
        days[day] = state;
        if (state === 'P') present++;
        if (state === 'A') absent++;
      }
      return {
        source_index: sourceIndex,
        gr_number: student.gr_number || '',
        name: student.name || '',
        father_name: student.father_name || '',
        class: student.class || '',
        section: student.section || '',
        group_name: student.group_name || '',
        days,
        present,
        absent,
      };
    });

    res.json({ success: true, month, days_in_month: daysInMonth, rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Save changed attendance rows as one transaction. Existing records for each
// submitted student/date are normalized to at most one IN and one OUT record.
router.post('/entries/bulk', async (req, res) => {
  try {
    const date = String(req.body.date || '').trim();
    const entries = Array.isArray(req.body.entries) ? req.body.entries : [];
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'A valid date is required' });
    }
    if (!entries.length) {
      return res.status(400).json({ success: false, error: 'No attendance changes selected' });
    }
    if (entries.length > 1000) {
      return res.status(400).json({ success: false, error: 'Too many rows in one update' });
    }

    const timeOk = value => !value || /^([01]\d|2[0-3]):[0-5]\d$/.test(value);
    const clean = [];
    const seen = new Set();
    for (const raw of entries) {
      const student_uid = String(raw.student_uid || '').trim();
      const state = String(raw.state || '').trim().toUpperCase();
      const in_time = String(raw.in_time || '').trim();
      const out_time = String(raw.out_time || '').trim();
      if (!student_uid || seen.has(student_uid)) continue;
      if (!['P', 'A'].includes(state)) {
        return res.status(400).json({ success: false, error: 'State must be P or A' });
      }
      if (!timeOk(in_time) || !timeOk(out_time)) {
        return res.status(400).json({ success: false, error: 'Time must use HH:MM format' });
      }
      seen.add(student_uid);
      clean.push({ student_uid, state, in_time, out_time });
    }
    if (!clean.length) {
      return res.status(400).json({ success: false, error: 'No valid attendance rows received' });
    }

    const placeholders = clean.map(() => '?').join(',');
    const validStudents = await query(
      `SELECT student_uid FROM students WHERE student_uid IN (${placeholders})`,
      clean.map(e => e.student_uid)
    );
    const validSet = new Set(validStudents.map(s => s.student_uid));
    const statements = [];

    for (const entry of clean) {
      if (!validSet.has(entry.student_uid)) continue;
      statements.push({
        sql: 'DELETE FROM attendance WHERE student_uid = ? AND date(timestamp) = ?',
        args: [entry.student_uid, date],
      });
      statements.push({
        sql: `INSERT INTO attendance_entry_states (student_uid, attendance_date, state, updated_at)
              VALUES (?, ?, ?, CURRENT_TIMESTAMP)
              ON CONFLICT(student_uid, attendance_date) DO UPDATE SET
                state = excluded.state, updated_at = CURRENT_TIMESTAMP`,
        args: [entry.student_uid, date, entry.state],
      });
      if (entry.state === 'P') {
        const hasInTime = !!entry.in_time;
        statements.push({
          sql: 'INSERT INTO attendance (student_uid, type, timestamp, manual_no_time) VALUES (?, ?, ?, ?)',
          args: [entry.student_uid, 'IN', `${date} ${entry.in_time || '00:00'}:00`, hasInTime ? 0 : 1],
        });
        if (entry.out_time) {
          statements.push({
            sql: 'INSERT INTO attendance (student_uid, type, timestamp, manual_no_time) VALUES (?, ?, ?, 0)',
            args: [entry.student_uid, 'OUT', `${date} ${entry.out_time}:00`],
          });
        }
      }
    }

    if (!statements.length) {
      return res.status(404).json({ success: false, error: 'Students were not found' });
    }
    await batchRun(statements);
    res.json({ success: true, updated: clean.filter(e => validSet.has(e.student_uid)).length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get absent students today (or for a given date)
router.get('/absent/today', async (req, res) => {
  try {
    const today = req.query.date || todayPKT();
    const cls = req.query.class;

    const anyAttendance = await query('SELECT 1 FROM attendance WHERE date(timestamp) = ? LIMIT 1', [today]);
    const hadClass = anyAttendance.length > 0;

    if (!hadClass) {
      const dow = new Date(today + 'T00:00:00').getDay();
      if (dow === 0) {
        return res.json({ success: true, absent: [], holiday: true, reason: 'Sunday' });
      }
      const holidayRow = await query('SELECT reason FROM holidays WHERE date = ?', [today]);
      if (holidayRow.length) {
        return res.json({ success: true, absent: [], holiday: true, reason: holidayRow[0].reason || 'Holiday' });
      }
    }

    let absent;
    if (cls) {
      absent = await query(
        'SELECT * FROM students WHERE status != \'inactive\' AND class = ? AND student_uid NOT IN (SELECT DISTINCT student_uid FROM attendance WHERE date(timestamp) = ?) ORDER BY name',
        [cls, today]
      );
    } else {
      absent = await query(
        'SELECT * FROM students WHERE status != \'inactive\' AND student_uid NOT IN (SELECT DISTINCT student_uid FROM attendance WHERE date(timestamp) = ?) ORDER BY class, name',
        [today]
      );
    }
    res.json({ success: true, absent });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Send bulk absent WhatsApp notifications
router.post('/absent/notify', async (req, res) => {
  try {
    const { uids } = req.body;
    if (!uids || !uids.length) {
      return res.status(400).json({ success: false, error: 'No students selected' });
    }

    const settings = await query('SELECT * FROM settings');
    const settingsMap = {};
    settings.forEach(s => settingsMap[s.key] = s.value);

    const template = settingsMap['absent_message'] ||
      'Dear Parent, your child {name} was absent from VCC today ({date}). Please ensure regular attendance. For queries: {contact}';

    let sent = 0, queued = 0, failed = 0;
    const results = [];
    const db = getDb();

    for (const uid of uids) {
      const students = await query('SELECT * FROM students WHERE student_uid = ?', [uid]);
      if (!students.length) continue;
      const student = students[0];
      const message = buildMessage(template, student, settingsMap['contact'] || '03000000000');

      const result = await smartSend(student, message, db);
      if (result.sent) sent++; else if (result.queued) queued++; else failed++;
      results.push({ name: student.name, phone: result.phone, sent: result.sent, queued: !!result.queued, usedFallback: result.usedFallback });

      const retryUntil = (result.sent || result.queued) ? null : new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
      try {
        await run('INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [student.name, student.class, result.phone, message,
           result.usedFallback ? 'ABSENT_FALLBACK' : 'ABSENT',
           result.queued ? 'queued' : result.sent ? 'sent' : 'failed', retryUntil, result.msgId || null, result.usedFallback ? 1 : 0, uid, result.sent ? null : result.reason]);
      } catch(e) {}
    }

    res.json({ success: true, sent, queued, failed, results });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get attendance by date range
router.get('/range', async (req, res) => {
  try {
    const { from, to } = req.query;
    const cls = req.query.class;
    if (!from || !to) return res.status(400).json({ success: false, error: 'from and to dates required' });
    let records;
    if (cls) {
      records = await query(
        "SELECT a.*, s.name, s.class, s.section, s.group_name, s.session FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) BETWEEN ? AND ? AND s.class = ? AND (s.status IS NULL OR s.status != 'inactive') ORDER BY a.timestamp DESC",
        [from, to, cls]
      );
    } else {
      records = await query(
        "SELECT a.*, s.name, s.class, s.section, s.group_name, s.session FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) BETWEEN ? AND ? AND (s.status IS NULL OR s.status != 'inactive') ORDER BY a.timestamp DESC",
        [from, to]
      );
    }
    const days = await query(
      "SELECT date(a.timestamp) as day, COUNT(DISTINCT a.student_uid) as present FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) BETWEEN ? AND ? AND a.type = 'IN' AND (s.status IS NULL OR s.status != 'inactive')" + (cls ? ' AND s.class = ?' : '') + ' GROUP BY day ORDER BY day',
      cls ? [from, to, cls] : [from, to]
    );
    const totalStudents = await query("SELECT COUNT(*) as cnt FROM students WHERE (status IS NULL OR status != 'inactive')" + (cls ? ' AND class = ?' : ''), cls ? [cls] : []);
    res.json({ success: true, records, days, totalStudents: totalStudents[0].cnt });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Edit attendance record
router.put('/:id', async (req, res) => {
  try {
    const { type } = req.body;
    if (!type || !['IN', 'OUT'].includes(type)) {
      return res.status(400).json({ success: false, error: 'type must be IN or OUT' });
    }
    const existing = await query('SELECT * FROM attendance WHERE id = ?', [req.params.id]);
    if (!existing.length) return res.status(404).json({ success: false, error: 'Record not found' });
    await run('UPDATE attendance SET type = ? WHERE id = ?', [type, req.params.id]);
    res.json({ success: true, message: 'Record updated' });
  } catch (err) {
    if (require('../attendance-integrity').isDuplicate(err)) return res.status(409).json({success:false,duplicate:true,error:'This attendance type is already recorded for this student on this date.'});
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete attendance record
router.delete('/:id', async (req, res) => {
  try {
    const existing = await query('SELECT * FROM attendance WHERE id = ?', [req.params.id]);
    if (!existing.length) return res.status(404).json({ success: false, error: 'Record not found' });
    await run('DELETE FROM attendance WHERE id = ?', [req.params.id]);
    res.json({ success: true, message: 'Record deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Manual attendance entry (admin override — works even for frozen students)
router.post('/manual', async (req, res) => {
  try {
    const { student_uid, type, date, time } = req.body;
    if (!student_uid || !type || !['IN', 'OUT', 'PRESENT'].includes(type)) {
      return res.status(400).json({ success: false, error: 'student_uid and valid type required' });
    }
    const students = await query('SELECT * FROM students WHERE student_uid = ?', [student_uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const student = students[0];
    const targetDate = date || todayPKT();
    const timestamp = time ? (targetDate + ' ' + time + ':00') : null;
    const recordType = type === 'PRESENT' ? 'IN' : type;
    if (timestamp) {
      await run('INSERT INTO attendance (student_uid, type, timestamp) VALUES (?, ?, ?)', [student_uid, recordType, timestamp]);
    } else {
      await run('INSERT INTO attendance (student_uid, type, timestamp, manual_no_time) VALUES (?, ?, ?, 1)', [student_uid, recordType, targetDate + ' 00:00:00']);
    }
    res.json({ success: true, student: student.name, class: student.class, type: recordType, timestamp });
  } catch (err) {
    if (require('../attendance-integrity').isDuplicate(err)) return res.status(409).json({success:false,duplicate:true,error:'Attendance already recorded for this student on this date. Use Attendance Entries to edit it.'});
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
