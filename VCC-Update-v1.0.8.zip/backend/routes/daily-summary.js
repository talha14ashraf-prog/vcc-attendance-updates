const express = require('express');
const router = express.Router();
const { query, todayPKT } = require('../database');

// Returns a Set of YYYY-MM-DD non-working days: all Sundays + declared holidays.
// Mirrors the same logic used in reports.js so percentages are consistent.
async function getNonWorkingDays(year, month) {
  const prefix = `${year}-${String(month).padStart(2,'0')}-%`;
  const holidayRows = await query('SELECT date FROM holidays WHERE date LIKE ?', [prefix]);
  const nonWorking = new Set(holidayRows.map(r => r.date));

  const totalDays = new Date(year, month, 0).getDate();
  for (let d = 1; d <= totalDays; d++) {
    const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    if (new Date(dateStr + 'T00:00:00').getDay() === 0) nonWorking.add(dateStr);
  }
  return nonWorking;
}

// Returns all calendar days in a month as YYYY-MM-DD strings.
function getDaysInMonth(year, month) {
  const days = [];
  const totalDays = new Date(year, month, 0).getDate();
  for (let d = 1; d <= totalDays; d++) {
    days.push(`${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`);
  }
  return days;
}

// GET /api/daily-summary?date=YYYY-MM-DD&class=X&section=Y&group=Z
router.get('/', async (req, res) => {
  try {
    let date = req.query.date;
    if (!date) date = todayPKT();

    const filterClass   = req.query.class   || '';
    const filterSection = req.query.section || '';
    const filterGroup   = req.query.group   || '';

    let sql = "SELECT student_uid, name, class, section, group_name FROM students WHERE (status IS NULL OR status != 'inactive')";
    const params = [];
    if (filterClass)   { sql += ' AND class=?';      params.push(filterClass); }
    if (filterSection) { sql += ' AND section=?';    params.push(filterSection); }
    if (filterGroup)   { sql += ' AND group_name=?'; params.push(filterGroup); }
    sql += ' ORDER BY class, name';

    const allStudents = await query(sql, params);

    const presentRows = await query(
      `SELECT DISTINCT student_uid FROM attendance WHERE type='IN' AND date(timestamp)=?`,
      [date]
    );
    const presentSet = new Set(presentRows.map(r => r.student_uid));

    const classMap = {};
    allStudents.forEach(s => {
      if (!classMap[s.class]) classMap[s.class] = { class: s.class, total:0, present:0, absent:0, students:[] };
      const present = presentSet.has(s.student_uid);
      classMap[s.class].total++;
      if (present) classMap[s.class].present++; else classMap[s.class].absent++;
      classMap[s.class].students.push({ name:s.name, student_uid:s.student_uid, present });
    });

    const classes = Object.values(classMap).sort((a,b)=>a.class.localeCompare(b.class));
    const grandTotal   = allStudents.length;
    const grandPresent = allStudents.filter(s => presentSet.has(s.student_uid)).length;

    // Return distinct filter options from ALL students (unfiltered)
    const allForFilters = await query('SELECT DISTINCT class, section, group_name FROM students ORDER BY class');
    const classes_list  = [...new Set(allForFilters.map(r=>r.class).filter(Boolean))].sort();
    const sections_list = [...new Set(allForFilters.map(r=>r.section).filter(Boolean))].sort();
    const groups_list   = [...new Set(allForFilters.map(r=>r.group_name).filter(Boolean))].sort();

    res.json({
      success:true, date,
      summary:{ total:grandTotal, present:grandPresent, absent:grandTotal-grandPresent },
      classes,
      filters:{ classes:classes_list, sections:sections_list, groups:groups_list }
    });
  } catch(err) {
    res.status(500).json({ success:false, error:err.message });
  }
});

// GET /api/daily-summary/monthly?month=YYYY-MM&class=X&section=Y&group=Z
router.get('/monthly', async (req, res) => {
  try {
    let month = req.query.month;
    if (!month) { const today=todayPKT(); month=today.slice(0,7); }

    const filterClass   = req.query.class   || '';
    const filterSection = req.query.section || '';
    const filterGroup   = req.query.group   || '';

    const [year, mon] = month.split('-').map(Number);

    let sql = "SELECT student_uid, name, class, section, group_name FROM students WHERE (status IS NULL OR status != 'inactive')";
    const params = [];
    if (filterClass)   { sql += ' AND class=?';      params.push(filterClass); }
    if (filterSection) { sql += ' AND section=?';    params.push(filterSection); }
    if (filterGroup)   { sql += ' AND group_name=?'; params.push(filterGroup); }
    sql += ' ORDER BY class, name';

    const allStudents = await query(sql, params);

    const rows = await query(
      `SELECT student_uid, date(timestamp) as day FROM attendance
       WHERE type='IN' AND strftime('%Y-%m', timestamp)=?`,
      [month]
    );

    const presenceMap = {};
    allStudents.forEach(s => { presenceMap[s.student_uid] = new Set(); });
    rows.forEach(r => { if (presenceMap[r.student_uid]) presenceMap[r.student_uid].add(r.day); });

    // Working days derived from the calendar (Mon-Sat minus holidays),
    // NOT from attendance data. Previously a day where everyone was absent
    // would not be counted as a working day — inflating attendance percentages.
    const nonWorking = await getNonWorkingDays(year, mon);
    const allCalendarDays = getDaysInMonth(year, mon);
    const today = todayPKT();
    const workingDays = allCalendarDays.filter(d => !nonWorking.has(d) && d <= today);
    const totalWorkingDays = workingDays.length;

    const classMap = {};
    allStudents.forEach(s => {
      if (!classMap[s.class]) classMap[s.class] = { class:s.class, students:[] };
      const presentDays = presenceMap[s.student_uid].size;
      const absentDays  = totalWorkingDays - presentDays;
      const pct = totalWorkingDays ? parseFloat(((presentDays/totalWorkingDays)*100).toFixed(1)) : 0;
      classMap[s.class].students.push({
        name:s.name, student_uid:s.student_uid,
        presentDays, absentDays, pct,
        dailyRecord: workingDays.map(d=>({ day:d, present:presenceMap[s.student_uid].has(d) }))
      });
    });

    const classes = Object.values(classMap).sort((a,b)=>a.class.localeCompare(b.class));

    let grandPresent=0, grandAbsent=0;
    allStudents.forEach(s => {
      const p = presenceMap[s.student_uid].size;
      grandPresent += p; grandAbsent += (totalWorkingDays - p);
    });

    // Filter options
    const allForFilters = await query('SELECT DISTINCT class, section, group_name FROM students ORDER BY class');
    const classes_list  = [...new Set(allForFilters.map(r=>r.class).filter(Boolean))].sort();
    const sections_list = [...new Set(allForFilters.map(r=>r.section).filter(Boolean))].sort();
    const groups_list   = [...new Set(allForFilters.map(r=>r.group_name).filter(Boolean))].sort();

    res.json({
      success:true, month, workingDays, totalWorkingDays,
      daysInMonth: new Date(year, mon, 0).getDate(),
      summary:{ totalStudents:allStudents.length, grandPresent, grandAbsent },
      classes,
      filters:{ classes:classes_list, sections:sections_list, groups:groups_list }
    });
  } catch(err) {
    res.status(500).json({ success:false, error:err.message });
  }
});

// GET /api/daily-summary/student?uid=VCC-XXXX&from=YYYY-MM-DD&to=YYYY-MM-DD
// Also supports: name=, gr=, class=, section= for searching
router.get('/student', async (req, res) => {
  try {
    const { uid, gr, name, class: cls, section, from, to } = req.query;

    // Build student lookup query
    let studentSql = "SELECT * FROM students WHERE (status IS NULL OR status != 'inactive')";
    const studentParams = [];

    if (uid)     { studentSql += ' AND student_uid=?';           studentParams.push(uid); }
    if (gr)      { studentSql += ' AND gr_number=?';             studentParams.push(gr); }
    if (name)    { studentSql += ' AND LOWER(name) LIKE ?';      studentParams.push('%' + name.toLowerCase() + '%'); }
    if (cls)     { studentSql += ' AND class=?';                 studentParams.push(cls); }
    if (section) { studentSql += ' AND section=?';               studentParams.push(section); }

    studentSql += ' ORDER BY name LIMIT 50';
    const matchedStudents = await query(studentSql, studentParams);

    if (!matchedStudents.length) {
      return res.json({ success: true, students: [], from: from||'', to: to||'', message: 'No students found.' });
    }

    const today    = todayPKT();
    const dateFrom = from || '2000-01-01';
    const dateTo   = to   || today;

    // Build calendar-based working days in range: Mon–Sat, not holiday, not future.
    // This ensures days where the server was closed (no attendance recorded) are
    // still counted as absent rather than simply ignored.
    const holidayRows2 = await query(
      `SELECT date FROM holidays WHERE date BETWEEN ? AND ?`,
      [dateFrom, dateTo]
    );
    const holidaySet = new Set(holidayRows2.map(r => r.date));

    const workingDays = [];
    const endDate = dateTo <= today ? dateTo : today;
    // String-based iteration avoids timezone/DST shifts
    let curISO = dateFrom;
    while (curISO <= endDate) {
      const [cy, cm, cd] = curISO.split('-').map(Number);
      const dow = new Date(cy, cm - 1, cd).getDay(); // local — no UTC shift
      if (dow !== 0 && !holidaySet.has(curISO)) workingDays.push(curISO);
      const next = new Date(cy, cm - 1, cd + 1);
      curISO = next.getFullYear() + '-' +
               String(next.getMonth() + 1).padStart(2, '0') + '-' +
               String(next.getDate()).padStart(2, '0');
    }
    const totalWorking = workingDays.length;

    const results = await Promise.all(matchedStudents.map(async student => {
      // Get all IN and OUT records for this student in the date range
      const attendanceRows = await query(
        `SELECT date(timestamp) as day, type, time(timestamp) as time_val
         FROM attendance
         WHERE student_uid=? AND date(timestamp) BETWEEN ? AND ?
         ORDER BY timestamp ASC`,
        [student.student_uid, dateFrom, dateTo]
      );

      // Build a day-by-day map: first IN and last OUT per day
      const dayMap = {};
      attendanceRows.forEach(row => {
        if (!dayMap[row.day]) dayMap[row.day] = { in: null, out: null };
        if (row.type === 'IN'  && !dayMap[row.day].in)  dayMap[row.day].in  = row.time_val;
        if (row.type === 'OUT')                          dayMap[row.day].out = row.time_val; // keep last OUT
      });

      const totalPresent = Object.keys(dayMap).length;
      const totalAbsent  = totalWorking - totalPresent;
      const pct = totalWorking ? parseFloat(((totalPresent / totalWorking) * 100).toFixed(1)) : 0;

      // Build daily record for every working day
      const dailyRecord = workingDays.map(day => ({
        day,
        present: !!dayMap[day],
        in:  dayMap[day] ? dayMap[day].in  : null,
        out: dayMap[day] ? dayMap[day].out : null,
      }));

      return {
        student_uid:    student.student_uid,
        name:           student.name,
        class:          student.class,
        section:        student.section,
        gr_number:      student.gr_number,
        admission_date: student.admission_date,
        totalPresent,
        totalAbsent,
        totalWorking,
        pct,
        workingDays,
        dailyRecord,
      };
    }));

    res.json({ success: true, from: dateFrom, to: dateTo, students: results });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;