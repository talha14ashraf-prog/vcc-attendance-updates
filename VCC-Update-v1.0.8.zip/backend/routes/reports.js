const express = require('express');
const router = express.Router();
const { query, run } = require('../database');
const path = require('path');
const fs = require('fs');
const zlib = require('zlib');

const DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function toPKT(utcStr) {
  // Timestamp stored as PKT string "YYYY-MM-DD HH:MM:SS" — parse directly, no Date conversion
  const parts = utcStr.split(' ');
  if (parts.length < 2) return utcStr;
  const timePart = parts[1]; // "HH:MM:SS"
  const [hh, mm] = timePart.split(':').map(Number);
  const ampm = hh >= 12 ? 'PM' : 'AM';
  const hour12 = hh % 12 || 12;
  return `${String(hour12).padStart(2,'0')}:${String(mm).padStart(2,'0')} ${ampm}`;
}

// Returns formatted time or '—' if record has manual_no_time flag (no time recorded)
function safeTime(record) {
  if (!record) return '—';
  if (record.manual_no_time) return '—';
  return toPKT(record.timestamp);
}

function formatDate(dateStr) {
  const [y, m, d] = dateStr.split('-');
  return `${d}/${m}/${y}`;
}

function getDayName(dateStr) {
  const d = new Date(dateStr + 'T00:00:00');
  return DAYS[d.getDay()];
}

function getDaysInMonth(year, month) {
  const days = [];
  const totalDays = new Date(year, month, 0).getDate();
  for (let d = 1; d <= totalDays; d++) {
    const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    days.push(dateStr);
  }
  return days;
}

// Returns a Set of YYYY-MM-DD strings that are non-working:
//   - All Sundays of the month (always — Sunday attendance is bonus, never penalizes)
//   - All holidays in the holidays table for that month
async function getNonWorkingDays(year, month) {
  const prefix = `${year}-${String(month).padStart(2,'0')}-%`;

  // Holidays from DB
  const holidayRows = await query('SELECT date FROM holidays WHERE date LIKE ?', [prefix]);
  const nonWorking = new Set(holidayRows.map(r => r.date));

  // All Sundays — always non-working regardless of attendance
  getDaysInMonth(year, month).forEach(dateStr => {
    if (new Date(dateStr + 'T00:00:00').getDay() === 0) nonWorking.add(dateStr);
  });

  return nonWorking;
}

async function getSettings() {
  const rows = await query('SELECT * FROM settings');
  const map = {};
  rows.forEach(r => map[r.key] = r.value);
  return map;
}

// ── HTML TEMPLATE PDF GENERATOR ─────────────────────────────────────
const { execFile } = require('child_process');
const os = require('os');

function renderHTMLtoPDF(html) {
  return new Promise((resolve, reject) => {
    const tmpDir  = os.tmpdir();
    const uid     = Date.now() + '_' + Math.random().toString(36).slice(2);
    const inFile  = path.join(tmpDir, 'vcc_in_' + uid + '.html');
    const outFile = path.join(tmpDir, 'vcc_out_' + uid + '.pdf');

    try { fs.writeFileSync(inFile, html, 'utf8'); }
    catch(e) { return reject(new Error('Temp write failed: ' + e.message)); }

    let chromePath;
    try {
      if (process.env.PUPPETEER_EXECUTABLE_PATH) {
        chromePath = process.env.PUPPETEER_EXECUTABLE_PATH;
      } else {
        chromePath = require('puppeteer-core').executablePath();
      }
      if (!chromePath) throw new Error('No Chrome path found');
    } catch(e) {
      try { fs.unlinkSync(inFile); } catch(_) {}
      return reject(new Error('Cannot find Chrome: ' + e.message + ' — Set PUPPETEER_EXECUTABLE_PATH in .env'));
    }

    const fileUrl = 'file:///' + inFile.replace(/\\/g, '/');
    const args = [
      '--headless=new', '--disable-gpu', '--no-sandbox',
      '--disable-setuid-sandbox', '--disable-dev-shm-usage',
      '--virtual-time-budget=5000',
      '--print-to-pdf=' + outFile,
      '--no-pdf-header-footer', fileUrl
    ];

    execFile(chromePath, args, { timeout: 30000 }, (err, stdout, stderr) => {
      try { fs.unlinkSync(inFile); } catch(_) {}
      if (err && !fs.existsSync(outFile)) {
        return reject(new Error('Chrome error: ' + (stderr || err.message)));
      }
      try {
        const pdf = fs.readFileSync(outFile);
        try { fs.unlinkSync(outFile); } catch(_) {}
        resolve(pdf);
      } catch(e) {
        reject(new Error('PDF read failed: ' + e.message));
      }
    });
  });
}


async function generateStudentPDF(student, year, month, settings) {

  const monthName = MONTHS[month - 1];
  const campus = settings.vcc_name || 'Vectors Coaching Centre';

  // Null-safe student fields
  const sName = (student.name || '').toUpperCase();
  const sClass = student.class || '—';
  const sSection = student.section || '—';
  const sGR = student.gr_number || '—';
  const sFather = student.father_name || '—';
  const rawAdm = student.admission_date || '';
  const sAdmission = rawAdm ? rawAdm.split('-').reverse().join('-') : '—';
  const sGroup = student.group_name || '';
  const groupSuffix = sGroup ? ` (${sGroup})` : '';

  // Get attendance data
  const startDate = `${year}-${String(month).padStart(2,'0')}-01`;
  const endDate = `${year}-${String(month).padStart(2,'0')}-${new Date(year, month, 0).getDate()}`;
  const attendanceRows = await query(`
    SELECT * FROM attendance
    WHERE student_uid = ?
    AND date(timestamp) >= ? AND date(timestamp) <= ?
    ORDER BY timestamp ASC
  `, [student.student_uid, startDate, endDate]);

  // Group by date
  const byDate = {};
  attendanceRows.forEach(r => {
    const d = r.timestamp.split(' ')[0];
    if (!byDate[d]) byDate[d] = [];
    byDate[d].push(r);
  });

  const allDays = getDaysInMonth(year, month);
  const nonWorkingDays = await getNonWorkingDays(year, month);
  let presentCount = 0;
  let absentCount = 0;

  // Build attendance rows HTML
  let rowsHtml = '';
  let serial = 0;
  allDays.forEach((dateStr) => {
    serial++;
    const dayName = getDayName(dateStr);
    const isNonWorking = nonWorkingDays.has(dateStr);
    const isSunday = new Date(dateStr + 'T00:00:00').getDay() === 0;

    if (isNonWorking) {
      // Holiday / Sunday — check if THIS student actually attended
      const dayRecords = byDate[dateStr] || [];
      const inRecord  = dayRecords.find(r => r.type === 'IN');
      const outRecord = dayRecords.find(r => r.type === 'OUT');

      if (inRecord) {
        // Student came on a holiday/Sunday — count as present (bonus), show normal row
        presentCount++;
        const inTime   = safeTime(inRecord);
        const outTime  = safeTime(outRecord);
        const label    = isSunday ? 'Sunday' : 'Holiday';
        const rowBg    = isSunday ? 'class="sunday-row"' : 'class="holiday-row"';
        rowsHtml += `<tr ${rowBg}>
          <td>${serial}</td>
          <td>${formatDate(dateStr)}</td>
          <td>${label} Ex Class</td>
          <td>${sGR}</td>
          <td>${sName}</td>
          <td>${sClass}</td>
          <td>${sSection}</td>
          <td><span class="status-p">P</span></td>
          <td>${inTime}</td>
          <td>${outTime}</td>
          <td>${campus}</td>
        </tr>`;
      } else {
        // Absent on holiday/Sunday — show styled row, do NOT count as absent
        const label = isSunday ? 'Sunday' : 'Holiday';
        const absentRowStyle = isSunday
          ? 'class="sunday-row"'
          : 'class="holiday-row"';
        rowsHtml += `<tr ${absentRowStyle}>
          <td>${serial}</td>
          <td>${formatDate(dateStr)}</td>
          <td>${label}</td>
          <td>${sGR}</td>
          <td>${sName}</td>
          <td>${sClass}</td>
          <td>${sSection}</td>
          <td>—</td>
          <td>—</td>
          <td>—</td>
          <td>${campus}</td>
        </tr>`;
      }
      return;
    }

// Pre-admission date — student wasn't enrolled yet
    if (rawAdm && dateStr < rawAdm) {
      rowsHtml += `<tr style="background:#e8e8e8;color:#999999;">
        <td style="background:#e8e8e8;">${serial}</td>
        <td style="background:#e8e8e8;">${formatDate(dateStr)}</td>
        <td style="background:#e8e8e8;">${dayName}</td>
        <td style="background:#e8e8e8;">${sGR}</td>
        <td style="background:#e8e8e8;">${sName}</td>
        <td style="background:#e8e8e8;">${sClass}</td>
        <td style="background:#e8e8e8;">${sSection}</td>
        <td style="background:#e8e8e8;letter-spacing:2px;">----</td>
        <td style="background:#e8e8e8;">—</td>
        <td style="background:#e8e8e8;">—</td>
        <td style="background:#e8e8e8;">${campus}</td>
      </tr>`;
      return; // not counted in present or absent
    }

    const dayRecords = byDate[dateStr] || [];
    const inRecord = dayRecords.find(r => r.type === 'IN');
    const outRecord = dayRecords.find(r => r.type === 'OUT');
    const isPresent = !!inRecord;

    if (isPresent) presentCount++; else absentCount++;

    const inTime = safeTime(inRecord);
    const outTime = safeTime(outRecord);
    const status = isPresent ? 'P' : 'A';
    const statusClass = isPresent ? 'status-p' : 'status-a';
    const rowBg = serial % 2 === 0 ? 'style="background:#f9f9f9"' : '';

    rowsHtml += `<tr ${rowBg}>
      <td>${serial}</td>
      <td>${formatDate(dateStr)}</td>
      <td>${dayName}</td>
      <td>${sGR}</td>
      <td>${sName}</td>
      <td>${sClass}</td>
      <td>${sSection}</td>
      <td class="${statusClass}">${status}</td>
      <td>${inTime}</td>
      <td>${outTime}</td>
      <td>${campus}</td>
    </tr>`;
  });

  // Load template from settings DB, or fall back to default file
  let template = settings.report_template || '';
  if (!template) {
    const defaultPath = path.join(__dirname, '../../frontend/report-template-default.html');
    if (fs.existsSync(defaultPath)) {
      template = fs.readFileSync(defaultPath, 'utf8');
    } else {
      throw new Error('No report template found. Please set one up in Settings → Report Template.');
    }
  }

  // Build logo img tag (base64 embed if logo file exists)
  let logoHtml = '<span style="font-weight:900;font-size:14px">VCC</span>';
  const logoPath = path.join(__dirname, '../../frontend/assets/logo.png');
  if (fs.existsSync(logoPath)) {
    const logoData = fs.readFileSync(logoPath).toString('base64');
    logoHtml = `<img src="data:image/png;base64,${logoData}" />`;
  }

  // Substitute all placeholders
  const html = template
    .replace(/\{\{VCC_NAME\}\}/g,       (settings.vcc_name || 'VECTORS COACHING CENTRE').toUpperCase())
    .replace(/\{\{LOGO_IMG\}\}/g,        logoHtml)
    .replace(/\{\{STUDENT_NAME\}\}/g,    sName)
    .replace(/\{\{FATHER_NAME\}\}/g,     sFather)
    .replace(/\{\{ADMISSION_DATE\}\}/g,  sAdmission)
    .replace(/\{\{CLASS\}\}/g,           sClass)
    .replace(/\{\{SECTION\}\}/g,         sSection)
    .replace(/\{\{GROUP_SUFFIX\}\}/g,    groupSuffix)
    .replace(/\{\{GR_NUMBER\}\}/g,       sGR)
    .replace(/\{\{MONTH_YEAR\}\}/g,      `${monthName.toUpperCase()} ${year}`)
    .replace(/\{\{ATTENDANCE_ROWS\}\}/g, rowsHtml)
    .replace(/\{\{TOTAL_DAYS\}\}/g,      String(allDays.length))
    .replace(/\{\{PRESENT_COUNT\}\}/g,   String(presentCount))
    .replace(/\{\{ABSENT_COUNT\}\}/g,    String(absentCount))
    .replace(/\{\{CAMPUS\}\}/g,          campus)
    .replace(/\{\{PHONE1\}\}/g,          settings.vcc_phone1 || '')
    .replace(/\{\{PHONE2\}\}/g,          settings.vcc_phone2 || '')
    .replace(/\{\{ADDRESS\}\}/g,         settings.vcc_address || '');

  // Render via isolated child process — avoids Windows Chrome/WebSocket conflicts
  return await renderHTMLtoPDF(html);
}

// ── ROUTES ──────────────────────────────────────────────

// Get available months
router.get('/months', async (req, res) => {
  try {
    const rows = await query(`
      SELECT DISTINCT strftime('%Y', timestamp) as year,
                      strftime('%m', timestamp) as month
      FROM attendance ORDER BY year DESC, month DESC
    `);
    res.json({ success: true, months: rows });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get report template
router.get('/template', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'report_template'");
    let template = rows.length ? rows[0].value : '';

    if (!template) {
      const defaultPath = path.join(__dirname, '../../frontend/report-template-default.html');
      if (fs.existsSync(defaultPath)) {
        template = fs.readFileSync(defaultPath, 'utf8');
      }
    }
    res.json({ success: true, template });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Save report template
router.post('/template', async (req, res) => {
  try {
    const { template } = req.body;
    if (!template) return res.status(400).json({ success: false, error: 'No template provided' });
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES ('report_template', ?)", [template]);
    res.json({ success: true, message: 'Template saved successfully' });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Reset template to default
router.post('/template/reset', async (req, res) => {
  try {
    await run("DELETE FROM settings WHERE key = 'report_template'");
    const defaultPath = path.join(__dirname, '../../frontend/report-template-default.html');
    let template = '';
    if (fs.existsSync(defaultPath)) {
      template = fs.readFileSync(defaultPath, 'utf8');
    }
    res.json({ success: true, template });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Generate single student PDF
router.get('/student/:uid/:year/:month', async (req, res) => {
  try {
    const { uid, year, month } = req.params;
    const students = await query('SELECT * FROM students WHERE student_uid = ?', [uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });

    const settings = await getSettings();
    const pdfBuffer = await generateStudentPDF(students[0], parseInt(year), parseInt(month), settings);
    const filename = `${students[0].name.toUpperCase()} ATTENDANCE REPORT ${MONTHS[parseInt(month)-1].toUpperCase()} ${year}.pdf`;

    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(pdfBuffer);
  } catch(err) {
    console.error('[PDF ROUTE ERROR]', err);
    res.status(500).type('text/plain').send('PDF Error: ' + (err.message || String(err)));
  }
});

// Generate ZIP of all/selected students
router.post('/generate-zip', async (req, res) => {
  try {
    const { year, month, class: cls, section, student_uids } = req.body;
    let students;

    if (student_uids && student_uids.length) {
      const placeholders = student_uids.map(() => '?').join(',');
      students = await query(`SELECT * FROM students WHERE student_uid IN (${placeholders}) ORDER BY name`, student_uids);
    } else if (cls && section) {
      students = await query('SELECT * FROM students WHERE class = ? AND section = ? ORDER BY name', [cls, section]);
    } else if (cls) {
      students = await query('SELECT * FROM students WHERE class = ? ORDER BY section, name', [cls]);
    } else {
      students = await query('SELECT * FROM students ORDER BY class, section, name');
    }

    if (!students.length) return res.status(404).json({ success: false, error: 'No students found' });

    // Hard cap: generating PDFs is sequential (one Chrome launch per student).
    // More than 60 students will exceed HTTP timeout (~2 min) and hang the server.
    // Filter by section to stay under the limit.
    const ZIP_LIMIT = 60;
    if (students.length > ZIP_LIMIT) {
      return res.status(400).json({
        success: false,
        error: `Too many students (${students.length}) for a single ZIP. Max is ${ZIP_LIMIT}. Please filter by section or select specific students.`
      });
    }

    const settings = await getSettings();
    const monthName = MONTHS[parseInt(month) - 1];

    const files = [];
    for (const student of students) {
      const pdfBuffer = await generateStudentPDF(student, parseInt(year), parseInt(month), settings);
      const filename = `${student.name.toUpperCase()} ATTENDANCE REPORT ${monthName.toUpperCase()} ${year}.pdf`;
      files.push({ filename, buffer: pdfBuffer });
    }

    const zipBuffer = createZip(files);
    const zipName = `VCC_Attendance_Reports_${monthName}_${year}${cls ? '_' + cls : ''}.zip`;
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', `attachment; filename="${zipName}"`);
    res.send(zipBuffer);

  } catch(err) {
    console.error('ZIP generation error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Preview: student list with attendance summary
router.post('/preview', async (req, res) => {
  try {
    const { year, month, class: cls, section } = req.body;
    let students;
    if (cls && section) {
      students = await query("SELECT student_uid, name, class, section, gr_number, admission_date FROM students WHERE class = ? AND section = ? AND status != 'inactive' ORDER BY name", [cls, section]);
    } else if (cls) {
      students = await query("SELECT student_uid, name, class, section, gr_number, admission_date FROM students WHERE class = ? AND status != 'inactive' ORDER BY section, name", [cls]);
    } else {
      students = await query("SELECT student_uid, name, class, section, gr_number, admission_date FROM students WHERE status != 'inactive' ORDER BY class, section, name");
    }

    const startDate = `${year}-${String(month).padStart(2,'0')}-01`;
    const endDate = `${year}-${String(month).padStart(2,'0')}-${new Date(year, month, 0).getDate()}`;
    const totalDays = new Date(year, month, 0).getDate();

    // Pre-compute all days of month with non-working flags
    const nonWorkingDays = await getNonWorkingDays(year, month);
    const allDays = getDaysInMonth(year, month).map(dateStr => ({
      dateStr,
      isNonWorking: nonWorkingDays.has(dateStr)
    }));

    // Single batch query for all students — replaces the N+1 per-student queries
    const allAtt = await query(
      `SELECT DISTINCT student_uid, date(timestamp) as d
       FROM attendance
       WHERE type = 'IN' AND date(timestamp) >= ? AND date(timestamp) <= ?`,
      [startDate, endDate]
    );
    const presenceMap = {};
    allAtt.forEach(r => {
      if (!presenceMap[r.student_uid]) presenceMap[r.student_uid] = new Set();
      presenceMap[r.student_uid].add(r.d);
    });

    const result = students.map(s => {
      const presentSet = presenceMap[s.student_uid] || new Set();
      const admDate = s.admission_date || '';

      let present = 0, absent = 0, applicable = 0;
      allDays.forEach(({ dateStr, isNonWorking }) => {
        if (admDate && dateStr < admDate) return;  // skip pre-admission
        if (isNonWorking) {
          // holiday/Sunday — only count if student actually attended (bonus present)
          if (presentSet.has(dateStr)) present++;
          return; // never count as absent, never add to applicable
        }
        applicable++;
        if (presentSet.has(dateStr)) present++;
        else absent++;
      });

      return {
        uid: s.student_uid, name: s.name, class: s.class,
        section: s.section, gr_number: s.gr_number,
        present, absent, total: applicable
      };
    });

    res.json({ success: true, students: result, totalDays });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Send single student PDF via WhatsApp
router.post('/send-whatsapp', async (req, res) => {
  try {
    const { uid, year, month, caption } = req.body;
    const { smartSendFile } = require('../whatsapp');

    const students = await query('SELECT * FROM students WHERE student_uid = ?', [uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const student = students[0];

    const settings = await getSettings();
    const pdfBuffer = await generateStudentPDF(student, parseInt(year), parseInt(month), settings);
    const monthName = MONTHS[parseInt(month) - 1];
    const filename = `${student.name.toUpperCase()} ATTENDANCE REPORT ${monthName.toUpperCase()} ${year}.pdf`;

    const result = await smartSendFile(student, pdfBuffer, filename, caption || '', require('../database'));

    // Log to whatsapp_log for tracking and retry
    try {
      await run(
        `INSERT INTO whatsapp_log
          (student_name, student_class, phone, message, type, status, log_type, report_year, report_month, student_uid, caption, used_phone2, fail_reason, msg_id)
         VALUES (?, ?, ?, ?, 'REPORT', ?, 'MONTHLY_REPORT', ?, ?, ?, ?, ?, ?, ?)`,
        [
          student.name, student.class, result.phone,
          `Monthly Report ${monthName} ${year}`,
          result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
          parseInt(year), parseInt(month), uid, caption || '',
          result.usedFallback ? 1 : 0, result.sent ? null : result.reason, result.msgId || null
        ]
      );
    } catch(logErr) { console.warn('Failed to log WA monthly report:', logErr.message); }

    res.json({ success: result.sent || result.queued, queued: !!result.queued, error: (result.sent || result.queued) ? null : result.reason });
  } catch(err) {
    console.error('send-whatsapp error:', err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// Retry failed monthly report — regenerate PDF and resend
router.post('/retry-whatsapp', async (req, res) => {
  try {
    const { ids } = req.body; // array of whatsapp_log IDs with log_type=MONTHLY_REPORT
    const { smartSendFile } = require('../whatsapp');

    let sent = 0, failed = 0;
    for (const id of ids) {
      const rows = await query('SELECT * FROM whatsapp_log WHERE id = ?', [id]);
      if (!rows.length) { failed++; continue; }
      const log = rows[0];
      if (String(log.msg_id || '').startsWith('sms:')) { failed++; continue; }

      if (!log.student_uid || !log.report_year || !log.report_month) { failed++; continue; }

      const students = await query('SELECT * FROM students WHERE student_uid = ?', [log.student_uid]);
      if (!students.length) { failed++; continue; }
      const student = students[0];

      try {
        const settings = await getSettings();
        const pdfBuffer = await generateStudentPDF(student, log.report_year, log.report_month, settings);
        const monthName = MONTHS[log.report_month - 1];
        const filename = `${student.name.toUpperCase()} ATTENDANCE REPORT ${monthName.toUpperCase()} ${log.report_year}.pdf`;

        const result = await smartSendFile(student, pdfBuffer, filename, log.caption || '', require('../database'));

        if (result.sent) {
          await run(`UPDATE whatsapp_log SET status='sent', retry_count=retry_count+1, retry_until=NULL, phone=?, used_phone2=?, fail_reason=NULL WHERE id=?`,
            [result.phone, result.usedFallback ? 1 : 0, id]);
          sent++;
        } else {
          const retryUntil = new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0];
          await run(`UPDATE whatsapp_log SET retry_count=retry_count+1, retry_until=?, phone=?, used_phone2=?, fail_reason=? WHERE id=?`,
            [retryUntil, result.phone, result.usedFallback ? 1 : 0, result.reason, id]);
          failed++;
        }
      } catch(sendErr) {
        failed++;
        console.error('Retry send error for log', id, sendErr.message);
      }
    }
    res.json({ success: true, sent, failed });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── ZIP builder ──────────────────────────────────────────
function createZip(files) {
  const buffers = [];
  const centralDir = [];
  let offset = 0;

  for (const file of files) {
    const nameBuffer = Buffer.from(file.filename, 'utf8');
    const compressed = zlib.deflateRawSync(file.buffer);

    const localHeader = Buffer.alloc(30 + nameBuffer.length);
    localHeader.writeUInt32LE(0x04034b50, 0);
    localHeader.writeUInt16LE(20, 4);
    localHeader.writeUInt16LE(0, 6);
    localHeader.writeUInt16LE(8, 8);
    localHeader.writeUInt16LE(0, 10);
    localHeader.writeUInt16LE(0, 12);
    const crc = crc32(file.buffer);
    localHeader.writeUInt32LE(crc, 14);
    localHeader.writeUInt32LE(compressed.length, 18);
    localHeader.writeUInt32LE(file.buffer.length, 22);
    localHeader.writeUInt16LE(nameBuffer.length, 26);
    localHeader.writeUInt16LE(0, 28);
    nameBuffer.copy(localHeader, 30);

    buffers.push(localHeader);
    buffers.push(compressed);

    const cdEntry = Buffer.alloc(46 + nameBuffer.length);
    cdEntry.writeUInt32LE(0x02014b50, 0);
    cdEntry.writeUInt16LE(20, 4);
    cdEntry.writeUInt16LE(20, 6);
    cdEntry.writeUInt16LE(0, 8);
    cdEntry.writeUInt16LE(8, 10);
    cdEntry.writeUInt16LE(0, 12);
    cdEntry.writeUInt16LE(0, 14);
    cdEntry.writeUInt32LE(crc, 16);
    cdEntry.writeUInt32LE(compressed.length, 20);
    cdEntry.writeUInt32LE(file.buffer.length, 24);
    cdEntry.writeUInt16LE(nameBuffer.length, 28);
    cdEntry.writeUInt16LE(0, 30);
    cdEntry.writeUInt16LE(0, 32);
    cdEntry.writeUInt16LE(0, 34);
    cdEntry.writeUInt16LE(0, 36);
    cdEntry.writeUInt32LE(0, 38);
    cdEntry.writeUInt32LE(offset, 42);
    nameBuffer.copy(cdEntry, 46);

    centralDir.push(cdEntry);
    offset += localHeader.length + compressed.length;
  }

  const cdBuffer = Buffer.concat(centralDir);
  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdBuffer.length, 12);
  eocd.writeUInt32LE(offset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...buffers, cdBuffer, eocd]);
}

// Build CRC table once at startup — not inside crc32() on every call
const CRC_TABLE = (() => {
  const table = [];
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) {
      c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    }
    table[i] = c;
  }
  return table;
})();

function crc32(buf) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc = (crc >>> 8) ^ CRC_TABLE[(crc ^ buf[i]) & 0xFF];
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

module.exports = router;
