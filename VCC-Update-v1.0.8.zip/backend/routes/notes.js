const express = require('express');
const router = express.Router();
const { query, run, batchRun, todayPKT } = require('../database');
const { buildSlipData, printSlip } = require('../print');

// Validates a YYYY-MM-DD string is a real calendar date (not just digit-shaped —
// e.g. rejects 2026-13-45), returning it back or null.
function parseDateParam(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return null;
  const [y, m, d] = value.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d));
  const valid = dt.getUTCFullYear() === y && dt.getUTCMonth() === m - 1 && dt.getUTCDate() === d;
  return valid ? value : null;
}

// GET /api/notes/catalog  → list all notes catalog entries
router.get('/catalog', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM notes_catalog ORDER BY class, subject');
    res.json({ success: true, catalog: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/catalog  body: { class, subject, cost_price, selling_price, stock_qty, low_stock_threshold }
router.post('/catalog', async (req, res) => {
  try {
    const { class: cls, subject, cost_price, selling_price, stock_qty, low_stock_threshold } = req.body;

    if (!cls || !String(cls).trim()) return res.status(400).json({ success: false, error: 'Class is required' });
    if (!subject || !String(subject).trim()) return res.status(400).json({ success: false, error: 'Subject is required' });

    const cost = Number(cost_price);
    const sell = Number(selling_price);
    const stock = Number(stock_qty);
    const threshold = low_stock_threshold === undefined || low_stock_threshold === '' ? 5 : Number(low_stock_threshold);

    if (!Number.isFinite(cost) || cost < 0) return res.status(400).json({ success: false, error: 'Cost price must be a valid non-negative number' });
    if (!Number.isFinite(sell) || sell < 0) return res.status(400).json({ success: false, error: 'Selling price must be a valid non-negative number' });
    if (!Number.isInteger(stock) || stock < 0) return res.status(400).json({ success: false, error: 'Stock quantity must be a valid non-negative whole number' });
    if (!Number.isInteger(threshold) || threshold < 0) return res.status(400).json({ success: false, error: 'Low stock threshold must be a valid non-negative whole number' });

    const existing = await query('SELECT id FROM notes_catalog WHERE class = ? AND subject = ?', [cls, subject]);
    if (existing.length) {
      return res.status(409).json({ success: false, error: `${subject} for class ${cls} already exists in the catalog. Edit it instead.` });
    }

    await run(
      'INSERT INTO notes_catalog (class, subject, cost_price, selling_price, stock_qty, low_stock_threshold) VALUES (?, ?, ?, ?, ?, ?)',
      [cls, subject, cost, sell, stock, threshold]
    );
    const rows = await query('SELECT * FROM notes_catalog WHERE class = ? AND subject = ?', [cls, subject]);
    res.json({ success: true, item: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/notes/catalog/:id  body: same fields as POST, any subset
router.put('/catalog/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const existingRows = await query('SELECT * FROM notes_catalog WHERE id = ?', [id]);
    if (!existingRows.length) return res.status(404).json({ success: false, error: 'Catalog item not found' });
    const existing = existingRows[0];

    const cls = req.body.class !== undefined ? req.body.class : existing.class;
    const subject = req.body.subject !== undefined ? req.body.subject : existing.subject;

    if (!cls || !String(cls).trim()) return res.status(400).json({ success: false, error: 'Class is required' });
    if (!subject || !String(subject).trim()) return res.status(400).json({ success: false, error: 'Subject is required' });

    const cost = req.body.cost_price !== undefined ? Number(req.body.cost_price) : existing.cost_price;
    const sell = req.body.selling_price !== undefined ? Number(req.body.selling_price) : existing.selling_price;
    const stock = req.body.stock_qty !== undefined ? Number(req.body.stock_qty) : existing.stock_qty;
    const threshold = req.body.low_stock_threshold !== undefined ? Number(req.body.low_stock_threshold) : existing.low_stock_threshold;

    if (!Number.isFinite(cost) || cost < 0) return res.status(400).json({ success: false, error: 'Cost price must be a valid non-negative number' });
    if (!Number.isFinite(sell) || sell < 0) return res.status(400).json({ success: false, error: 'Selling price must be a valid non-negative number' });
    if (!Number.isInteger(stock) || stock < 0) return res.status(400).json({ success: false, error: 'Stock quantity must be a valid non-negative whole number' });
    if (!Number.isInteger(threshold) || threshold < 0) return res.status(400).json({ success: false, error: 'Low stock threshold must be a valid non-negative whole number' });

    // If class/subject changed, make sure it doesn't collide with a different existing row
    if (cls !== existing.class || subject !== existing.subject) {
      const collision = await query('SELECT id FROM notes_catalog WHERE class = ? AND subject = ? AND id != ?', [cls, subject, id]);
      if (collision.length) {
        return res.status(409).json({ success: false, error: `${subject} for class ${cls} already exists in the catalog.` });
      }
    }

    await run(
      'UPDATE notes_catalog SET class = ?, subject = ?, cost_price = ?, selling_price = ?, stock_qty = ?, low_stock_threshold = ? WHERE id = ?',
      [cls, subject, cost, sell, stock, threshold, id]
    );

    // Log to audit trail whenever stock actually changed via this form.
    if (stock !== existing.stock_qty) {
      await run(
        `INSERT INTO stock_adjustments (catalog_id, class, subject, change_qty, stock_before, stock_after, reason, note)
         VALUES (?, ?, ?, ?, ?, ?, 'edit', 'Changed via Inventory edit form')`,
        [id, cls, subject, stock - existing.stock_qty, existing.stock_qty, stock]
      );
    }

    const rows = await query('SELECT * FROM notes_catalog WHERE id = ?', [id]);
    res.json({ success: true, item: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/catalog/:id/adjust — explicit stock adjustment with a reason (damaged, recount, return, other)
// body: { change_qty: number (can be negative), reason: string, note: string }
router.post('/catalog/:id/adjust', async (req, res) => {
  try {
    const { id } = req.params;
    const rows = await query('SELECT * FROM notes_catalog WHERE id = ?', [id]);
    if (!rows.length) return res.status(404).json({ success: false, error: 'Catalog item not found' });
    const cat = rows[0];

    const changeQty = Number(req.body.change_qty);
    if (!Number.isInteger(changeQty) || changeQty === 0) {
      return res.status(400).json({ success: false, error: 'Change quantity must be a non-zero whole number (positive to add, negative to remove).' });
    }
    const validReasons = ['damaged', 'recount', 'return', 'other'];
    const reason = validReasons.includes(req.body.reason) ? req.body.reason : 'other';
    const note = (req.body.note || '').trim();

    const newStock = cat.stock_qty + changeQty;
    if (newStock < 0) {
      return res.status(400).json({ success: false, error: `Cannot reduce stock below 0 (current: ${cat.stock_qty}).` });
    }

    await run('UPDATE notes_catalog SET stock_qty = ? WHERE id = ?', [newStock, id]);
    await run(
      `INSERT INTO stock_adjustments (catalog_id, class, subject, change_qty, stock_before, stock_after, reason, note)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [id, cat.class, cat.subject, changeQty, cat.stock_qty, newStock, reason, note]
    );

    const updated = await query('SELECT * FROM notes_catalog WHERE id = ?', [id]);
    res.json({ success: true, item: updated[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/catalog/:id/adjustments — audit trail for one catalog item
router.get('/catalog/:id/adjustments', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM stock_adjustments WHERE catalog_id = ? ORDER BY created_at DESC', [req.params.id]);
    res.json({ success: true, adjustments: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/adjustments — full audit trail across all catalog items (for export / review)
router.get('/adjustments', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM stock_adjustments ORDER BY created_at DESC', []);
    res.json({ success: true, adjustments: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/notes/catalog/:id
router.delete('/catalog/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await run('DELETE FROM notes_catalog WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── helper: load a sale + its items + its payment history ─────────────────
async function loadSaleFull(id) {
  const saleRows = await query('SELECT * FROM sales WHERE id = ?', [id]);
  if (!saleRows.length) return null;
  const sale = saleRows[0];
  const items = await query('SELECT * FROM sale_items WHERE sale_id = ? ORDER BY id', [id]);
  const payments = await query('SELECT * FROM payments WHERE sale_id = ? ORDER BY created_at', [id]);
  return { ...sale, items, payments };
}

async function getVccName() {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'vcc_name'", []);
    return rows.length ? rows[0].value : 'Vectors Coaching Centre';
  } catch (e) {
    return 'Vectors Coaching Centre';
  }
}

async function getContact() {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'contact'", []);
    return rows.length ? rows[0].value : '';
  } catch (e) {
    return '';
  }
}

// ══════════════════════════════════════════════════════════════════════
// SELL (POS)
// ══════════════════════════════════════════════════════════════════════

// POST /api/notes/sales  — create a sale (or lumpsum issuance)
// body: {
//   sale_type: 'sale' | 'lumpsum',
//   customer_type: 'VCCIAN' | 'OUTSIDER',
//   student_id: number|null, customer_name, customer_phone, class,
//   items: [{ catalog_id, qty }],
//   amount_paid: number,          // ignored (forced 0) for lumpsum
//   allow_negative_stock: bool    // optional override for out-of-stock sells
// }
router.post('/sales', async (req, res) => {
  try {
    const {
      sale_type, customer_type, student_id, customer_name, customer_phone,
      class: cls, items, amount_paid, allow_negative_stock
    } = req.body;

    const isLumpsum = sale_type === 'lumpsum';
    const custType = customer_type === 'VCCIAN' ? 'VCCIAN' : 'OUTSIDER';

    if (!Array.isArray(items) || !items.length) {
      return res.status(400).json({ success: false, error: 'Cart is empty — add at least one item.' });
    }
    for (const it of items) {
      if (!it.catalog_id || !Number.isInteger(Number(it.qty)) || Number(it.qty) <= 0) {
        return res.status(400).json({ success: false, error: 'Each cart item needs a valid catalog_id and a positive whole quantity.' });
      }
    }
    if (custType === 'VCCIAN' && student_id) {
      const stuRows = await query('SELECT id FROM students WHERE id = ?', [student_id]);
      if (!stuRows.length) return res.status(400).json({ success: false, error: 'Selected student not found.' });
    }

    // Load catalog rows for every cart item, lock in price/cost snapshots.
    const catalogIds = items.map(it => Number(it.catalog_id));
    const placeholders = catalogIds.map(() => '?').join(',');
    const catalogRows = await query(`SELECT * FROM notes_catalog WHERE id IN (${placeholders})`, catalogIds);
    const catalogById = {};
    catalogRows.forEach(r => { catalogById[r.id] = r; });

    const lineItems = [];
    let total = 0;
    for (const it of items) {
      const cat = catalogById[it.catalog_id];
      if (!cat) return res.status(400).json({ success: false, error: `Catalog item ${it.catalog_id} no longer exists.` });
      const qty = Number(it.qty);
      if (!allow_negative_stock && cat.stock_qty < qty) {
        return res.status(409).json({
          success: false,
          error: `Not enough stock for ${cat.subject} (Class ${cat.class}): have ${cat.stock_qty}, need ${qty}. Resubmit with an override to sell anyway.`,
          insufficient_stock: { catalog_id: cat.id, subject: cat.subject, class: cat.class, available: cat.stock_qty, requested: qty }
        });
      }
      const unitPrice = isLumpsum ? 0 : Number(cat.selling_price);
      const unitCost = isLumpsum ? 0 : Number(cat.cost_price); // lumpsum: no revenue, no profit/loss — stock still deducted
      lineItems.push({ catalog_id: cat.id, subject: cat.subject, class: cat.class, qty, unit_cost: unitCost, unit_price: unitPrice });
      total += unitPrice * qty;
    }
    total = Number(total.toFixed(2));

    let paid, due;
    if (isLumpsum) {
      paid = 0; due = 0;
    } else {
      paid = amount_paid === undefined || amount_paid === '' ? 0 : Number(amount_paid);
      if (!Number.isFinite(paid) || paid < 0) return res.status(400).json({ success: false, error: 'Amount paid must be a valid non-negative number.' });
      if (paid > total) paid = total; // cap — can't pay more than the total
      due = Number((total - paid).toFixed(2));
    }

    // Build one atomic batch: insert sale, insert items, deduct stock,
    // (optionally) insert the initial payment row.
    const statements = [];
    statements.push({
      sql: `INSERT INTO sales (sale_type, customer_type, student_id, customer_name, customer_phone, class, total_amount, amount_paid, amount_due)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: [
        isLumpsum ? 'lumpsum' : 'sale', custType, student_id || null,
        (customer_name || '').trim(), (customer_phone || '').trim(), (cls || '').trim(),
        total, paid, due
      ]
    });

    // batchRun doesn't give us the new sale's id mid-batch, so we run the
    // sale insert first on its own, then batch the rest against that id.
    const saleInsert = await run(statements[0].sql, statements[0].args);
    const saleId = saleInsert.lastInsertRowid;

    const followUp = [];
    for (const li of lineItems) {
      followUp.push({
        sql: `INSERT INTO sale_items (sale_id, catalog_id, subject, class, qty, unit_cost, unit_price) VALUES (?, ?, ?, ?, ?, ?, ?)`,
        args: [saleId, li.catalog_id, li.subject, li.class, li.qty, li.unit_cost, li.unit_price]
      });
      followUp.push({
        sql: `UPDATE notes_catalog SET stock_qty = stock_qty - ? WHERE id = ?`,
        args: [li.qty, li.catalog_id]
      });
    }
    if (paid > 0) {
      followUp.push({
        sql: `INSERT INTO payments (sale_id, amount, note) VALUES (?, ?, ?)`,
        args: [saleId, paid, isLumpsum ? '' : 'Initial payment at sale']
      });
    }
    await batchRun(followUp);

    const full = await loadSaleFull(saleId);
    res.json({ success: true, sale: full });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/sales/:id — full sale detail (for reprint / view)
router.get('/sales/:id', async (req, res) => {
  try {
    const full = await loadSaleFull(req.params.id);
    if (!full) return res.status(404).json({ success: false, error: 'Sale not found' });
    res.json({ success: true, sale: full });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/sales?limit=20 — recent sales (for reprint lookup)
router.get('/sales', async (req, res) => {
  try {
    const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 200);
    const rows = await query('SELECT * FROM sales ORDER BY id DESC LIMIT ?', [limit]);
    res.json({ success: true, sales: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/sales/:id/slip — build printable slip data + attempt print
// Always returns the slip data (frontend needs it for the browser-preview
// modal regardless). Also attempts to send it straight to the configured
// thermal printer; print_result tells the frontend whether that worked so
// it can skip prompting for a browser print dialog when it already printed.
router.get('/sales/:id/slip', async (req, res) => {
  try {
    const full = await loadSaleFull(req.params.id);
    if (!full) return res.status(404).json({ success: false, error: 'Sale not found' });
    const [vccName, contact] = await Promise.all([getVccName(), getContact()]);
    const slip = buildSlipData(full, full.items, vccName, contact);
    const printResult = await printSlip(slip);
    res.json({ success: true, slip, print_result: printResult });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/sales/:id/void — void a sale: reverses stock, marks cancelled, kept for audit
// body: { reason: string (optional) }
router.post('/sales/:id/void', async (req, res) => {
  try {
    const saleRows = await query('SELECT * FROM sales WHERE id = ?', [req.params.id]);
    if (!saleRows.length) return res.status(404).json({ success: false, error: 'Sale not found' });
    const sale = saleRows[0];
    if (sale.voided) return res.status(400).json({ success: false, error: 'Sale is already voided.' });

    const items = await query('SELECT * FROM sale_items WHERE sale_id = ?', [sale.id]);
    const reason = (req.body && req.body.reason ? String(req.body.reason) : '').trim();

    // Snapshot current stock for every affected catalog row so we can log accurate before/after.
    const catalogIds = items.filter(it => it.catalog_id).map(it => it.catalog_id);
    const catalogById = {};
    if (catalogIds.length) {
      const placeholders = catalogIds.map(() => '?').join(',');
      const catRows = await query(`SELECT * FROM notes_catalog WHERE id IN (${placeholders})`, catalogIds);
      catRows.forEach(r => { catalogById[r.id] = r; });
    }

    const statements = [];
    // Reverse stock for every line item still linked to a live catalog row.
    for (const it of items) {
      if (it.catalog_id && catalogById[it.catalog_id]) {
        const cat = catalogById[it.catalog_id];
        statements.push({
          sql: `UPDATE notes_catalog SET stock_qty = stock_qty + ? WHERE id = ?`,
          args: [it.qty, it.catalog_id]
        });
        statements.push({
          sql: `INSERT INTO stock_adjustments (catalog_id, class, subject, change_qty, stock_before, stock_after, reason, note)
                VALUES (?, ?, ?, ?, ?, ?, 'other', ?)`,
          args: [it.catalog_id, cat.class, cat.subject, it.qty, cat.stock_qty, cat.stock_qty + it.qty, `Voided sale #${sale.id}${reason ? ' — ' + reason : ''}`]
        });
      }
    }
    statements.push({
      sql: `UPDATE sales SET voided = 1, voided_at = CURRENT_TIMESTAMP, void_reason = ? WHERE id = ?`,
      args: [reason, sale.id]
    });
    await batchRun(statements);

    const full = await loadSaleFull(sale.id);
    res.json({ success: true, sale: full });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════
// PENDING (credit sales) + payments
// ══════════════════════════════════════════════════════════════════════

// GET /api/notes/pending — all sales with amount_due > 0
router.get('/pending', async (req, res) => {
  try {
    const sales = await query(
      `SELECT * FROM sales WHERE sale_type = 'sale' AND amount_due > 0 AND voided = 0 ORDER BY created_at DESC`, []
    );
    if (!sales.length) return res.json({ success: true, pending: [] });
    const ids = sales.map(s => s.id);
    const placeholders = ids.map(() => '?').join(',');
    const items = await query(`SELECT * FROM sale_items WHERE sale_id IN (${placeholders})`, ids);
    const itemsBySale = {};
    items.forEach(it => { (itemsBySale[it.sale_id] = itemsBySale[it.sale_id] || []).push(it); });
    const pending = sales.map(s => ({ ...s, items: itemsBySale[s.id] || [] }));
    res.json({ success: true, pending });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/pending/:saleId/payments — record a payment against a sale
// body: { amount, note }
router.post('/pending/:saleId/payments', async (req, res) => {
  try {
    const { saleId } = req.params;
    const { amount, note } = req.body;
    const amt = Number(amount);
    if (!Number.isFinite(amt) || amt <= 0) return res.status(400).json({ success: false, error: 'Payment amount must be a valid positive number.' });

    const saleRows = await query('SELECT * FROM sales WHERE id = ?', [saleId]);
    if (!saleRows.length) return res.status(404).json({ success: false, error: 'Sale not found' });
    const sale = saleRows[0];

    if (amt > sale.amount_due) {
      return res.status(400).json({ success: false, error: `Payment of Rs ${amt.toFixed(2)} exceeds amount due (Rs ${Number(sale.amount_due).toFixed(2)}).` });
    }

    const newPaid = Number((Number(sale.amount_paid) + amt).toFixed(2));
    const newDue = Number((Number(sale.amount_due) - amt).toFixed(2));

    await batchRun([
      { sql: `INSERT INTO payments (sale_id, amount, note) VALUES (?, ?, ?)`, args: [saleId, amt, (note || '').trim()] },
      { sql: `UPDATE sales SET amount_paid = ?, amount_due = ? WHERE id = ?`, args: [newPaid, newDue, saleId] }
    ]);

    const full = await loadSaleFull(saleId);
    res.json({ success: true, sale: full });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/pending/:saleId/payments — payment history for one sale
router.get('/pending/:saleId/payments', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM payments WHERE sale_id = ? ORDER BY created_at', [req.params.saleId]);
    res.json({ success: true, payments: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════
// DEMAND
// ══════════════════════════════════════════════════════════════════════

// GET /api/notes/demand — all demand entries, newest first
router.get('/demand', async (req, res) => {
  try {
    const rows = await query('SELECT * FROM demand_log ORDER BY requested_at DESC', []);
    res.json({ success: true, demand: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/demand/summary — restock signal: pending demand grouped by
// class+subject (highest total qty first), plus any catalog items that are
// low on stock or out of stock even with no logged demand. Rows carry a
// `source` field: 'demand' (has pending customer requests), 'stock' (low/out
// of stock only, no pending demand), or 'both'.
router.get('/demand/summary', async (req, res) => {
  try {
    const demandRows = await query(
      `SELECT class, subject, SUM(qty_wanted) AS total_qty, COUNT(*) AS entry_count
       FROM demand_log WHERE status = 'pending'
       GROUP BY class, subject`, []
    );
    const lowStockRows = await query(
      `SELECT class, subject, stock_qty, low_stock_threshold
       FROM notes_catalog WHERE stock_qty <= low_stock_threshold`, []
    );

    const key = (cls, subj) => `${cls}::${subj}`;
    const merged = new Map();

    for (const d of demandRows) {
      merged.set(key(d.class, d.subject), {
        class: d.class, subject: d.subject,
        total_qty: d.total_qty, entry_count: d.entry_count,
        stock_qty: null, low_stock_threshold: null,
        source: 'demand'
      });
    }
    for (const s of lowStockRows) {
      const k = key(s.class, s.subject);
      const existing = merged.get(k);
      if (existing) {
        existing.stock_qty = s.stock_qty;
        existing.low_stock_threshold = s.low_stock_threshold;
        existing.source = 'both';
      } else {
        merged.set(k, {
          class: s.class, subject: s.subject,
          total_qty: 0, entry_count: 0,
          stock_qty: s.stock_qty, low_stock_threshold: s.low_stock_threshold,
          source: 'stock'
        });
      }
    }

    // Highest pending demand first, then lowest stock first, then name.
    const rows = [...merged.values()].sort((a, b) =>
      b.total_qty - a.total_qty ||
      (a.stock_qty ?? Infinity) - (b.stock_qty ?? Infinity) ||
      a.subject.localeCompare(b.subject)
    );

    res.json({ success: true, summary: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/demand — add a demand entry
// body: { customer_name, customer_phone, class, subject, qty_wanted }
router.post('/demand', async (req, res) => {
  try {
    const { customer_name, customer_phone, class: cls, subject, qty_wanted } = req.body;
    if (!cls || !String(cls).trim()) return res.status(400).json({ success: false, error: 'Class is required' });
    if (!subject || !String(subject).trim()) return res.status(400).json({ success: false, error: 'Subject is required' });
    const qty = qty_wanted === undefined || qty_wanted === '' ? 1 : Number(qty_wanted);
    if (!Number.isInteger(qty) || qty <= 0) return res.status(400).json({ success: false, error: 'Quantity wanted must be a positive whole number.' });

    const result = await run(
      `INSERT INTO demand_log (customer_name, customer_phone, class, subject, qty_wanted, status) VALUES (?, ?, ?, ?, ?, 'pending')`,
      [(customer_name || '').trim(), (customer_phone || '').trim(), cls.trim(), subject.trim(), qty]
    );
    const rows = await query('SELECT * FROM demand_log WHERE id = ?', [result.lastInsertRowid]);
    res.json({ success: true, entry: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PUT /api/notes/demand/:id — update status (mark fulfilled) or fields
router.put('/demand/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const existingRows = await query('SELECT * FROM demand_log WHERE id = ?', [id]);
    if (!existingRows.length) return res.status(404).json({ success: false, error: 'Demand entry not found' });
    const existing = existingRows[0];

    const status = req.body.status !== undefined ? req.body.status : existing.status;
    if (status !== 'pending' && status !== 'fulfilled') {
      return res.status(400).json({ success: false, error: "Status must be 'pending' or 'fulfilled'." });
    }
    const qty = req.body.qty_wanted !== undefined ? Number(req.body.qty_wanted) : existing.qty_wanted;
    if (!Number.isInteger(qty) || qty <= 0) return res.status(400).json({ success: false, error: 'Quantity wanted must be a positive whole number.' });

    await run(
      `UPDATE demand_log SET status = ?, qty_wanted = ?, customer_name = ?, customer_phone = ? WHERE id = ?`,
      [
        status, qty,
        req.body.customer_name !== undefined ? req.body.customer_name.trim() : existing.customer_name,
        req.body.customer_phone !== undefined ? req.body.customer_phone.trim() : existing.customer_phone,
        id
      ]
    );
    const rows = await query('SELECT * FROM demand_log WHERE id = ?', [id]);
    res.json({ success: true, entry: rows[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/notes/demand/:id
router.delete('/demand/:id', async (req, res) => {
  try {
    await run('DELETE FROM demand_log WHERE id = ?', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ══════════════════════════════════════════════════════════════════════
// LUMPSUM (view) — issuance itself happens through POST /sales with
// sale_type: 'lumpsum'
// ══════════════════════════════════════════════════════════════════════

// GET /api/notes/lumpsum — all lumpsum issuances, newest first, with items
router.get('/lumpsum', async (req, res) => {
  try {
    const sales = await query(`SELECT * FROM sales WHERE sale_type = 'lumpsum' ORDER BY created_at DESC`, []);
    if (!sales.length) return res.json({ success: true, lumpsum: [] });
    const ids = sales.map(s => s.id);
    const placeholders = ids.map(() => '?').join(',');
    const items = await query(`SELECT * FROM sale_items WHERE sale_id IN (${placeholders})`, ids);
    const itemsBySale = {};
    items.forEach(it => { (itemsBySale[it.sale_id] = itemsBySale[it.sale_id] || []).push(it); });
    const lumpsum = sales.map(s => ({ ...s, items: itemsBySale[s.id] || [] }));
    res.json({ success: true, lumpsum });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/lumpsum/by-student — grouped by student (or free-text name), class-wise
router.get('/lumpsum/by-student', async (req, res) => {
  try {
    const sales = await query(`SELECT * FROM sales WHERE sale_type = 'lumpsum' ORDER BY class, customer_name`, []);
    if (!sales.length) return res.json({ success: true, groups: [] });
    const ids = sales.map(s => s.id);
    const placeholders = ids.map(() => '?').join(',');
    const items = await query(`SELECT * FROM sale_items WHERE sale_id IN (${placeholders})`, ids);
    const itemsBySale = {};
    items.forEach(it => { (itemsBySale[it.sale_id] = itemsBySale[it.sale_id] || []).push(it); });

    const groupKey = s => (s.student_id ? `student:${s.student_id}` : `name:${s.customer_name}|${s.class}`);
    const groups = {};
    for (const s of sales) {
      const key = groupKey(s);
      if (!groups[key]) {
        groups[key] = { student_id: s.student_id, customer_name: s.customer_name, class: s.class, issuances: [] };
      }
      groups[key].issuances.push({ ...s, items: itemsBySale[s.id] || [] });
    }
    res.json({ success: true, groups: Object.values(groups) });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/lumpsum/search-students?q=... — search enrolled students by
// name or GR number, for flagging as lumpsum. Excludes already-flagged ones.
router.get('/lumpsum/search-students', async (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ success: true, students: [] });
    const like = `%${q}%`;
    const students = await query(
      `SELECT id, student_uid, name, class, gr_number, admission_date, is_lumpsum
       FROM students
       WHERE (name LIKE ? OR gr_number LIKE ?) AND (status = 'active' OR status IS NULL OR status = '')
       ORDER BY class, name LIMIT 25`,
      [like, like]
    );
    res.json({ success: true, students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/notes/lumpsum/flag/:studentId — flag/unflag an enrolled student
// as lumpsum. body: { flag: true|false }. Just a tag — does NOT issue notes.
router.post('/lumpsum/flag/:studentId', async (req, res) => {
  try {
    const id = req.params.studentId;
    const flag = req.body.flag !== false; // default true
    const existing = await query('SELECT id FROM students WHERE id = ?', [id]);
    if (!existing.length) return res.status(404).json({ success: false, error: 'Student not found.' });
    await run('UPDATE students SET is_lumpsum = ? WHERE id = ?', [flag ? 1 : 0, id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/lumpsum/flagged — flagged (is_lumpsum) students, class-wise,
// each with their lumpsum note-issuance history (subject + date), for the
// list below the flag-search box. No student_id link needed on the sale row
// for this — issuance is looked up by matching name+class as a fallback too,
// since older issuances may have been entered as free text before flagging.
router.get('/lumpsum/flagged', async (req, res) => {
  try {
    const students = await query(
      `SELECT id, student_uid, name, class, gr_number, admission_date
       FROM students WHERE is_lumpsum = 1 ORDER BY class, name`, []
    );
    if (!students.length) return res.json({ success: true, students: [] });

    const ids = students.map(s => s.id);
    const placeholders = ids.map(() => '?').join(',');
    const sales = await query(
      `SELECT * FROM sales WHERE sale_type = 'lumpsum' AND student_id IN (${placeholders}) ORDER BY created_at`,
      ids
    );
    const saleIds = sales.map(s => s.id);
    let itemsBySale = {};
    if (saleIds.length) {
      const iph = saleIds.map(() => '?').join(',');
      const items = await query(`SELECT * FROM sale_items WHERE sale_id IN (${iph})`, saleIds);
      items.forEach(it => { (itemsBySale[it.sale_id] = itemsBySale[it.sale_id] || []).push(it); });
    }
    const salesByStudent = {};
    sales.forEach(s => { (salesByStudent[s.student_id] = salesByStudent[s.student_id] || []).push(s); });

    const result = students.map(s => ({
      ...s,
      entries: (salesByStudent[s.id] || []).map(sale => ({
        date: sale.created_at,
        items: (itemsBySale[sale.id] || []).map(it => ({ subject: it.subject, qty: it.qty }))
      }))
    }));
    res.json({ success: true, students: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/reports/summary?from=YYYY-MM-DD&to=YYYY-MM-DD
// Sales + profit totals bucketed per day, from sale_items (price/cost
// snapshots), so historical reports stay accurate after catalog price
// changes. Lumpsum items always contribute 0 profit/revenue since
// unit_price is forced to 0 at issuance time. from/to optional — when
// omitted, all-time data returned.
router.get('/reports/summary', async (req, res) => {
  try {
    const from = parseDateParam(req.query.from);
    const to = parseDateParam(req.query.to);
    const cls = req.query.class && String(req.query.class).trim() ? String(req.query.class).trim() : null;

    const where = ["s.voided = 0"];
    const params = [];
    if (from) { where.push("date(s.created_at) >= ?"); params.push(from); }
    if (to) { where.push("date(s.created_at) <= ?"); params.push(to); }
    if (cls) { where.push("si.class = ?"); params.push(cls); }
    const whereClause = `WHERE ${where.join(' AND ')}`;

    const rows = await query(
      `SELECT date(s.created_at) AS bucket,
              SUM(si.unit_price * si.qty) AS revenue,
              SUM((si.unit_price - si.unit_cost) * si.qty) AS profit,
              SUM(si.qty) AS units_sold
       FROM sale_items si
       JOIN sales s ON s.id = si.sale_id
       ${whereClause}
       GROUP BY bucket ORDER BY bucket DESC`, params
    );
    res.json({ success: true, from, to, class: cls, rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/reports/breakdown?by=subject|class&from=YYYY-MM-DD&to=YYYY-MM-DD&class=X
router.get('/reports/breakdown', async (req, res) => {
  try {
    const by = req.query.by === 'class' ? 'class' : 'subject';
    const from = parseDateParam(req.query.from);
    const to = parseDateParam(req.query.to);
    const cls = req.query.class && String(req.query.class).trim() ? String(req.query.class).trim() : null;

    const where = ["s.voided = 0"];
    const params = [];
    if (from) { where.push("date(s.created_at) >= ?"); params.push(from); }
    if (to) { where.push("date(s.created_at) <= ?"); params.push(to); }
    if (cls) { where.push("si.class = ?"); params.push(cls); }
    const whereClause = `WHERE ${where.join(' AND ')}`;

    const rows = await query(
      `SELECT si.${by} AS label,
              SUM(si.unit_price * si.qty) AS revenue,
              SUM((si.unit_price - si.unit_cost) * si.qty) AS profit,
              SUM(si.qty) AS units_sold
       FROM sale_items si
       JOIN sales s ON s.id = si.sale_id
       ${whereClause}
       GROUP BY si.${by} ORDER BY revenue DESC`, params
    );
    res.json({ success: true, by, from, to, class: cls, rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/reports/sales-detail?from=YYYY-MM-DD&to=YYYY-MM-DD&class=X
// Full itemized sales list for printable reports — one row per sale_item,
// with the parent sale's customer/date/payment info alongside it.
router.get('/reports/sales-detail', async (req, res) => {
  try {
    const from = parseDateParam(req.query.from);
    const to = parseDateParam(req.query.to);
    const cls = req.query.class && String(req.query.class).trim() ? String(req.query.class).trim() : null;

    const where = ["s.voided = 0"];
    const params = [];
    if (from) { where.push("date(s.created_at) >= ?"); params.push(from); }
    if (to) { where.push("date(s.created_at) <= ?"); params.push(to); }
    if (cls) { where.push("si.class = ?"); params.push(cls); }
    const whereClause = `WHERE ${where.join(' AND ')}`;

    const rows = await query(
      `SELECT s.id AS sale_id, s.created_at, s.customer_name, s.customer_type,
              s.sale_type, s.amount_paid, s.amount_due,
              si.class, si.subject, si.qty, si.unit_price, si.unit_cost,
              (si.unit_price * si.qty) AS line_revenue,
              ((si.unit_price - si.unit_cost) * si.qty) AS line_profit
       FROM sale_items si
       JOIN sales s ON s.id = si.sale_id
       ${whereClause}
       ORDER BY s.created_at ASC, s.id ASC, si.id ASC`, params
    );
    res.json({ success: true, from, to, class: cls, rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/notes/reports/totals?from=YYYY-MM-DD&to=YYYY-MM-DD — inclusive sale-date totals
router.get('/reports/totals', async (req, res) => {
  try {
    const from = parseDateParam(req.query.from);
    const to = parseDateParam(req.query.to);
    if ((req.query.from && !from) || (req.query.to && !to) || (from && to && from > to)) {
      return res.status(400).json({ success: false, error: 'Provide valid dates with From on or before To.' });
    }
    const where = ['s.voided = 0'];
    const params = [];
    if (from) { where.push('date(s.created_at) >= ?'); params.push(from); }
    if (to) { where.push('date(s.created_at) <= ?'); params.push(to); }
    const whereClause = 'WHERE ' + where.join(' AND ');
    const rows = await query(
      `SELECT SUM(si.unit_price * si.qty) AS revenue,
              SUM((si.unit_price - si.unit_cost) * si.qty) AS profit,
              SUM(si.qty) AS units_sold
       FROM sale_items si
       JOIN sales s ON s.id = si.sale_id
       ${whereClause}`, params
    );
    const pendingRows = await query(`SELECT COALESCE(SUM(s.amount_due),0) AS total_due FROM sales s ${whereClause} AND s.sale_type='sale' AND s.amount_due > 0`, params);
    const collectedRows = await query(`SELECT COALESCE(SUM(s.amount_paid),0) AS collected FROM sales s ${whereClause} AND s.sale_type='sale'`, params);
    res.json({
      success: true,
      totals: {
        revenue: rows[0].revenue || 0,       // billed value (sale_items unit_price*qty) — includes unpaid/due amounts
        collected: collectedRows[0].collected || 0, // actual cash received (sales.amount_paid) — excludes due
        profit: rows[0].profit || 0,
        units_sold: rows[0].units_sold || 0,
        total_due: pendingRows[0].total_due || 0
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;