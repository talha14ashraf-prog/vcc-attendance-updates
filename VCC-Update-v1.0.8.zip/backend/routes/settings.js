const express = require('express');
const router = express.Router();
const { query, run } = require('../database');
const multer = require('multer');
const path = require('path');
const fs = require('fs');

const upload = multer({
  dest: path.join(__dirname, '../../frontend/assets/'),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB max — prevents disk fill from large uploads
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only image files are allowed'));
  }
});

// Get all settings
router.get('/', async (req, res) => {
  try {
    const settings = await query('SELECT * FROM settings');
    const map = {};
    settings.forEach(s => map[s.key] = s.value);
    res.json({ success: true, settings: map });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update settings
router.post('/update', async (req, res) => {
  try {
    const allowed = [
      'in_message', 'out_message', 'absent_message', 'contact', 'vcc_name', 'qr_x', 'qr_y', 'qr_size',
      'vcc_phone1', 'vcc_phone2', 'vcc_address', 'classes', 'sections', 'groups', 'sessions', 'campus', 'genders',
      'report_caption', 'group_subjects', 'exam_absent_message', 'marks_message',
      'attendance_channel', 'sms_gateway_url', 'sms_gateway_user', 'sms_gateway_password', 'update_repository',
      'sms_in_message', 'sms_out_message', 'message_channel_absent', 'message_channel_marks', 'message_channel_test_plan', 'message_channel_pdf', 'message_channel_other', 'sms_public_url'
    ];
    // Run all writes in parallel instead of one-by-one — each awaited write
    // was serializing (write -> wait -> write -> wait...), which is why a
    // save with several changed fields felt slow. They all hit the same
    // local file so this is safe and just as consistent.
    if (req.body.attendance_channel && !['sms','whatsapp'].includes(req.body.attendance_channel)) throw new Error('Invalid attendance channel');
    if (req.body.update_repository !== undefined && !/^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(String(req.body.update_repository).trim())) throw new Error('GitHub repository must be written as owner/repository');
    if (req.body.attendance_channel === 'sms') {
      const current = await require('../sms').settings();
      require('../sms').validate({ ...current, ...req.body });
      if (!req.body.sms_in_message?.trim() || !req.body.sms_out_message?.trim()) throw new Error('Both SMS templates are required');
    }
    for (const key of allowed.filter(k => k.startsWith('message_channel_'))) {
      if (req.body[key] !== undefined && !['sms','whatsapp',''].includes(req.body[key])) throw new Error('Invalid message channel');
    }
    const writes = allowed
      .filter(key => req.body[key] !== undefined)
      .map(key => run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, req.body[key]]));
    await Promise.all(writes);
    if (req.body.attendance_channel === 'whatsapp') {
      require('../whatsapp').initWhatsApp().catch(() => {});
    }
    res.json({ success: true, message: 'Settings saved successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Upload ID card template image
router.post('/upload-template', upload.single('template'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'No file uploaded' });
    const newPath = path.join(__dirname, '../../frontend/assets/id-template.png');
    fs.renameSync(req.file.path, newPath);
    res.json({ success: true, message: 'Template uploaded successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Upload VCC logo (used in PDF reports)
router.post('/upload-logo', upload.single('logo'), (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ success: false, error: 'No file uploaded' });
    const newPath = path.join(__dirname, '../../frontend/assets/logo.png');
    fs.renameSync(req.file.path, newPath);
    res.json({ success: true, message: 'Logo uploaded successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── ID Card Templates (stored as base64 in Turso — syncs across all PCs) ────
// GET  /api/settings/template?side=front|back
// POST /api/settings/template  { side, data }   (data = base64 dataURL)
// DEL  /api/settings/template?side=front|back

router.get('/template', async (req, res) => {
  try {
    const side = req.query.side === 'back' ? 'back' : 'front';
    const rows = await query("SELECT value FROM settings WHERE key = ?", ['card_tpl_' + side]);
    const data = rows.length ? rows[0].value : null;
    res.json({ success: true, data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/template', async (req, res) => {
  try {
    const { side, data } = req.body;
    if (!side || !data) return res.status(400).json({ success: false, error: 'side and data required' });
    if (side !== 'front' && side !== 'back') return res.status(400).json({ success: false, error: 'side must be front or back' });
    if (data.length > 8 * 1024 * 1024) return res.status(400).json({ success: false, error: 'Image too large (max 6MB)' });
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", ['card_tpl_' + side, data]);
    res.json({ success: true, message: 'Template saved to cloud' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.delete('/template', async (req, res) => {
  try {
    const side = req.query.side === 'back' ? 'back' : 'front';
    await run("DELETE FROM settings WHERE key = ?", ['card_tpl_' + side]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── ID Card Field Positions (stored in Turso — syncs across all PCs) ─────────
// GET  /api/settings/template-positions?side=front|back
// POST /api/settings/template-positions  { side, positions }

router.get('/template-positions', async (req, res) => {
  try {
    const side = req.query.side === 'back' ? 'back' : 'front';
    const rows = await query("SELECT value FROM settings WHERE key = ?", ['card_pos_' + side]);
    let positions = {};
    if (rows.length && rows[0].value) {
      try { positions = JSON.parse(rows[0].value); } catch(e) {}
    }
    res.json({ success: true, positions });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/template-positions', async (req, res) => {
  try {
    const { side, positions } = req.body;
    if (!side) return res.status(400).json({ success: false, error: 'side required' });
    if (side !== 'front' && side !== 'back') return res.status(400).json({ success: false, error: 'side must be front or back' });
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", ['card_pos_' + side, JSON.stringify(positions || {})]);
    res.json({ success: true, message: 'Positions saved to cloud' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Absent Schedule ──────────────────────────────────────────────────────────
// GET  /api/settings/absent-schedule  → returns array of slots
// POST /api/settings/absent-schedule  → saves array of slots
router.get('/absent-schedule', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'absent_schedule'");
    let schedule = [];
    if (rows.length && rows[0].value) {
      try { schedule = JSON.parse(rows[0].value); } catch(e) {}
    }
    res.json({ success: true, schedule });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/absent-schedule', async (req, res) => {
  try {
    const { schedule } = req.body;
    if (!Array.isArray(schedule)) {
      return res.status(400).json({ success: false, error: 'schedule must be an array' });
    }
    const VALID_DAYS = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const clean = schedule
      .filter(s => s.class && s.time && /^\d{2}:\d{2}$/.test(s.time))
      .map(s => ({
        class: s.class.trim(),
        section: (s.section || '').trim(),
        time: s.time,
        days: Array.isArray(s.days) ? s.days.filter(d => VALID_DAYS.includes(d)) : []
      }));
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES ('absent_schedule', ?)", [JSON.stringify(clean)]);
    res.json({ success: true, message: 'Absent schedule saved', schedule: clean });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Freeze / Unfreeze Students ───────────────────────────────────────────────
// GET  /api/settings/freeze-search?q=...  → search students by name or GR
// POST /api/settings/freeze               → { uid, freeze: true/false, reason? }

router.get('/freeze-search', async (req, res) => {
  try {
    const q = (req.query.q || '').trim();
    if (!q) return res.json({ success: true, students: [] });
    const like = '%' + q + '%';
    const students = await query(
      `SELECT id, student_uid, name, class, section, gr_number, roll_no, father_name,
              status, is_frozen, freeze_reason
       FROM students
       WHERE (name LIKE ? OR gr_number LIKE ? OR roll_no LIKE ?)
         AND (status IS NULL OR status != 'inactive')
       ORDER BY class, name
       LIMIT 20`,
      [like, like, like]
    );
    res.json({ success: true, students });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/freeze', async (req, res) => {
  try {
    const { uid, freeze, reason } = req.body;
    if (!uid) return res.status(400).json({ success: false, error: 'uid required' });
    const student = await query('SELECT * FROM students WHERE student_uid = ?', [uid]);
    if (!student.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const isFrozen = freeze ? 1 : 0;
    await run('UPDATE students SET is_frozen = ?, freeze_reason = ? WHERE student_uid = ?',
      [isFrozen, reason || '', uid]);
    res.json({
      success: true,
      message: freeze
        ? `${student[0].name} has been frozen (defaulter).`
        : `${student[0].name} has been unfrozen. Attendance will now be marked.`
    });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Teacher ↔ Subject/Class/Section Mapping ──────────────────────────────────
// GET  /api/settings/teacher-map  → array of {class, section, subject, teacher, phone}
// POST /api/settings/teacher-map  → saves array
// GET /api/settings/group-subjects
router.get('/group-subjects', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'group_subjects'");
    const val = rows.length ? rows[0].value : '{}';
    let data = {};
    try { data = JSON.parse(val); } catch(e) {}
    res.json({ success: true, group_subjects: data });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/settings/group-subjects
router.post('/group-subjects', async (req, res) => {
  try {
    const data = req.body.group_subjects || {};
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES ('group_subjects', ?)", [JSON.stringify(data)]);
    res.json({ success: true });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/teacher-map', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'teacher_subject_map'");
    let map = [];
    if (rows.length && rows[0].value) {
      try { map = JSON.parse(rows[0].value); } catch(e) {}
    }
    res.json({ success: true, map });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.post('/teacher-map', async (req, res) => {
  try {
    const { map } = req.body;
    if (!Array.isArray(map)) {
      return res.status(400).json({ success: false, error: 'map must be an array' });
    }
    const clean = map
      .filter(m => m.class && m.subject && m.teacher && m.phone)
      .map(m => ({
        class: String(m.class).trim(),
        section: (m.section || '').trim(), // blank = applies to all sections of that class
        subject: String(m.subject).trim(),
        teacher: String(m.teacher).trim(),
        phone: String(m.phone).trim()
      }));
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES ('teacher_subject_map', ?)", [JSON.stringify(clean)]);
    res.json({ success: true, message: 'Teacher mapping saved', map: clean });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/sms-status', async (req,res) => {
  try { res.json({success:true, ...await require('../sms').overview()}); }
  catch (e) { res.status(500).json({success:false,error:e.message}); }
});
router.post('/sms-check', async (req,res) => {
  try {
    const sms = require('../sms');
    await sms.checkCredentials({...await sms.settings(), ...req.body});
    res.json({success:true});
  } catch(e) { res.status(400).json({success:false,error:e.message}); }
});
router.post('/sms-retry', async (req,res) => {
  try { await require('../sms').retryRejected(req.body.id); res.json({success:true}); }
  catch(e) { res.status(400).json({success:false,error:e.message}); }
});
module.exports = router;
