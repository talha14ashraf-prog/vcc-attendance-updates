const express = require('express');
const router = express.Router();
const { query, run } = require('../database');

// GET /api/holidays?year=2025&month=3  → list holidays for that month (or all if no params)
router.get('/', async (req, res) => {
  try {
    const { year, month } = req.query;
    let rows;
    if (year && month) {
      const prefix = `${year}-${String(month).padStart(2, '0')}-%`;
      rows = await query('SELECT * FROM holidays WHERE date LIKE ? ORDER BY date', [prefix]);
    } else {
      rows = await query('SELECT * FROM holidays ORDER BY date');
    }
    res.json({ success: true, holidays: rows });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/holidays  body: { date: 'YYYY-MM-DD', reason: '' }
router.post('/', async (req, res) => {
  try {
    const { date, reason = '' } = req.body;
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return res.status(400).json({ success: false, error: 'Invalid date. Use YYYY-MM-DD.' });
    }
    await run('INSERT OR IGNORE INTO holidays (date, reason) VALUES (?, ?)', [date, reason]);
    // If it already existed, update the reason
    await run('UPDATE holidays SET reason = ? WHERE date = ?', [reason, date]);
    const row = await query('SELECT * FROM holidays WHERE date = ?', [date])[0];
    res.json({ success: true, holiday: row });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/holidays/:id
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await run('DELETE FROM holidays WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;