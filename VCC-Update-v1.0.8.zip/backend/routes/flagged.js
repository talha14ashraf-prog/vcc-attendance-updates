const express = require('express');
const router = express.Router();
const { query, run, todayPKT } = require('../database');

// Fetch all holiday dates from DB into a Set for fast lookup.
// Called once per request — holidays rarely change mid-request.
async function getHolidaySet() {
  const rows = await query('SELECT date FROM holidays');
  return new Set(rows.map(r => r.date));
}

// Returns array of school days (Mon–Sat, non-holiday) going back N days from date (inclusive).
// Both Sundays and declared holidays are skipped — a student absent on Eid
// should not have that day counted toward their consecutive absent streak.
function getSchoolDaysBack(fromDateISO, count, holidaySet) {
  const days = [];
  let [y, m, d] = fromDateISO.split('-').map(Number);
  while (days.length < count) {
    const dateStr = `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const dow = new Date(dateStr + 'T12:00:00').getDay();
    if (dow !== 0 && !holidaySet.has(dateStr)) days.push(dateStr); // skip Sunday + holidays
    d--;
    if (d === 0) {
      m--;
      if (m === 0) { m = 12; y--; }
      d = new Date(y, m, 0).getDate();
    }
  }
  return days; // most recent first
}

// Count how many school days (Mon-Sat, non-holiday) exist from fromISO up to toISO inclusive.
// Used to cap streak at days-since-enrollment.
function schoolDaysBetween(fromISO, toISO, holidaySet) {
  let count = 0;
  let [y, m, d] = fromISO.split('-').map(Number);
  const end = new Date(`${toISO}T12:00:00`);
  while (true) {
    const dateStr = `${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    const cur = new Date(dateStr + 'T12:00:00');
    if (cur > end) break;
    if (cur.getDay() !== 0 && !holidaySet.has(dateStr)) count++;
    d++;
    const daysInMonth = new Date(y, m, 0).getDate();
    if (d > daysInMonth) { d = 1; m++; if (m > 12) { m = 1; y++; } }
  }
  return count;
}

// GET /api/flagged?threshold=3&class=IX-A
router.get('/', async (req, res) => {
  try {
    const threshold = Math.max(2, Math.min(30, parseInt(req.query.threshold) || 3));
    const cls = req.query.class || null;

    const todayISO = todayPKT();

    const LOOKBACK = 60;
    const holidaySet = await getHolidaySet();
    const windowDays = getSchoolDaysBack(todayISO, LOOKBACK, holidaySet);
    const oldest = windowDays[windowDays.length - 1];

    const students = cls
      ? await query("SELECT * FROM students WHERE class = ? AND (status IS NULL OR status != 'inactive') ORDER BY class, name", [cls])
      : await query("SELECT * FROM students WHERE (status IS NULL OR status != 'inactive') ORDER BY class, name");

    if (!students.length) return res.json({ success: true, flagged: [] });

    const uids = students.map(s => s.student_uid);
    const placeholders = uids.map(() => '?').join(',');

    const scanRows = await query(
      `SELECT student_uid, date(timestamp) as day
       FROM attendance
       WHERE type = 'IN'
         AND student_uid IN (${placeholders})
         AND date(timestamp) >= ?
       GROUP BY student_uid, day`,
      [...uids, oldest]
    );

    const scannedDays = {};
    uids.forEach(uid => { scannedDays[uid] = new Set(); });
    scanRows.forEach(r => {
      if (scannedDays[r.student_uid]) scannedDays[r.student_uid].add(r.day);
    });

    const lastSeenRows = await query(
      `SELECT student_uid, max(date(timestamp)) as last_day
       FROM attendance
       WHERE type = 'IN' AND student_uid IN (${placeholders})
       GROUP BY student_uid`,
      [...uids]
    );
    const lastSeen = {};
    lastSeenRows.forEach(r => { lastSeen[r.student_uid] = r.last_day; });

    const flagged = [];

    students.forEach(student => {
      const uid = student.student_uid;
      const scanned = scannedDays[uid];

      // Cap streak at school days since enrollment.
      // admission_date if filled, otherwise fall back to today
      // (new/unenrolled students start at 1 day absent max).
      const enrollDate = (student.admission_date && student.admission_date.match(/^\d{4}-\d{2}-\d{2}/))
        ? student.admission_date.slice(0, 10)
        : todayISO;
      const maxStreak = schoolDaysBetween(enrollDate, todayISO, holidaySet);

      let streak = 0;
      for (let i = 0; i < windowDays.length; i++) {
        if (streak >= maxStreak) break; // can't be absent longer than enrolled
        if (scanned.has(windowDays[i])) break;
        streak++;
      }

      if (streak >= threshold) {
        flagged.push({
          student_uid: uid,
          name: student.name,
          class: student.class,
          parent_phone: student.parent_phone,
          consecutive_absent: streak,
          last_seen: lastSeen[uid] || null
        });
      }
    });

    flagged.sort((a, b) => b.consecutive_absent - a.consecutive_absent || a.class.localeCompare(b.class));

    res.json({ success: true, flagged, generated_at: new Date().toISOString(), today: todayISO });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── GET /api/flagged/dead-numbers ────────────────────────────────────────────
// Returns students whose last 5 sent WhatsApp messages all have ack = 1 (1 tick only).
// Excludes dismissed students (wa_dead_dismissed = 1).
router.get('/dead-numbers', async (req, res) => {
  try {
    // Ensure dismiss column exists
    try { await run('ALTER TABLE students ADD COLUMN wa_dead_dismissed INTEGER DEFAULT 0'); } catch(e) {}

    const students = await query(`
      SELECT s.student_uid, s.name, s.class, s.section, s.parent_phone, s.parent_phone2,
             s.wa_status, s.wa_dead_dismissed, s.gr_number, s.admission_date
      FROM students s
      WHERE (s.status IS NULL OR s.status != 'inactive')
      ORDER BY s.class, s.name
    `);

    const deadList = [];

    for (const student of students) {
      // Fetch last 3 sent messages regardless of ack value.
      // We intentionally drop the `status = 'sent'` filter because blocked-number
      // messages may land with status 'failed' or remain at status 'sent' with
      // ack stuck at 0/1 — we want all outbound attempts counted.
      const logs = await query(`
        SELECT ack, msg_id, timestamp, phone
        FROM whatsapp_log
        WHERE (student_uid = ? OR (student_uid IS NULL AND student_name = ?))
        ORDER BY id DESC
        LIMIT 3
      `, [student.student_uid, student.name]);

      if (logs.length < 3) continue;

      // normalized ack values (WPPConnect / WhatsApp):
      //   0 = pending (in queue)           → never delivered
      //   1 = sent to WA server (1 tick)   → never delivered to handset
      //   2 = delivered to handset (2 ticks)
      //   3 = read (blue ticks)
      //
      // A "dead" number = none of the last 3 messages ever reached the handset,
      // i.e. every ack is 0 or 1 (or NULL for rows created before ack column existed).
      // Using < 2 covers all three cases cleanly.
      const neverDelivered = logs.every(l => {
        const ack = l.ack === null || l.ack === undefined ? 0 : Number(l.ack);
        return ack < 2;
      });
      if (!neverDelivered) continue;

      // If previously dismissed (via the Dismiss button) but now blocked again → auto-undismiss
      // so it resurfaces for attention. Do NOT do this for students that were
      // permanently cleared via the Delete button (wa_status === 'cleared') —
      // otherwise a "deleted" entry comes right back on the next refresh since
      // the underlying message log hasn't changed.
      if (student.wa_dead_dismissed && student.wa_status !== 'cleared') {
        try { await run('UPDATE students SET wa_dead_dismissed = 0 WHERE student_uid = ?', [student.student_uid]); } catch(e) {}
        student.wa_dead_dismissed = 0;
      }

      deadList.push({
        student_uid:    student.student_uid,
        name:           student.name,
        class:          student.class,
        section:        student.section || '',
        gr_number:      student.gr_number || '',
        admission_date: student.admission_date || '',
        parent_phone:   student.parent_phone || '',
        parent_phone2:  student.parent_phone2 || '',
        wa_status:      student.wa_status || 'unknown',
        last_msg_at:    logs[0].timestamp || null,
        one_tick_count: logs.length,
        dismissed:      student.wa_dead_dismissed ? true : false,
      });
    }

    res.json({ success: true, dead: deadList });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/flagged/dead-numbers/dismiss ───────────────────────────────────
router.post('/dead-numbers/dismiss', async (req, res) => {
  try {
    const { student_uid } = req.body;
    if (!student_uid) return res.status(400).json({ success: false, error: 'student_uid required' });
    await run('UPDATE students SET wa_dead_dismissed = 1 WHERE student_uid = ?', [student_uid]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/flagged/dead-numbers/delete ────────────────────────────────────
// Permanently deletes the WhatsApp log history for these students (the data
// that caused them to be flagged as "dead"), so this entry is genuinely gone —
// not just hidden. Does NOT delete the student record itself.
router.post('/dead-numbers/delete', async (req, res) => {
  try {
    const { student_uids } = req.body;
    if (!student_uids || !student_uids.length) return res.status(400).json({ success: false, error: 'student_uids required' });
    const placeholders = student_uids.map(() => '?').join(',');
    await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${placeholders})`, student_uids);
    // wa_status/wa_dead_dismissed reset since the log that flagged them is gone
    await run(`UPDATE students SET wa_dead_dismissed = 0, wa_status = 'unknown' WHERE student_uid IN (${placeholders})`, student_uids);
    res.json({ success: true, deleted: student_uids.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/flagged/dead-numbers/undismiss ─────────────────────────────────
router.post('/dead-numbers/undismiss', async (req, res) => {
  try {
    const { student_uid } = req.body;
    if (!student_uid) return res.status(400).json({ success: false, error: 'student_uid required' });
    await run('UPDATE students SET wa_dead_dismissed = 0 WHERE student_uid = ?', [student_uid]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── POST /api/flagged/dead-numbers/update-phone ──────────────────────────────
// Body: { student_uid, phone, which } — which: 'phone1' (default) or 'phone2'
router.post('/dead-numbers/update-phone', async (req, res) => {
  try {
    const { student_uid, phone, which } = req.body;
    if (!student_uid || !phone) return res.status(400).json({ success: false, error: 'student_uid and phone required' });
    if (which === 'phone2') {
      await run(
        'UPDATE students SET parent_phone2 = ?, wa_dead_dismissed = 0 WHERE student_uid = ?',
        [phone, student_uid]
      );
    } else {
      await run(
        'UPDATE students SET parent_phone = ?, wa_status = ?, wa_dead_dismissed = 0 WHERE student_uid = ?',
        [phone, 'unknown', student_uid]
      );
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
