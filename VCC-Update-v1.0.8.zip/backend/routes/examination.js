const express = require('express');
const router = express.Router();
const { query, run } = require('../database');
const { smartSend } = require('../whatsapp');
const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');

function getDb() { return require('../database'); }

function nowPktDateTime() {
  return new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0];
}

function formatMarksValue(value) {
  if (value === null || value === undefined || value === '') return '';
  const marks = Number(value);
  if (!Number.isFinite(marks)) return '';
  const normalized = Math.round((marks + Number.EPSILON) * 100) / 100;
  return Number.isInteger(normalized) ? String(normalized).padStart(2, '0') : String(normalized);
}

async function markAwardListSentIfComplete(awardListId) {
  const [counts] = await query(`SELECT COUNT(*) AS total,
    SUM(CASE WHEN sent = 1 THEN 1 ELSE 0 END) AS sent_total
    FROM award_list_entries WHERE award_list_id = ?`, [awardListId]);
  if (Number(counts?.total || 0) > 0 && Number(counts?.sent_total || 0) >= Number(counts.total)) {
    const sentAt = nowPktDateTime();
    await run(`UPDATE award_lists
      SET marks_sent_at = COALESCE(marks_sent_at, ?),
          marks_sent_method = COALESCE(marks_sent_method, 'system')
      WHERE id = ?`, [sentAt, awardListId]);
    return sentAt;
  }
  return null;
}

function getAwardListQrBaseUrl(req) {
  // Keep only the small QR portal public; the local admin system stays private.
  // PUBLIC_BASE_URL remains a fallback for existing installations.
  const configured = String(process.env.AWARD_PORTAL_URL || process.env.PUBLIC_BASE_URL || '').trim().replace(/\/$/, '');
  if (configured) return configured;

  const requestHost = String(req.get('host') || '').trim();
  const hostName = (requestHost.startsWith('[')
    ? requestHost.slice(1, requestHost.indexOf(']'))
    : requestHost.split(':')[0]).toLowerCase();
  if (requestHost && hostName !== 'localhost' && hostName !== '127.0.0.1' && hostName !== '::1') {
    return `${req.protocol}://${requestHost}`;
  }

  const privateIpv4 = Object.values(os.networkInterfaces())
    .flat()
    .find(address => address && address.family === 'IPv4' && !address.internal && (
      address.address.startsWith('10.') ||
      address.address.startsWith('192.168.') ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(address.address)
    ));
  return privateIpv4 ? `${req.protocol}://${privateIpv4.address}:${process.env.PORT || 3000}` : `${req.protocol}://${requestHost}`;
}

function fillMarksTemplate(template, entry, al, contact) {
  return template
    .replace(/{name}/g, entry.name || '')
    .replace(/{class}/g, al.class || '')
    .replace(/{section}/g, al.section || '')
    .replace(/{marks}/g, formatMarksValue(entry.marks_obtained))
    .replace(/{total}/g, al.total_marks || '')
    .replace(/{subject}/g, al.subject || '')
    .replace(/{date}/g, al.test_date || '')
    .replace(/{contact}/g, contact || '');
}

function fillAbsentTemplate(template, entry, al, contact) {
  const statusLabel = entry.special_status === 'NOT_ADMITTED' ? 'Not Admitted' : 'Absent';
  return template
    .replace(/{name}/g, entry.name || '')
    .replace(/{class}/g, al.class || '')
    .replace(/{section}/g, al.section || '')
    .replace(/{status}/g, statusLabel)
    .replace(/{subject}/g, al.subject || '')
    .replace(/{date}/g, al.test_date || '')
    .replace(/{contact}/g, contact || '')
    .replace(/{total}/g, al.total_marks || '');
}

// 'grp' column now created directly in test_plans table (see database.js CREATE TABLE).
// Old race-condition migration removed — it ran at require-time, before initDb()
// created the table, so it silently failed on fresh installs.

// GET /api/examination/settings — classes, sections, logo status
router.get('/settings', async (req, res) => {
  try {
    const rows = await query("SELECT key, value FROM settings WHERE key IN ('classes','sections','groups','sessions','campus','vcc_name','contact','group_subjects','notice_en','notice_ur')");
    const map = {};
    rows.forEach(r => map[r.key] = r.value);

    const logoPath = path.join(__dirname, '../../frontend/assets/logo.png');
    map.has_logo = fs.existsSync(logoPath);

    res.json({ success: true, settings: map });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/send-test-plan
// Body: { class, section, month, year, rows: [{date,day,timing,subject}], message_text }
router.post('/send-test-plan', async (req, res) => {
  try {
    const { class: cls, section, month, year, rows, message_text } = req.body;

    if (!cls || !month || !year || !rows || !rows.length) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }

    // Get active students for this class+section
    let students;
    if (section) {
      students = await query(
        "SELECT * FROM students WHERE class = ? AND section = ? AND (status = 'active' OR status IS NULL OR status = '') ORDER BY name",
        [cls, section]
      );
    } else {
      students = await query(
        "SELECT * FROM students WHERE class = ? AND (status = 'active' OR status IS NULL OR status = '') ORDER BY name",
        [cls]
      );
    }

    if (!students.length) {
      return res.status(404).json({ success: false, error: 'No active students found for this class' });
    }

    const db = getDb();
    let sent = 0, queued = 0, failed = 0;
    const results = [];

    const monthName = new Date(year, month - 1, 1).toLocaleString('en-US', { month: 'long' }).toUpperCase();
    const classLabel = section ? `${cls} - ${section}` : cls;
    const header = message_text || `WEEKLY TEST PLAN OF ${monthName} ${year} FOR CLASS ${classLabel}`;

    // Build schedule text
    const scheduleLines = rows.map((r, i) =>
      `${i + 1}. ${r.date} (${r.day}) | ${r.timing} | ${r.subject}`
    ).join('\n');

    for (const student of students) {
      const personalMsg = `${header}\n\nDear Parent of ${student.name},\n\nWeekly Test Schedule:\n${scheduleLines}\n\nPlease ensure your child is well-prepared and punctual for each test.\n\n— Vectors Coaching Centre`;

      const result = await smartSend(student, personalMsg, db);
      if (result.sent) sent++; else if (result.queued) queued++; else failed++;

      results.push({
        name: student.name,
        phone: result.phone,
        sent: result.sent,
        queued: !!result.queued,
        usedFallback: result.usedFallback,
        reason: result.reason || null
      });

      try {
        await run(
          'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [
            student.name, student.class, result.phone, personalMsg,
            'TEST_PLAN',
            result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
            (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0],
            result.msgId || null,
            result.usedFallback ? 1 : 0,
            student.student_uid || null,
            result.sent ? null : result.reason
          ]
        );
      } catch (e) {}

    }

    res.json({ success: true, sent, queued, failed, total: students.length, results });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Test Plans (persisted so Award List page can search them) ──────────────

// POST /api/examination/save-test-plan
// Body: { class, section, month, year, rows: [{date,day,timing,subject}] }
// Saves one row per scheduled test. Re-saving the same class/section/month/year
// replaces the previous set (so editing a plan and saving again doesn't duplicate).
router.post('/save-test-plan', async (req, res) => {
  try {
    const { class: cls, section, month, year, rows, group: grp } = req.body;
    if (!cls || !month || !year || !rows || !rows.length) {
      return res.status(400).json({ success: false, error: 'Missing required fields' });
    }

    await run(
      'DELETE FROM test_plans WHERE class = ? AND section = ? AND month = ? AND year = ? AND grp = ?',
      [cls, section || '', month, year, grp || '']
    );

    for (const r of rows) {
      if (!r.subject || !r.subject.trim()) continue; // skip blank rows
      await run(
        'INSERT INTO test_plans (class, section, subject, test_date, day, timing, month, year, grp) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [cls, section || '', r.subject.trim(), r.date, r.day, r.timing, month, year, grp || '']
      );
    }

    res.json({ success: true, message: 'Test plan saved' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/date-range-hint?class=IX&section=A&session=2025-2026
// Returns the earliest test_date month+year for a class in a session,
// and the previous month from today as to_month/to_year
router.get('/date-range-hint', async (req, res) => {
  try {
    const { class: cls, section, session } = req.query;
    if (!cls) return res.json({ success: false, error: 'class required' });

    let sql = 'SELECT test_date FROM award_lists WHERE class = ?';
    const args = [cls];
    if (section) { sql += ' AND section = ?'; args.push(section); }
    if (session)  { sql += ' AND session = ?'; args.push(session); }
    sql += ' ORDER BY substr(test_date,7,4)||substr(test_date,4,2)||substr(test_date,1,2) ASC LIMIT 1';

    const rows = await query(sql, args);

    let fromMonth = null, fromYear = null;
    if (rows.length && rows[0].test_date) {
      const parts = rows[0].test_date.split('-'); // DD-MM-YYYY
      if (parts.length === 3) {
        fromMonth = parseInt(parts[1]);
        fromYear  = parseInt(parts[2]);
      }
    }

    // to_month = previous month from today
    const now = new Date();
    let toMonth = now.getMonth(); // 0-indexed so this is already "previous"
    let toYear  = now.getFullYear();
    if (toMonth === 0) { toMonth = 12; toYear -= 1; }

    res.json({ success: true, fromMonth, fromYear, toMonth, toYear });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/test-plans?class=IX&subject=Physics&date=01-07-2026&month=7&year=2026
// Any combination of filters. Returns matching saved tests, most recent first.
router.get('/test-plans', async (req, res) => {
  try {
    const { class: cls, section, subject, date, month, year, group: grp, exact } = req.query;
    const where = [];
    const args = [];
    if (cls)     { where.push('class = ?'); args.push(cls); }
    if (section || exact === '1') { where.push('section = ?'); args.push(section || ''); }
    if (grp || exact === '1')     { where.push('grp = ?'); args.push(grp || ''); }
    if (subject) { where.push('subject LIKE ?'); args.push('%' + subject + '%'); }
    if (date)    { where.push('test_date = ?'); args.push(date); }
    if (month)   { where.push('month = ?'); args.push(parseInt(month)); }
    if (year)    { where.push('year = ?'); args.push(parseInt(year)); }

    const sql = `SELECT * FROM test_plans` +
      (where.length ? ' WHERE ' + where.join(' AND ') : '') +
      ' ORDER BY class, section, month, test_date ASC LIMIT 500';

    const plans = await query(sql, args);
    res.json({ success: true, plans });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/test-plans/grouped — returns one row per class+section+month+year with test count
// Supports same filters: class, section, month, year
router.get('/test-plans/grouped', async (req, res) => {
  try {
    const { class: cls, section, month, year, group: grp } = req.query;
    const where = [];
    const args = [];
    if (cls)     { where.push('class = ?'); args.push(cls); }
    if (section) { where.push('section = ?'); args.push(section); }
    if (grp)     { where.push('grp = ?'); args.push(grp); }
    if (month)   { where.push('month = ?'); args.push(parseInt(month)); }
    if (year)    { where.push('year = ?'); args.push(parseInt(year)); }

    // Get all matching rows sorted by date, then group in JS to preserve date order
    const sql = `SELECT class, section, grp, month, year, subject, test_date
      FROM test_plans` +
      (where.length ? ' WHERE ' + where.join(' AND ') : '') +
      ' ORDER BY class, section, month, year, test_date ASC';

    const rows = await query(sql, args);

    // Group in JS — preserves insertion (date) order for subjects
    const map = new Map();
    rows.forEach(r => {
      const key = `${r.class}||${r.section}||${r.grp}||${r.month}||${r.year}`;
      if (!map.has(key)) {
        map.set(key, {
          class: r.class, section: r.section, grp: r.grp || '', month: r.month, year: r.year,
          test_count: 0, first_date: r.test_date, last_date: r.test_date, subjects: []
        });
      }
      const g = map.get(key);
      g.test_count++;
      g.last_date  = r.test_date;
      g.subjects.push(r.subject);
    });

    const groups = Array.from(map.values()).map(g => ({
      ...g, subjects: g.subjects.join(', ')
    }));

    // Detect whether a WhatsApp test-plan blast was already sent for each
    // group, by checking whatsapp_log for a sent TEST_PLAN message for that
    // class which mentions the group's month+year (log only stores class,
    // not section/group/month/year directly, so we match on message text).
    const mnNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
    for (const g of groups) {
      try {
        const monthName = mnNames[parseInt(g.month)] || '';
        const logRows = await query(
          "SELECT 1 FROM whatsapp_log WHERE student_class = ? AND type IN ('TEST_PLAN','TEST_PLAN_PDF') AND status = 'sent' AND (message LIKE ? OR caption LIKE ?) LIMIT 1",
          [g.class, `%${monthName.toUpperCase()} ${g.year}%`, `%${monthName}%${g.year}%`]
        );
        g.whatsapp_sent = logRows.length > 0;
      } catch (e) {
        g.whatsapp_sent = false;
      }
    }

    res.json({ success: true, groups });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/examination/test-plans — deletes all tests for a class+section+month+year
router.delete('/test-plans', async (req, res) => {
  try {
    const { class: cls, section, month, year, group: grp } = req.query;
    if (!cls || !month || !year) {
      return res.status(400).json({ success: false, error: 'class, month and year are required' });
    }
    await run(
      'DELETE FROM test_plans WHERE class = ? AND section = ? AND month = ? AND year = ? AND grp = ?',
      [cls, section || '', parseInt(month), parseInt(year), grp || '']
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/teacher-map — { class, section, subject } -> teacher
// Reads the JSON array saved from Settings (teacher_subject_map).
router.get('/teacher-map', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'teacher_subject_map'");
    let map = [];
    if (rows.length && rows[0].value) {
      try { map = JSON.parse(rows[0].value); } catch (e) { map = []; }
    }
    res.json({ success: true, map });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Award Lists ──────────────────────────────────────────────────────────────

// POST /api/examination/award-lists
// Upsert: if an award list with same class+section+subject+test_date already exists,
// return its existing ID without creating a duplicate.
router.post('/award-lists', async (req, res) => {
  try {
    const { class: cls, section, group_name, gender, subject, test_date, total_marks, teacher, session, campus, students } = req.body;
    if (!cls || !subject || !test_date || !total_marks) {
      return res.status(400).json({ success: false, error: 'Missing required fields: class, subject, test_date, total_marks' });
    }
    if (!Array.isArray(students) || !students.length) {
      return res.status(400).json({ success: false, error: 'students array required and must not be empty' });
    }

    // Check if an award list already exists for same class+section+subject+test_date
    const existing = await query(
      'SELECT id FROM award_lists WHERE class = ? AND section = ? AND subject = ? AND test_date = ? LIMIT 1',
      [cls, section || '', subject, test_date]
    );
    if (existing.length) {
      // Already saved — return existing ID, do not create duplicate
      return res.json({ success: true, award_list_id: existing[0].id, already_existed: true });
    }

    const result = await run(
      'INSERT INTO award_lists (class, section, group_name, gender, subject, test_date, total_marks, teacher, session, campus) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [cls, section || '', group_name || '', gender || '', subject, test_date, parseInt(total_marks), teacher || '', session || '', campus || '']
    );
    const award_list_id = Number(result.lastInsertRowid);

    for (const s of students) {
      await run(
        'INSERT INTO award_list_entries (award_list_id, student_uid, name, father_name, gr_number, parent_phone, parent_phone2) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [award_list_id, s.student_uid || null, s.name, s.father_name || '', s.gr_number || '', s.parent_phone || '', s.parent_phone2 || '']
      );
    }

    res.json({ success: true, award_list_id });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/award-lists?class=&subject=&date=&section=
router.get('/award-lists', async (req, res) => {
  try {
    const { class: cls, section, subject, date, month, year, session, pending, today } = req.query;
    // Award Lists are an archive: return the complete matching set by default.
    // A numeric limit is applied only when a caller explicitly requests one.
    const rawLimit = req.query.limit == null ? 'all' : String(req.query.limit).toLowerCase();
    const parsedLimit = Number.parseInt(rawLimit, 10);
    const hasNumericLimit = rawLimit !== 'all' && Number.isFinite(parsedLimit) && parsedLimit > 0;
    const resultLimit = hasNumericLimit ? Math.min(parsedLimit, 500) : null;
    const parsedOffset = Number.parseInt(req.query.offset, 10);
    const resultOffset = Number.isFinite(parsedOffset) && parsedOffset > 0 ? parsedOffset : 0;
    const limitClause = resultLimit ? ` LIMIT ${resultLimit} OFFSET ${resultOffset}` : '';
    const where = [];
    const args = [];
    if (cls)     { where.push('al.class = ?'); args.push(cls); }
    if (section) { where.push('al.section = ?'); args.push(section); }
    if (subject) { where.push('al.subject LIKE ?'); args.push('%' + subject + '%'); }
    if (date)    { where.push('al.test_date = ?'); args.push(date); }
    if (month) {
      const months = String(month).split(',')
        .map(value => Number.parseInt(value, 10))
        .filter(value => Number.isInteger(value) && value >= 1 && value <= 12);
      if (months.length) {
        where.push(`strftime('%m', substr(al.test_date,7,4)||'-'||substr(al.test_date,4,2)||'-'||substr(al.test_date,1,2)) IN (${months.map(() => '?').join(',')})`);
        args.push(...months.map(value => String(value).padStart(2, '0')));
      }
    }
    if (year)    { where.push("substr(al.test_date,7,4) = ?"); args.push(year); }
    if (session) { where.push('al.session = ?'); args.push(session); }

    // Lightweight lookup used by the Test Plan search to determine whether an
    // Award List was already generated. It intentionally has no row cap.
    if (req.query.keys_only === '1') {
      const lists = await query(`SELECT al.id, al.class, al.section, al.subject, al.test_date
        FROM award_lists al
        ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
        ORDER BY al.id DESC`, args);
      return res.json({ success: true, lists });
    }

    // Pending mode: test_date < today AND not fully sent
    // Date format is DD-MM-YYYY — convert to YYYY-MM-DD for comparison
    let havingClause = '';
    if (pending === '1' && today) {
      const [dd, mm, yyyy] = today.split('-');
      const todayIso = `${yyyy}-${mm}-${dd}`;
      // Convert stored DD-MM-YYYY to YYYY-MM-DD for comparison
      where.push("substr(al.test_date,7,4)||'-'||substr(al.test_date,4,2)||'-'||substr(al.test_date,1,2) < ?");
      args.push(todayIso);
      // No HAVING — return all past tests, frontend filters by status
    }

    const sql = `SELECT al.id, al.class, al.section, al.group_name, al.gender, al.subject, al.test_date, al.total_marks, al.teacher, al.locked, al.copy_handed_over_at, al.copy_handed_over_method, al.copy_received_at, al.copy_received_method, al.copy_reminder_count, al.copy_last_reminder_at, al.marks_sent_at, al.marks_sent_method, al.created_at,
      COUNT(ale.id) as student_count,
      SUM(CASE WHEN ale.marks_obtained IS NOT NULL OR ale.special_status IS NOT NULL THEN 1 ELSE 0 END) as marks_entered_count,
      SUM(CASE WHEN ale.sent = 1 THEN 1 ELSE 0 END) as sent_count,
      MAX(ale.sent_at) as last_entry_sent_at
      FROM award_lists al
      LEFT JOIN award_list_entries ale ON ale.award_list_id = al.id
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      GROUP BY al.id
      ${havingClause}
      ORDER BY ${pending === '1' ? "substr(al.test_date,7,4)||'-'||substr(al.test_date,4,2)||'-'||substr(al.test_date,1,2) ASC" : 'al.id DESC'}${limitClause}`;

    const lists = await query(sql, args);
    res.json({ success: true, lists });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// DELETE /api/examination/award-lists/:id
router.delete('/award-lists/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await run('DELETE FROM award_list_entries WHERE award_list_id = ?', [id]);
    await run('DELETE FROM award_lists WHERE id = ?', [id]);
    res.json({ success: true });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/award-lists/:id
router.get('/award-lists/:id', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });

    const entries = await query('SELECT * FROM award_list_entries WHERE award_list_id = ? ORDER BY id ASC', [id]);
    res.json({ success: true, award_list: al, entries });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/award-lists/:id/qr
// Printable QR for the Legal award-list format. It opens a token-protected,
// login-free page for the handover and return stages of copy custody.
router.get('/award-lists/:id/qr', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT id, qr_token FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    let token = al.qr_token;
    if (!token) {
      token = crypto.randomBytes(24).toString('hex');
      await run('UPDATE award_lists SET qr_token = ? WHERE id = ?', [token, id]);
    }
    const origin = getAwardListQrBaseUrl(req);
    const target = `${origin}/award-list-receive/${token}`;
    // Keep this as vector artwork: browser/print scaling was blurring the old
    // 280px PNG. A standards-compliant four-module quiet zone is essential for
    // reliable scans from both the preview and the printed award list.
    const svg = await QRCode.toString(target, {
      type: 'svg',
      width: 512,
      margin: 4,
      errorCorrectionLevel: 'H',
      color: { dark: '#000000', light: '#ffffff' }
    });
    res.setHeader('Content-Type', 'image/svg+xml; charset=utf-8');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.send(svg);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// PATCH /api/examination/award-lists/:id/copy-receiving
// Admin fallback for entering the actual return date/time without scanning.
router.patch('/award-lists/:id/copy-receiving', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [award] = await query('SELECT id, copy_handed_over_at FROM award_lists WHERE id = ?', [id]);
    if (!award) return res.status(404).json({ success:false, error:'Award list not found.' });
    if (!award.copy_handed_over_at) return res.status(409).json({ success:false, error:'Mark the copies as handed over before recording their return.' });
    let receivedAt = String(req.body.received_at || '').trim().replace('T', ' ');
    if (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(receivedAt)) receivedAt += ':00';
    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/.test(receivedAt) || Number.isNaN(new Date(receivedAt.replace(' ', 'T') + '+05:00').getTime())) {
      return res.status(400).json({ success:false, error:'Enter a valid receiving date and time.' });
    }
    await run('UPDATE award_lists SET copy_received_at = ? WHERE id = ?', [receivedAt, id]);
    res.json({ success:true, copy_received_at:receivedAt });
  } catch (err) {
    res.status(500).json({ success:false, error:'Could not save the receiving date and time.' });
  }
});

// PATCH /api/examination/award-lists/:id/copy-custody
// Admin correction for accidental QR scans or incorrectly entered custody dates.
router.patch('/award-lists/:id/copy-custody', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [award] = await query('SELECT id, copy_handed_over_at, copy_handed_over_method, copy_received_at, copy_received_method FROM award_lists WHERE id = ?', [id]);
    if (!award) return res.status(404).json({ success:false, error:'Award list not found.' });

    const hasGiven = Object.prototype.hasOwnProperty.call(req.body, 'handed_over_at') || Object.prototype.hasOwnProperty.call(req.body, 'handed_over_state');
    const hasReturned = Object.prototype.hasOwnProperty.call(req.body, 'received_at') || Object.prototype.hasOwnProperty.call(req.body, 'received_state');
    if (!hasGiven && !hasReturned) return res.status(400).json({ success:false, error:'No custody date was provided.' });

    const normalizeDateTime = (value, label) => {
      const text = String(value ?? '').trim().replace('T', ' ');
      if (!text) return null;
      const normalized = /^\d{4}-\d{2}-\d{2}$/.test(text)
        ? text
        : (/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(text) ? text + ':00' : text);
      if (!/^\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?$/.test(normalized) || Number.isNaN(new Date(normalized.replace(' ', 'T') + (normalized.includes(' ') ? '+05:00' : 'T00:00:00+05:00')).getTime())) {
        const error = new Error(`Enter a valid ${label} date. Time is optional.`);
        error.status = 400;
        throw error;
      }
      return normalized;
    };

    const givenState = hasGiven ? String(req.body.handed_over_state || '').toLowerCase() : '';
    const returnedState = hasReturned ? String(req.body.received_state || '').toLowerCase() : '';
    const givenAt = hasGiven ? (givenState === 'tentative' ? null : normalizeDateTime(req.body.handed_over_at, 'given')) : award.copy_handed_over_at;
    const returnedAt = hasReturned ? (returnedState === 'tentative' ? null : normalizeDateTime(req.body.received_at, 'returned')) : award.copy_received_at;
    const givenMethod = hasGiven ? (givenState === 'tentative' ? 'tentative' : (givenAt ? 'manual' : null)) : award.copy_handed_over_method;
    const returnedMethod = hasReturned ? (returnedState === 'tentative' ? 'tentative' : (returnedAt ? 'manual' : null)) : award.copy_received_method;
    if ((returnedAt || returnedMethod === 'tentative') && !(givenAt || givenMethod === 'tentative')) return res.status(409).json({ success:false, error:'Copies cannot be returned before they are marked as given.' });
    if (givenAt && returnedAt) {
      const givenTime = new Date(givenAt.replace(' ', 'T') + '+05:00').getTime();
      const returnedTime = new Date(returnedAt.replace(' ', 'T') + '+05:00').getTime();
      if (returnedTime < givenTime) return res.status(409).json({ success:false, error:'Returned date cannot be earlier than the given date.' });
    }

    await run('UPDATE award_lists SET copy_handed_over_at = ?, copy_handed_over_method = ?, copy_received_at = ?, copy_received_method = ? WHERE id = ?', [givenAt, givenMethod, returnedAt, returnedMethod, id]);
    res.json({ success:true, copy_handed_over_at:givenAt, copy_handed_over_method:givenMethod, copy_received_at:returnedAt, copy_received_method:returnedMethod });
  } catch (err) {
    res.status(err.status || 500).json({ success:false, error:err.message || 'Could not update copy custody dates.' });
  }
});

// PATCH /api/examination/award-lists/:id/marks-sent
// Records manual WhatsApp sending, or corrects/clears an existing sent date.
router.patch('/award-lists/:id/marks-sent', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [award] = await query('SELECT id, locked FROM award_lists WHERE id = ?', [id]);
    if (!award) return res.status(404).json({ success:false, error:'Award list not found.' });

    const sentState = String(req.body.sent_state || '').toLowerCase();
    let sentAt = sentState === 'tentative' ? '' : String(req.body.sent_at ?? '').trim().replace('T', ' ');
    if (sentAt && /^\d{4}-\d{2}-\d{2}$/.test(sentAt)) {
      // A date by itself is a valid historical record; time is deliberately optional.
    } else
    if (sentAt && /^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(sentAt)) sentAt += ':00';
    if (sentAt && (!/^\d{4}-\d{2}-\d{2}(?: \d{2}:\d{2}:\d{2})?$/.test(sentAt) || Number.isNaN(new Date(sentAt.replace(' ', 'T') + (sentAt.includes(' ') ? '+05:00' : 'T00:00:00+05:00')).getTime()))) {
      return res.status(400).json({ success:false, error:'Enter a valid marks sent date. Time is optional.' });
    }
    if ((sentAt || sentState === 'tentative') && !award.locked) {
      return res.status(409).json({ success:false, error:'Lock the Award List before marking its results as sent.' });
    }

    const sentMethod = sentState === 'tentative' ? 'tentative' : (sentAt ? 'manual' : null);
    await run('UPDATE award_lists SET marks_sent_at = ?, marks_sent_method = ? WHERE id = ?', [sentAt || null, sentMethod, id]);
    res.json({ success:true, marks_sent_at:sentAt || null, marks_sent_method:sentMethod });
  } catch (err) {
    res.status(500).json({ success:false, error:err.message || 'Could not update marks sent date.' });
  }
});

// GET /api/examination/award-lists/:id/available-students?q=...
// Search the full active student register so a student filed under the wrong
// section can still be added to an existing award list.
router.get('/award-lists/:id/available-students', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT id FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });

    const search = String(req.query.q || '').trim();
    if (!search) return res.json({ success: true, students: [] });

    const like = `%${search}%`;
    const students = await query(`
      SELECT s.student_uid, s.name, s.father_name, s.gr_number, s.class, s.section
      FROM students s
      WHERE (s.status IS NULL OR TRIM(s.status) = '' OR LOWER(TRIM(s.status)) = 'active')
        AND (s.gr_number LIKE ? OR s.name LIKE ?)
        AND NOT EXISTS (
          SELECT 1 FROM award_list_entries ale
          WHERE ale.award_list_id = ? AND ale.student_uid = s.student_uid
        )
      ORDER BY CASE WHEN s.gr_number = ? THEN 0 ELSE 1 END, s.name ASC
      LIMIT 30
    `, [like, like, id, search]);

    res.json({ success: true, students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/entries
// Add one student snapshot without rebuilding the list or disturbing marks.
router.post('/award-lists/:id/entries', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const studentUid = String(req.body.student_uid || '').trim();
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });

    let student;
    if (studentUid) {
      [student] = await query('SELECT * FROM students WHERE student_uid = ?', [studentUid]);
      if (!student) return res.status(404).json({ success: false, error: 'Student not found' });
      const [existing] = await query(
        'SELECT id FROM award_list_entries WHERE award_list_id = ? AND student_uid = ?',
        [id, studentUid]
      );
      if (existing) return res.status(409).json({ success: false, error: 'Student is already in this award list' });
    } else {
      const name = String(req.body.name || '').trim();
      if (!name) return res.status(400).json({ success:false, error:'Student name is required.' });
      student = {
        student_uid:null,
        name,
        father_name:String(req.body.father_name || '').trim(),
        gr_number:String(req.body.gr_number || '').trim(),
        parent_phone:String(req.body.parent_phone || '').trim(),
        parent_phone2:String(req.body.parent_phone2 || '').trim()
      };
      const [duplicate] = await query(`SELECT id FROM award_list_entries
        WHERE award_list_id = ? AND LOWER(TRIM(name)) = LOWER(TRIM(?))
          AND COALESCE(TRIM(gr_number),'') = COALESCE(TRIM(?),'')`, [id, name, student.gr_number]);
      if (duplicate) return res.status(409).json({ success:false, error:'A student with the same name and GR number is already in this Award List.' });
    }

    const result = await run(`INSERT INTO award_list_entries
      (award_list_id, student_uid, name, father_name, gr_number, parent_phone, parent_phone2)
      VALUES (?, ?, ?, ?, ?, ?, ?)`, [
      id, student.student_uid || null, student.name || '', student.father_name || '',
      student.gr_number || '', student.parent_phone || '', student.parent_phone2 || ''
    ]);

    // A roster change must reopen marks entry, but it must not consume the
    // teacher's one manual correction/unlock allowance.
    const rosterWasFinalized = !!al.locked || !!al.marks_sent_at || al.marks_sent_method === 'tentative';
    if (rosterWasFinalized) {
      await run('UPDATE award_lists SET locked = 0, marks_sent_at = NULL, marks_sent_method = NULL WHERE id = ?', [id]);
    }

    const [entry] = await query('SELECT * FROM award_list_entries WHERE id = ?', [Number(result.lastInsertRowid)]);
    res.json({ success: true, entry, unlocked: rosterWasFinalized });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/award-lists/:id/entries/:entryId/message-preview
// Return the exact personalized text used by the WhatsApp result sender so it
// can also be copied for manual sending without retyping student details.
router.get('/award-lists/:id/entries/:entryId/message-preview', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const entryId = parseInt(req.params.entryId);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success:false, error:'Award List not found.' });

    const [entry] = await query(
      'SELECT * FROM award_list_entries WHERE id = ? AND award_list_id = ?',
      [entryId, id]
    );
    if (!entry) return res.status(404).json({ success:false, error:'Student entry not found.' });

    const hasSpecialStatus = entry.special_status === 'ABSENT' || entry.special_status === 'NOT_ADMITTED';
    const hasMarks = entry.marks_obtained !== null && entry.marks_obtained !== undefined && entry.marks_obtained !== '';
    if (!hasSpecialStatus && !hasMarks) {
      return res.status(400).json({ success:false, error:'Save this student result before copying the message.' });
    }

    const contactRows = await query("SELECT value FROM settings WHERE key = 'contact'");
    const contact = (contactRows[0] && contactRows[0].value) ? contactRows[0].value : '03000000000';

    let message;
    if (hasSpecialStatus) {
      const rows = await query("SELECT value FROM settings WHERE key = 'exam_absent_message'");
      const template = (rows[0] && rows[0].value)
        ? rows[0].value
        : 'Dear Parent, your child {name} (Class {class} - {section}) was {status} in {subject} test held on {date}. For any confusion feel free to contact {contact}.';
      message = fillAbsentTemplate(template, entry, al, contact);
    } else {
      const rows = await query("SELECT value FROM settings WHERE key = 'marks_message'");
      const template = (rows[0] && rows[0].value)
        ? rows[0].value
        : 'Dear Parent, your child {name} obtained ({marks}/{total}) marks in {subject} test held on {date}. For any confusion feel free to contact {contact}.';
      message = fillMarksTemplate(template, entry, al, contact);
    }

    res.json({
      success:true,
      message,
      phone:entry.parent_phone || entry.parent_phone2 || '',
      phone2:entry.parent_phone2 || ''
    });
  } catch (err) {
    res.status(500).json({ success:false, error:err.message || 'Could not prepare the result message.' });
  }
});

// DELETE /api/examination/award-lists/:id/entries/:entryId
router.delete('/award-lists/:id/entries/:entryId', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const entryId = parseInt(req.params.entryId);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    const [entry] = await query(
      'SELECT * FROM award_list_entries WHERE id = ? AND award_list_id = ?',
      [entryId, id]
    );
    if (!entry) return res.status(404).json({ success: false, error: 'Award list entry not found' });
    if (entry.sent) {
      return res.status(400).json({ success: false, error: 'This result has already been sent and cannot be removed from the award list' });
    }

    await run('DELETE FROM award_list_entries WHERE id = ? AND award_list_id = ?', [entryId, id]);
    const rosterWasFinalized = !!al.locked || !!al.marks_sent_at || al.marks_sent_method === 'tentative';
    if (rosterWasFinalized) {
      await run('UPDATE award_lists SET locked = 0, marks_sent_at = NULL, marks_sent_method = NULL WHERE id = ?', [id]);
    }
    res.json({ success: true, unlocked: rosterWasFinalized });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/marks
router.post('/award-lists/:id/marks', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    if (al.locked) return res.status(400).json({ success: false, error: 'Award list is locked. Unlock first to edit marks.' });

    const { entries } = req.body;
    if (!Array.isArray(entries)) return res.status(400).json({ success: false, error: 'entries array required' });

    for (const e of entries) {
      // Handle special status (ABSENT / NOT_ADMITTED)
      if (e.special_status === 'ABSENT' || e.special_status === 'NOT_ADMITTED') {
        await run('UPDATE award_list_entries SET marks_obtained = NULL, special_status = ? WHERE id = ? AND award_list_id = ?', [e.special_status, e.entry_id, id]);
        continue;
      }
      // Clear special status if switching back to marks
      if (e.marks_obtained === null || e.marks_obtained === undefined || e.marks_obtained === '') {
        await run('UPDATE award_list_entries SET marks_obtained = NULL, special_status = NULL WHERE id = ? AND award_list_id = ?', [e.entry_id, id]);
        continue;
      }
      const m = Number(e.marks_obtained);
      const hasValidPrecision = Math.abs(m * 100 - Math.round(m * 100)) < 1e-8;
      if (!Number.isFinite(m) || !hasValidPrecision || m < 0 || m > Number(al.total_marks)) {
        return res.status(400).json({ success: false, error: `Marks ${e.marks_obtained} out of range (0–${al.total_marks}) for entry ${e.entry_id}` });
      }
      const normalizedMarks = Math.round((m + Number.EPSILON) * 100) / 100;
      await run('UPDATE award_list_entries SET marks_obtained = ?, special_status = NULL WHERE id = ? AND award_list_id = ?', [normalizedMarks, e.entry_id, id]);
    }

    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/lock  (lock only, no send)
router.post('/award-lists/:id/lock', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    if (al.locked) return res.status(400).json({ success: false, error: 'Award list is already locked.' });

    // Safety net: don't allow locking a list with no marks/status saved yet —
    // this is what previously caused "marks not showing after lock" when the
    // teacher clicked Lock before clicking Save Marks.
    const [{ cnt }] = await query(
      "SELECT COUNT(*) as cnt FROM award_list_entries WHERE award_list_id = ? AND (marks_obtained IS NOT NULL OR special_status IS NOT NULL)",
      [id]
    );
    if (!cnt) {
      return res.status(400).json({ success: false, error: 'No marks have been saved yet for this award list. Click "Save Marks" first, then Lock.' });
    }

    await run('UPDATE award_lists SET locked = 1 WHERE id = ?', [id]);
    res.json({ success: true });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/lock-and-send
router.post('/award-lists/:id/lock-and-send', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });

    await run('UPDATE award_lists SET locked = 1 WHERE id = ?', [id]);

    const contactRows = await query("SELECT value FROM settings WHERE key = 'contact'");
    const contact = (contactRows[0] && contactRows[0].value) ? contactRows[0].value : '03000000000';

    const templateRows = await query("SELECT value FROM settings WHERE key = 'marks_message'");
    const marksTemplate = (templateRows[0] && templateRows[0].value)
      ? templateRows[0].value
      : 'Dear Parent, your child {name} obtained ({marks}/{total}) marks in {subject} test held on {date}. For any confusion feel free to contact {contact}.';

    const entries = await query('SELECT * FROM award_list_entries WHERE award_list_id = ? AND marks_obtained IS NOT NULL AND (special_status IS NULL OR special_status = \'\') AND sent = 0', [id]);
    const absentEntries = await query("SELECT * FROM award_list_entries WHERE award_list_id = ? AND special_status IN ('ABSENT','NOT_ADMITTED') AND sent = 0", [id]);

    const absentTmplRows = await query("SELECT value FROM settings WHERE key = 'exam_absent_message'");
    const absentTemplate = (absentTmplRows[0] && absentTmplRows[0].value)
      ? absentTmplRows[0].value
      : 'Dear Parent, your child {name} (Class {class} - {section}) was {status} in {subject} test held on {date}. For any confusion feel free to contact {contact}.';

    const db = getDb();
    let sent_count = 0, queued_count = 0, failed_count = 0, skipped_count = 0;
    const results = [];

    for (const entry of entries) {
      if (!entry.parent_phone || !entry.parent_phone.toString().trim()) {
        skipped_count++;
        results.push({ name: entry.name, phone: '', sent: false, reason: 'No phone number' });
        continue;
      }

      const message = fillMarksTemplate(marksTemplate, entry, al, contact);
      const studentObj = { name: entry.name, parent_phone: entry.parent_phone || '', parent_phone2: entry.parent_phone2 || '', student_uid: entry.student_uid || null, award_entry_id: entry.id, wa_status: undefined };
      const result = await smartSend(studentObj, message, db);

      if (result.sent) {
        sent_count++;
        await run('UPDATE award_list_entries SET sent = 1, sent_at = CURRENT_TIMESTAMP WHERE id = ?', [entry.id]);
      } else if (result.queued) { queued_count++; } else { failed_count++; }

      try {
        await run(
          'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [entry.name, al.class, result.phone, message, 'EXAM_RESULT', 'EXAM_RESULT', result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
           (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').split('.')[0],
           result.msgId || null, result.usedFallback ? 1 : 0, entry.student_uid || null, result.sent ? null : result.reason]
        );
      } catch(e) {}

      results.push({ name: entry.name, phone: result.phone, sent: result.sent, queued: !!result.queued, reason: result.reason || null });
    }

    // Send absent/not-admitted messages
    for (const entry of absentEntries) {
      if (!entry.parent_phone || !entry.parent_phone.toString().trim()) {
        skipped_count++;
        results.push({ name: entry.name, phone: '', sent: false, reason: 'No phone number' });
        continue;
      }
      const message = fillAbsentTemplate(absentTemplate, entry, al, contact);
      const studentObj = { name: entry.name, parent_phone: entry.parent_phone || '', parent_phone2: entry.parent_phone2 || '', student_uid: entry.student_uid || null, award_entry_id: entry.id, wa_status: undefined };
      const result = await smartSend(studentObj, message, db);
      if (result.sent) {
        sent_count++;
        await run('UPDATE award_list_entries SET sent = 1, sent_at = CURRENT_TIMESTAMP WHERE id = ?', [entry.id]);
      } else if (result.queued) { queued_count++; } else { failed_count++; }
      try {
        await run(
          'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [entry.name, al.class, result.phone, message, 'EXAM_ABSENT', 'EXAM_RESULT', result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
           (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').split('.')[0],
           result.msgId || null, result.usedFallback ? 1 : 0, entry.student_uid || null, result.sent ? null : result.reason]
        );
      } catch(e) {}
      results.push({ name: entry.name, phone: result.phone, sent: result.sent, queued: !!result.queued, reason: result.reason || null });
    }

    const marks_sent_at = await markAwardListSentIfComplete(id);
    res.json({ success: true, sent_count, queued_count, failed_count, skipped_count, results, marks_sent_at });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/send-selected
// Body: { entry_ids: [1,2,3] }
router.post('/award-lists/:id/send-selected', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT * FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    if (!al.locked) return res.status(400).json({ success: false, error: 'Award list must be locked before sending marks.' });

    const { entry_ids } = req.body;
    if (!Array.isArray(entry_ids) || !entry_ids.length) {
      return res.status(400).json({ success: false, error: 'entry_ids array required' });
    }

    const contactRows = await query("SELECT value FROM settings WHERE key = 'contact'");
    const contact = (contactRows[0] && contactRows[0].value) ? contactRows[0].value : '03000000000';

    const tmplRows = await query("SELECT value FROM settings WHERE key = 'marks_message'");
    const selectedTemplate = (tmplRows[0] && tmplRows[0].value)
      ? tmplRows[0].value
      : 'Dear Parent, your child {name} obtained ({marks}/{total}) marks in {subject} test held on {date}. For any confusion feel free to contact {contact}.';

    const db = getDb();
    let sent_count = 0, queued_count = 0, failed_count = 0, skipped_count = 0;
    const results = [];

    for (const eid of entry_ids) {
      const [entry] = await query('SELECT * FROM award_list_entries WHERE id = ? AND award_list_id = ?', [eid, id]);
      if (!entry) {
        skipped_count++;
        results.push({ name: '?', phone: '', sent: false, reason: 'Entry not found' });
        continue;
      }
      // Absent / Not Admitted — send via absent template
      if (entry.special_status === 'ABSENT' || entry.special_status === 'NOT_ADMITTED') {
        if (!entry.parent_phone || !entry.parent_phone.toString().trim()) {
          skipped_count++;
          results.push({ name: entry.name, phone: '', sent: false, reason: 'No phone number' });
          continue;
        }
        const absentTmplRows2 = await query("SELECT value FROM settings WHERE key = 'exam_absent_message'");
        const absTmpl = (absentTmplRows2[0] && absentTmplRows2[0].value)
          ? absentTmplRows2[0].value
          : 'Dear Parent, your child {name} (Class {class} - {section}) was {status} in {subject} test held on {date}. For any confusion feel free to contact {contact}.';
        const absMsg = fillAbsentTemplate(absTmpl, entry, al, contact);
        const absStudentObj = { name: entry.name, parent_phone: entry.parent_phone || '', parent_phone2: entry.parent_phone2 || '', student_uid: entry.student_uid || null, award_entry_id: entry.id, wa_status: undefined };
        const absResult = await smartSend(absStudentObj, absMsg, db);
        if (absResult.sent) {
          sent_count++;
          await run('UPDATE award_list_entries SET sent = 1, sent_at = CURRENT_TIMESTAMP WHERE id = ?', [entry.id]);
        } else if (absResult.queued) { queued_count++; } else { failed_count++; }
        try {
          await run(
            'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [entry.name, al.class, absResult.phone, absMsg, 'EXAM_ABSENT', 'EXAM_RESULT', absResult.queued ? 'queued' : absResult.sent ? 'sent' : 'failed',
             (absResult.sent || absResult.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').split('.')[0],
             absResult.msgId || null, absResult.usedFallback ? 1 : 0, entry.student_uid || null, absResult.sent ? null : absResult.reason]
          );
        } catch(e) {}
        results.push({ name: entry.name, phone: absResult.phone, sent: absResult.sent, queued: !!absResult.queued, reason: absResult.reason || null });
        continue;
      }
      if (entry.marks_obtained === null || entry.marks_obtained === undefined) {
        skipped_count++;
        results.push({ name: entry.name, phone: '', sent: false, reason: 'No marks entered' });
        continue;
      }
      if (!entry.parent_phone || !entry.parent_phone.toString().trim()) {
        skipped_count++;
        results.push({ name: entry.name, phone: '', sent: false, reason: 'No phone number' });
        continue;
      }

      const message = fillMarksTemplate(selectedTemplate, entry, al, contact);
      const studentObj = { name: entry.name, parent_phone: entry.parent_phone || '', parent_phone2: entry.parent_phone2 || '', student_uid: entry.student_uid || null, award_entry_id: entry.id, wa_status: undefined };
      const result = await smartSend(studentObj, message, db);

      if (result.sent) {
        sent_count++;
        await run('UPDATE award_list_entries SET sent = 1, sent_at = CURRENT_TIMESTAMP WHERE id = ?', [entry.id]);
      } else if (result.queued) { queued_count++; } else { failed_count++; }

      try {
        await run(
          'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
          [entry.name, al.class, result.phone, message, 'EXAM_RESULT', 'EXAM_RESULT', result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
           (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').split('.')[0],
           result.msgId || null, result.usedFallback ? 1 : 0, entry.student_uid || null, result.sent ? null : result.reason]
        );
      } catch(e) {}

      results.push({ name: entry.name, phone: result.phone, sent: result.sent, queued: !!result.queued, reason: result.reason || null });
    }

    const marks_sent_at = await markAwardListSentIfComplete(id);
    res.json({ success: true, sent_count, queued_count, failed_count, skipped_count, results, marks_sent_at });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/award-lists/:id/unlock
// Allowed only ONCE per award list — used to correct a mistake after locking.
router.post('/award-lists/:id/unlock', async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [al] = await query('SELECT id, locked, unlock_count FROM award_lists WHERE id = ?', [id]);
    if (!al) return res.status(404).json({ success: false, error: 'Award list not found' });
    if (!al.locked) return res.status(400).json({ success: false, error: 'Award list is not locked.' });
    if ((al.unlock_count || 0) >= 1) {
      return res.status(400).json({ success: false, error: 'This award list has already been unlocked once. Unlock is only allowed one time per award list.' });
    }
    await run('UPDATE award_lists SET locked = 0, unlock_count = unlock_count + 1 WHERE id = ?', [id]);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});


// ── EXAM REPORT TEMPLATE ─────────────────────────────────────────────────────

const DEFAULT_EXAM_TEMPLATE = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { font-family: Arial, sans-serif; font-size: 12px; padding: 20px; background: #fff; color: #000; }
  .header { text-align: center; margin-bottom: 10px; }
  .header-top { display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 4px; }
  .logo { width: 90px; height: 90px; object-fit: contain; }
  .vcc-name { font-size: 26px; font-weight: 900; text-decoration: underline; letter-spacing: 1px; }
  .dept { font-size: 15px; font-weight: 700; border: 2px solid #000; display: inline-block; padding: 2px 16px; margin: 4px 0; }
  .report-title { font-size: 17px; font-weight: 900; text-decoration: underline; margin: 4px 0; }
  .info-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 10px 20px; margin: 10px 0 6px 0; font-size: 11.5px; }
  .info-grid .label { font-weight: 700; }
  .months-line { font-size: 11.5px; margin-bottom: 10px; }
  .months-line .label { font-weight: 700; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
  th { background: #222; color: #fff; padding: 6px 8px; font-size: 12px; font-weight: 700; border: 1px solid #000; text-align: center; }
  td { padding: 5px 8px; border: 1px solid #000; text-align: center; font-size: 11.5px; }
  td:nth-child(2) { text-align: left; }
  .footer { border-top: 2px solid #000; padding-top: 8px; text-align: center; font-size: 10px; margin-top: auto; }
  .footer-icons { display: flex; align-items: center; justify-content: center; gap: 16px; margin-bottom: 4px; }
  .footer-address { font-size: 9.5px; color: #333; }
</style>
</head>
<body>
<div class="header">
  <div class="header-top">
    {{LOGO_IMG}}
    <div class="vcc-name">{{VCC_NAME}}</div>
  </div>
  <div class="dept">DEPARTMENT OF EXAMINATIONS</div><br>
  <div class="report-title">WEEKLY TEST REPORT</div>
</div>

<div class="info-grid">
  <div><span class="label">Student Name:</span> {{STUDENT_NAME}}</div>
  <div><span class="label">Date of Admission:</span> {{ADMISSION_DATE}}</div>
  <div><span class="label">Father's Name:</span> {{FATHER_NAME}}</div>
  <div><span class="label">Class:</span> {{CLASS}} – {{SECTION}}{{GROUP_SUFFIX}} &nbsp;&nbsp; <span class="label">GR no:</span> {{GR_NUMBER}}</div>
</div>

<div class="months-line"><span class="label">Months Included:</span> {{MONTHS_INCLUDED}}</div>

<table>
  <thead>
    <tr>
      <th style="width:40px">S.no</th>
      <th>Subjects</th>
      <th>Test Date</th>
      <th>Total Marks</th>
      <th>Marks Obtained</th>
    </tr>
  </thead>
  <tbody>
    {{TEST_ROWS}}
  </tbody>
</table>

<div class="footer">
  <div class="footer-icons">
    <span>📘 {{CAMPUS}}</span>
    <span>📞 {{PHONE1}}</span>
    <span>📞 {{PHONE2}}</span>
  </div>
  <div class="footer-address">{{ADDRESS}}</div>
</div>
</body>
</html>`;

// GET /api/examination/report-template
router.get('/report-template', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'exam_report_template'");
    const template = (rows[0] && rows[0].value) ? rows[0].value : DEFAULT_EXAM_TEMPLATE;
    res.json({ success: true, template });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/report-template
router.post('/report-template', async (req, res) => {
  try {
    const { template } = req.body;
    if (!template) return res.status(400).json({ success: false, error: 'template required' });
    await run(
      "INSERT INTO settings(key, value) VALUES('exam_report_template', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      [template]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/report-template/reset
router.post('/report-template/reset', async (req, res) => {
  try {
    await run(
      "INSERT INTO settings(key, value) VALUES('exam_report_template', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      [DEFAULT_EXAM_TEMPLATE]
    );
    res.json({ success: true, template: DEFAULT_EXAM_TEMPLATE });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── EXAM TEST REPORT PDF GENERATOR ──────────────────────────────────────────
// Uses same renderHTMLtoPDF helper pattern from reports.js

const { execFile } = require('child_process');

function renderHTMLtoPDF(html) {
  return new Promise((resolve, reject) => {
    const tmpDir  = os.tmpdir();
    const uid2    = Date.now() + '_' + Math.random().toString(36).slice(2);
    const inFile  = path.join(tmpDir, 'vcc_exam_in_'  + uid2 + '.html');
    const outFile = path.join(tmpDir, 'vcc_exam_out_' + uid2 + '.pdf');

    try { fs.writeFileSync(inFile, html, 'utf8'); }
    catch(e) { return reject(new Error('Temp write failed: ' + e.message)); }

    let chromePath;
    try {
      if (process.env.PUPPETEER_EXECUTABLE_PATH) {
        chromePath = process.env.PUPPETEER_EXECUTABLE_PATH;
      } else {
        chromePath = require('puppeteer-core').executablePath();
      }
      if (!chromePath) throw new Error('No Chrome path found');
    } catch(e) {
      try { fs.unlinkSync(inFile); } catch(_) {}
      return reject(new Error('Cannot find Chrome: ' + e.message + ' — Set PUPPETEER_EXECUTABLE_PATH in .env'));
    }

    const fileUrl = 'file:///' + inFile.replace(/\\/g, '/');
    const args = [
      '--headless=new', '--disable-gpu', '--no-sandbox',
      '--disable-setuid-sandbox', '--disable-dev-shm-usage',
      '--virtual-time-budget=5000',
      '--print-to-pdf=' + outFile,
      '--no-pdf-header-footer', fileUrl
    ];

    execFile(chromePath, args, { timeout: 30000 }, (err, stdout, stderr) => {
      try { fs.unlinkSync(inFile); } catch(_) {}
      if (err && !fs.existsSync(outFile)) {
        return reject(new Error('Chrome error: ' + (stderr || err.message)));
      }
      try {
        const pdf = fs.readFileSync(outFile);
        try { fs.unlinkSync(outFile); } catch(_) {}
        resolve(pdf);
      } catch(e) {
        reject(new Error('PDF read failed: ' + e.message));
      }
    });
  });
}

async function renderHTMLtoJPG(html) {
  const puppeteer = require('puppeteer-core');
  let chromePath;
  if (process.env.PUPPETEER_EXECUTABLE_PATH) {
    chromePath = process.env.PUPPETEER_EXECUTABLE_PATH;
  } else {
    try { chromePath = await puppeteer.executablePath(); } catch (_) {}
    if (!chromePath || !fs.existsSync(chromePath)) {
      const commonBrowserPaths = process.platform === 'win32' ? [
        'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
        'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
        'C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe'
      ] : ['/usr/bin/google-chrome', '/usr/bin/chromium', '/usr/bin/chromium-browser'];
      chromePath = commonBrowserPaths.find(candidate => fs.existsSync(candidate));
    }
  }
  if (!chromePath) throw new Error('Cannot find Chrome — set PUPPETEER_EXECUTABLE_PATH in .env');

  // The preview uses a same-origin browser URL for the logo. Convert it to an
  // embedded data URL because the renderer receives standalone HTML.
  let preparedHtml = String(html || '');
  const logoPath = path.join(__dirname, '../../frontend/assets/logo.png');
  if (fs.existsSync(logoPath)) {
    const logoData = fs.readFileSync(logoPath).toString('base64');
    preparedHtml = preparedHtml.replace(/\/assets\/logo\.png/g, `data:image/png;base64,${logoData}`);
  }

  const browser = await puppeteer.launch({
    executablePath: chromePath,
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage', '--disable-gpu']
  });
  try {
    const page = await browser.newPage();
    await page.setViewport({ width: 794, height: 1123, deviceScaleFactor: 2 });
    await page.setJavaScriptEnabled(false);
    await page.setContent(preparedHtml, { waitUntil: 'load', timeout: 20000 });
    await page.evaluate(() => document.fonts && document.fonts.ready);
    return Buffer.from(await page.screenshot({ type: 'jpeg', quality: 94, fullPage: true }));
  } finally {
    await browser.close();
  }
}

// POST /api/examination/download-test-plan-jpg
// Render the exact Test Plan preview as a high-resolution JPG.
router.post('/download-test-plan-jpg', async (req, res) => {
  try {
    const html = String(req.body.html || '');
    if (!html.trim()) return res.status(400).json({ success: false, error: 'Test plan preview is required' });
    if (html.length > 2 * 1024 * 1024) return res.status(400).json({ success: false, error: 'Test plan is too large to render' });

    const jpg = await renderHTMLtoJPG(html);
    const safeName = String(req.body.filename || 'VCC_TEST_PLAN').replace(/[^a-z0-9_-]+/gi, '_');
    res.setHeader('Content-Type', 'image/jpeg');
    res.setHeader('Content-Disposition', `attachment; filename="${safeName}.jpg"`);
    res.send(jpg);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Parse "DD-MM-YYYY" test_date into a comparable integer YYYYMMDD for sorting/filtering
function parseTestDate(ddmmyyyy) {
  if (!ddmmyyyy || typeof ddmmyyyy !== 'string') return 0;
  const parts = ddmmyyyy.split('-');
  if (parts.length !== 3) return 0;
  return parseInt(parts[2] + parts[1] + parts[0]); // YYYYMMDD
}

// Is DD-MM-YYYY inside the from→to month range?
function inRange(ddmmyyyy, fromMonth, fromYear, toMonth, toYear) {
  const parts = ddmmyyyy.split('-');
  if (parts.length !== 3) return false;
  const m = parseInt(parts[1]);
  const y = parseInt(parts[2]);
  const val    = y * 100 + m;
  const valFrom = fromYear * 100 + fromMonth;
  const valTo   = toYear  * 100 + toMonth;
  return val >= valFrom && val <= valTo;
}

// Build all placeholders and return rendered HTML
async function buildReportHTML(student_uid, fromMonth, fromYear, toMonth, toYear) {
  // 1. Fetch student
  const students = await query('SELECT * FROM students WHERE student_uid = ?', [student_uid]);
  if (!students.length) throw new Error('Student not found: ' + student_uid);
  const student = students[0];

  // 2. Parse dates → YYYYMMDD integer for comparison
  // test_date is DD-MM-YYYY, admission_date is YYYY-MM-DD
  function testDateToInt(ddmmyyyy) {
    if (!ddmmyyyy) return 0;
    const p = ddmmyyyy.split('-');
    if (p.length !== 3) return 0;
    return parseInt(p[2] + p[1] + p[0]); // DD-MM-YYYY → YYYYMMDD
  }
  function admissionDateToInt(yyyymmdd) {
    if (!yyyymmdd) return 0;
    return parseInt(yyyymmdd.replace(/-/g, '')); // YYYY-MM-DD → YYYYMMDD
  }
  const admissionInt = admissionDateToInt(student.admission_date);

  // 3. Fetch ALL award_lists for this student's class+section in date range
  //    (regardless of whether student has an entry)
  // Fetch ALL award_lists for class+section, then filter by group in JS
  // group logic: show tests where group_name matches student's group OR group_name is empty/null (common subjects)
  const allLists = await query(
    `SELECT id, subject, test_date, total_marks, class, section, group_name, session
     FROM award_lists
     WHERE class = ? AND section = ?
     ORDER BY substr(test_date,7,4)||substr(test_date,4,2)||substr(test_date,1,2) ASC`,
    [student.class, student.section || '']
  );

  // Group filter:
  // award_list group_name can be "BIO", "COMP", "COMP, BIO", "BIO, COMP", or ""
  // Rule: show the test if the student's group appears anywhere in the award_list's group_name
  // e.g. student=BIO → show "BIO", "COMP, BIO", "BIO, COMP", "" → exclude "COMP" only
  const studentGroup = (student.group_name || '').trim().toUpperCase();
  const filteredLists = allLists.filter(al => {
    const alGroup = (al.group_name || '').trim().toUpperCase();
    if (alGroup === '') return true;              // no group = common subject, always show
    if (!studentGroup) return true;              // student has no group, show everything
    // Split award_list group_name by comma and check if student's group is included
    const alGroups = alGroup.split(',').map(g => g.trim());
    return alGroups.includes(studentGroup);
  });

  // Filter to date range
  const listsInRange = filteredLists.filter(al =>
    inRange(al.test_date, parseInt(fromMonth), parseInt(fromYear), parseInt(toMonth), parseInt(toYear))
  );

  // 4. Fetch this student's actual entries (all, we'll match by award_list_id)
  const myEntries = await query(
    `SELECT ale.award_list_id, ale.marks_obtained, ale.special_status
     FROM award_list_entries ale
     WHERE ale.student_uid = ?`,
    [student_uid]
  );
  const entryMap = {};
  myEntries.forEach(e => { entryMap[e.award_list_id] = e; });

  // 5. Build TEST_ROWS — one row per award_list in range
  const testRows = listsInRange.map((al, i) => {
    const testInt    = testDateToInt(al.test_date);
    const beforeAdmission = admissionInt > 0 && testInt > 0 && testInt < admissionInt;
    const entry      = entryMap[al.id];

    let marksCell, rowStyle;

    if (beforeAdmission) {
      // Test was before student joined — greyed out, "Not Admitted"
      marksCell = '<span style="color:#999;font-style:italic;">Not Admitted</span>';
      rowStyle  = 'style="color:#aaa;"';
    } else if (!entry) {
      // Student should have been in this test but no entry exists
      marksCell = '<span style="color:#cc0000;font-weight:700;">Absent</span>';
      rowStyle  = '';
    } else {
      const isAbsent = entry.special_status === 'ABSENT' || entry.special_status === 'NOT_ADMITTED';
      if (isAbsent) {
        marksCell = '<span style="color:#cc0000;font-weight:700;">Absent</span>';
      } else {
        const rawMarks = (entry.marks_obtained !== null && entry.marks_obtained !== undefined) ? entry.marks_obtained : null;
        marksCell = rawMarks !== null ? formatMarksValue(rawMarks) : '—';
      }
      rowStyle = '';
    }

    return `<tr ${rowStyle}>
      <td>${i + 1}</td>
      <td style="text-align:left;">${al.subject || ''}</td>
      <td>${al.test_date || ''}</td>
      <td>${al.total_marks || ''}</td>
      <td>${marksCell}</td>
    </tr>`;
  }).join('\n');

  // Pad with empty rows so table always has at least 15 rows (looks better on PDF)
  const MIN_ROWS = 15;
  const actualRows = listsInRange.length;
  let emptyRows = '';
  if (actualRows < MIN_ROWS) {
    for (let i = actualRows; i < MIN_ROWS; i++) {
      emptyRows += `<tr>
        <td style="color:#ccc;">${i + 1}</td>
        <td></td><td></td><td></td><td></td>
      </tr>\n`;
    }
  }
  const finalTestRows = testRows + emptyRows;

  const entries = listsInRange; // for return value compatibility

  // 4. Compute MONTHS_INCLUDED label
  const MONTH_NAMES = ['January','February','March','April','May','June',
                       'July','August','September','October','November','December'];
  let monthsIncluded;
  if (fromYear === toYear && fromMonth === toMonth) {
    monthsIncluded = MONTH_NAMES[parseInt(fromMonth) - 1] + ' ' + fromYear;
  } else {
    monthsIncluded = MONTH_NAMES[parseInt(fromMonth) - 1] + ' ' + fromYear +
                     ' to ' + MONTH_NAMES[parseInt(toMonth) - 1] + ' ' + toYear;
  }

  // 5. Load settings
  const settingRows = await query('SELECT key, value FROM settings');
  const settings = {};
  settingRows.forEach(r => { settings[r.key] = r.value; });

  // 6. Logo as inline <img> tag with base64 src (avoids file:// raw-text rendering bug)
  let logoTag = '';
  try {
    const logoPath = path.join(__dirname, '../../frontend/assets/logo.png');
    if (fs.existsSync(logoPath)) {
      const buf = fs.readFileSync(logoPath);
      const b64 = buf.toString('base64');
      logoTag = '<img class="logo" src="data:image/png;base64,' + b64 + '" style="width:90px;height:90px;object-fit:contain;" />';
    }
  } catch(_) {}

  // 7. GROUP_SUFFIX
  const groupSuffix = student.group_name ? ' (' + student.group_name + ')' : '';

  // 8. Fetch template from DB
  const tmplRows = await query("SELECT value FROM settings WHERE key = 'exam_report_template'");
  let template = (tmplRows[0] && tmplRows[0].value) ? tmplRows[0].value : DEFAULT_EXAM_TEMPLATE;

  // 9. Substitute all placeholders
  const html = template
    .replace(/\{\{STUDENT_NAME\}\}/g,   student.name          || '')
    .replace(/\{\{FATHER_NAME\}\}/g,    student.father_name   || '')
    .replace(/\{\{ADMISSION_DATE\}\}/g, (function(){
      const d = student.admission_date || '';
      if (!d) return '';
      const p = d.split('-');
      return p.length === 3 ? p[2] + '-' + p[1] + '-' + p[0] : d; // YYYY-MM-DD → DD-MM-YYYY
    })())
    .replace(/\{\{CLASS\}\}/g,          student.class         || '')
    .replace(/\{\{SECTION\}\}/g,        student.section       || '')
    .replace(/\{\{GROUP_SUFFIX\}\}/g,   groupSuffix)
    .replace(/\{\{GR_NUMBER\}\}/g,      student.gr_number     || '')
    .replace(/\{\{MONTHS_INCLUDED\}\}/g, monthsIncluded)
    .replace(/\{\{TEST_ROWS\}\}/g,      finalTestRows || '<tr><td colspan="5" style="text-align:center;color:#888;">No tests found in this date range.</td></tr>')
    .replace(/\{\{LOGO_IMG\}\}/g,       logoTag)
    .replace(/\{\{VCC_NAME\}\}/g,       settings.vcc_name  || 'Vectors Coaching Centre')
    .replace(/\{\{PHONE1\}\}/g,         settings.contact   || '')
    .replace(/\{\{PHONE2\}\}/g,         settings.contact2  || '')
    .replace(/\{\{ADDRESS\}\}/g,        settings.address   || '')
    .replace(/\{\{CAMPUS\}\}/g,         settings.campus    || '');

  return { html, student, entries };
}

// POST /api/examination/generate-report
// Body: { student_uid, from_month, from_year, to_month, to_year }
// Returns PDF buffer as application/pdf
router.post('/generate-report', async (req, res) => {
  try {
    const { student_uid, from_month, from_year, to_month, to_year } = req.body;
    if (!student_uid || !from_month || !from_year || !to_month || !to_year) {
      return res.status(400).json({ success: false, error: 'student_uid, from_month, from_year, to_month, to_year are required' });
    }

    const { html, student } = await buildReportHTML(student_uid, from_month, from_year, to_month, to_year);
    const pdfBuffer = await renderHTMLtoPDF(html);

    const filename = `${(student.name || 'REPORT').toUpperCase()} TEST REPORT.pdf`;
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.send(pdfBuffer);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/send-report
// Body: { student_uid, from_month, from_year, to_month, to_year, caption }
// Generates PDF and sends via WhatsApp smartSendFile
router.post('/send-report', async (req, res) => {
  try {
    const { student_uid, from_month, from_year, to_month, to_year, caption } = req.body;
    if (!student_uid || !from_month || !from_year || !to_month || !to_year) {
      return res.status(400).json({ success: false, error: 'student_uid, from_month, from_year, to_month, to_year are required' });
    }

    const { html, student } = await buildReportHTML(student_uid, from_month, from_year, to_month, to_year);
    const pdfBuffer = await renderHTMLtoPDF(html);

    const filename = `${(student.name || 'REPORT').toUpperCase()} TEST REPORT.pdf`;
    const { smartSendFile } = require('../whatsapp');
    const db = getDb();

    const result = await smartSendFile(student, pdfBuffer, filename, caption || '', db);

    try {
      await run(
        'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, caption, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          student.name, student.class, result.phone,
          '[PDF: Test Report]', 'EXAM_REPORT', 'EXAM_REPORT',
          result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
          (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0],
          result.msgId || null,
          result.usedFallback ? 1 : 0,
          student_uid,
          caption || '',
          result.sent ? null : result.reason
        ]
      );
    } catch(e) {}

    res.json({
      success: result.sent || result.queued,
      queued: !!result.queued,
      sent: result.sent,
      phone: result.phone,
      usedFallback: result.usedFallback || false,
      error: result.reason || null
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
// GET /api/examination/test-plan-template
router.get('/test-plan-template', async (req, res) => {
  try {
    const rows = await query("SELECT value FROM settings WHERE key = 'test_plan_template'");
    if (rows[0] && rows[0].value) {
      res.json({ success: true, template: rows[0].value });
    } else {
      res.json({ success: false, template: null });
    }
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/test-plan-template
router.post('/test-plan-template', async (req, res) => {
  try {
    const { template } = req.body;
    if (!template) return res.status(400).json({ success: false, error: 'template required' });
    await query(
      "INSERT INTO settings(key, value) VALUES('test_plan_template', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      [template]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/notice-text — save Weekly Test Plan notice (EN + UR)
router.post('/notice-text', async (req, res) => {
  try {
    const { notice_en, notice_ur } = req.body;
    if (!notice_en) return res.status(400).json({ success: false, error: 'notice_en required' });
    await query(
      "INSERT INTO settings(key, value) VALUES('notice_en', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
      [notice_en]
    );
    if (notice_ur) {
      await query(
        "INSERT INTO settings(key, value) VALUES('notice_ur', ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value",
        [notice_ur]
      );
    }
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/examination/students-for-plan?class=&section=&group=
// Returns active students matching class + section + group (for WA send panel)
router.get('/students-for-plan', async (req, res) => {
  try {
    const { class: cls, section, group: grp } = req.query;
    if (!cls) return res.status(400).json({ success: false, error: 'class is required' });

    let sql = "SELECT student_uid, name, class, section, group_name, parent_phone, parent_phone2 FROM students WHERE class = ? AND (status = 'active' OR status IS NULL OR status = '')";
    const args = [cls];

    if (section) { sql += ' AND section = ?'; args.push(section); }
    if (grp)     { sql += " AND (group_name = ? OR group_name LIKE ? OR group_name LIKE ? OR group_name LIKE ?)"; args.push(grp, grp + ',%', '%,' + grp, '%,' + grp + ',%'); }

    sql += ' ORDER BY name';
    const students = await query(sql, args);

    const result = students.map(s => ({
      student_uid: s.student_uid,
      name: s.name,
      class: s.class,
      section: s.section,
      group_name: s.group_name,
      phone: s.parent_phone || s.parent_phone2 || null
    }));

    res.json({ success: true, students: result });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/examination/send-test-plan-pdf
// Body: { student_uid, class, section, group, month, year }
// Generates test plan PDF and sends to that specific student via WhatsApp
router.post('/send-test-plan-pdf', async (req, res) => {
  try {
    const { student_uid, class: cls, section, group: grp, month, year } = req.body;
    if (!student_uid || !cls || !month || !year) {
      return res.status(400).json({ success: false, error: 'student_uid, class, month, year are required' });
    }

    // Fetch student
    const [student] = await query('SELECT * FROM students WHERE student_uid = ?', [student_uid]);
    if (!student) return res.status(404).json({ success: false, error: 'Student not found' });

    // Fetch test plan rows
    const params = [cls, section || '', parseInt(month), parseInt(year), grp || ''];
    const planRows = await query(
      'SELECT * FROM test_plans WHERE class = ? AND section = ? AND month = ? AND year = ? AND grp = ? ORDER BY test_date ASC',
      params
    );
    if (!planRows.length) return res.status(404).json({ success: false, error: 'No test plan found for this class/month/year' });

    // Fetch settings for PDF generation
    const settingRows = await query("SELECT key, value FROM settings WHERE key IN ('vcc_name','vcc_phone1','vcc_phone2','vcc_address','sessions','notice_en','notice_ur','test_plan_template','contact')");
    const s = {};
    settingRows.forEach(r => s[r.key] = r.value);

    const mnNames = ['','January','February','March','April','May','June','July','August','September','October','November','December'];
    const monthName  = mnNames[parseInt(month)] || String(month);
    const classLabel = cls + (section ? ' - ' + section : '') + (grp ? ' (' + grp + ')' : '');
    const vccName    = (s.vcc_name || 'VECTORS COACHING CENTRE').toUpperCase();
    const vccPhone   = s.vcc_phone1 || '0330-8155168';
    const vccPhone2  = s.vcc_phone2 || '021-34110685';
    const vccAddress = s.vcc_address || '';
    const sessionLabel = s.sessions || ((parseInt(year)-1) + '-' + String(year).slice(-2));

    const DEFAULT_EN = `We are pleased to announce the Weekly Test Plan for the Month of {MONTH} for Class {CLASS} (Session {SESSION}). These tests are a vital part of our academic routine, designed to regularly assess students understanding and progress in their subjects.\n\nThe detailed test schedule and timings are provided below. We kindly request your continued support in ensuring that your child is well-prepared and punctual for each test.\n\nAdministrator\nVectors Coaching Centre (VCC)`;
    const DEFAULT_UR = `ہمیں اعلان کرتے ہوئے خوشی ہورہی ہے کہ جماعت ({CLASS}، Session {SESSION}) کے لیے {MONTH} کے مہینے کا ہفتہ وار امتحانی نظام الاوقات جاری کر دیا گیا ہے۔ یہ ٹیسٹ ہمارے تعلیمی نظام کا ایک اہم حصہ ہیں، جن کا مقصد طلباء کی تعلیمی کارکردگی اور فہم کو باقاعدگی سے جانچنا ہے۔\n\nتفصیلی شیڈول اور اوقات درج ذیل ہیں۔ ہم آپ سے مؤدبانہ گزارش کرتے ہیں کہ آپ اپنے بچے کی مکمل تیاری اور بروقت حاضری کو یقینی بنانے میں ہمارا ساتھ دیں۔\n\nایڈمنسٹریٹر\nویکٹرز کوچنگ سینٹر (VCC)`;
    const noticeEnSaved = s.notice_en || '';
    const noticeUrSaved = s.notice_ur || '';
    // If saved notice has no placeholders (was baked with a specific class), fall back to DEFAULT so correct classLabel is used
    const enBase = (noticeEnSaved.includes('{CLASS}') || noticeEnSaved.includes('{MONTH}')) ? noticeEnSaved : DEFAULT_EN;
    const urBase = (noticeUrSaved.includes('{CLASS}') || noticeUrSaved.includes('{MONTH}')) ? noticeUrSaved : DEFAULT_UR;
    const noticeEn = enBase.replace(/{CLASS}/g, classLabel).replace(/{MONTH}/g, monthName).replace(/{SESSION}/g, sessionLabel);
    const noticeUr = urBase.replace(/{CLASS}/g, classLabel).replace(/{MONTH}/g, monthName).replace(/{SESSION}/g, sessionLabel);

    const rowsHtml = planRows.map((row, i) => `
      <tr>
        <td>${i+1}</td>
        <td>${row.test_date||''}</td>
        <td>${row.day||''}</td>
        <td>${row.timing||''}</td>
        <td><strong>${row.subject||''}</strong></td>
      </tr>`).join('');

    // Load template or use default
    const logoPath = path.join(__dirname, '../../frontend/assets/logo.png');
    let logoB64 = '';
    try {
      if (fs.existsSync(logoPath)) {
        const buf = fs.readFileSync(logoPath);
        logoB64 = `<img src="data:image/png;base64,${buf.toString('base64')}" style="width:100%;height:100%;object-fit:contain;">`;
      }
    } catch(e) {}

    const TPL_DEFAULT = `<!DOCTYPE html><html><head><meta charset="UTF-8">
<style>
body{font-family:Arial,sans-serif;font-size:11pt;margin:0;padding:12mm 14mm;}
.header{display:flex;align-items:center;gap:12px;border-bottom:2px solid #000;padding-bottom:8px;margin-bottom:6px;}
.logo{width:60px;height:60px;flex-shrink:0;}
.vcc-name{font-size:20pt;font-weight:900;text-decoration:underline;flex:1;text-align:center;}
.dept{text-align:center;font-size:12pt;border:1px solid #000;padding:3px 0;margin:6px 0;}
.plan-title{text-align:center;font-size:14pt;font-weight:900;text-decoration:underline;margin:8px 0 10px;}
.notice{font-size:10pt;line-height:1.6;margin-bottom:10px;white-space:pre-wrap;}
.notice-ur{font-size:10pt;line-height:1.8;direction:rtl;text-align:right;margin:10px 0;}
.schedule-box{border:2px solid #000;padding:10px;margin-top:12px;}
.schedule-title{font-size:12pt;font-weight:900;text-align:center;text-decoration:underline;margin-bottom:8px;}
table{width:100%;border-collapse:collapse;}
th{border:1px solid #000;padding:5px 8px;font-weight:700;font-size:10pt;text-align:center;background:#f0f0f0;}
td{border:1px solid #000;padding:5px 8px;font-size:10pt;text-align:center;}
.footer{margin-top:20px;border-top:1px solid #000;padding-top:6px;font-size:8.5pt;text-align:center;color:#333;}
</style></head><body>
<div class="header">
<div class="logo">{{LOGO_IMG}}</div>
<div class="vcc-name">{{VCC_NAME}}</div>
</div>
<div class="dept">WEEKLY TEST PLAN — {{MONTH}} {{YEAR}} — SESSION {{SESSION}}</div>
<div class="plan-title">CLASS: {{CLASS}}</div>
<div class="notice">{{NOTICE_EN}}</div>
<div class="notice-ur">{{NOTICE_UR}}</div>
<div class="schedule-box">
<div class="schedule-title">TEST SCHEDULE</div>
<table><thead><tr><th>#</th><th>Date</th><th>Day</th><th>Time</th><th>Subject</th></tr></thead>
<tbody>{{SCHEDULE_ROWS}}</tbody></table></div>
<div class="footer">{{PHONE1}} | {{PHONE2}} | {{ADDRESS}}</div>
</body></html>`;

    let tplHtml = TPL_DEFAULT;
    try {
      const tplRows = await query("SELECT value FROM settings WHERE key = 'test_plan_template'");
      if (tplRows[0] && tplRows[0].value) tplHtml = tplRows[0].value;
    } catch(e) {}

    const finalHtml = tplHtml
      .replace(/\{\{VCC_NAME\}\}/g, vccName)
      .replace(/\{\{LOGO_IMG\}\}/g, logoB64)
      .replace(/\{\{CLASS\}\}/g, classLabel)
      .replace(/\{\{SECTION\}\}/g, section || '')
      .replace(/\{\{MONTH\}\}/g, monthName.toUpperCase())
      .replace(/\{\{YEAR\}\}/g, year)
      .replace(/\{\{SESSION\}\}/g, sessionLabel)
      .replace(/\{\{NOTICE_EN\}\}/g, noticeEn.replace(/\n/g, '<br>'))
      .replace(/\{\{NOTICE_UR\}\}/g, noticeUr.replace(/\n/g, '<br>'))
      .replace(/\{\{SCHEDULE_ROWS\}\}/g, rowsHtml)
      .replace(/\{\{PHONE1\}\}/g, vccPhone)
      .replace(/\{\{PHONE2\}\}/g, vccPhone2)
      .replace(/\{\{ADDRESS\}\}/g, vccAddress);

    const pdfBuffer = await renderHTMLtoPDF(finalHtml);
 const filename = `Test Plan ${classLabel} ${monthName} ${year}.pdf`;
    const caption   = `Weekly Test Plan — ${classLabel} | ${monthName} ${year}`;

    const { smartSendFile } = require('../whatsapp');
    const db = getDb();
    const result = await smartSendFile(student, pdfBuffer, filename, caption, db);

    try {
      await run(
        'INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, log_type, status, retry_until, msg_id, used_phone2, student_uid, caption, fail_reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          student.name, student.class, result.phone,
          '[PDF: Test Plan]', 'TEST_PLAN_PDF', 'TEST_PLAN_PDF',
          result.queued ? 'queued' : result.sent ? 'sent' : 'failed',
          (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T',' ').split('.')[0],
          result.msgId || null,
          result.usedFallback ? 1 : 0,
          student_uid, caption,
          result.sent ? null : result.reason
        ]
      );
    } catch(e) {}

    res.json({
      success: result.sent || result.queued,
      queued: !!result.queued,
      sent: result.sent,
      phone: result.phone,
      usedFallback: result.usedFallback || false,
      error: result.reason || null
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
