const express = require('express');
const router = express.Router();
const https = require('https');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { query } = require('../database');
const extractZip = promisify(execFile);

const ROOT_DIR = path.resolve(__dirname, '../..');
const UPDATE_DIR = path.join(ROOT_DIR, '_updates');
const MAX_UPDATE_BYTES = 100 * 1024 * 1024;
const TRUSTED_HOSTS = new Set([
  'api.github.com', 'github.com', 'objects.githubusercontent.com',
  'release-assets.githubusercontent.com', 'raw.githubusercontent.com'
]);
const ALLOWED_ROOT_DIRS = new Set(['backend', 'frontend']);
const ALLOWED_ROOT_FILES = new Set([
  'package.json', 'package-lock.json', 'start.bat', 'setup.bat',
  'kiosk.bat', 'kiosk-launcher.ps1', 'Create Kiosk Shortcut.bat',
  'README.md', 'SETUP.md', '.env.example', 'vcc-update.json'
]);

function safeVersion(value) {
  const match = String(value || '').trim().match(/^v?(\d+)\.(\d+)\.(\d+)$/);
  if (!match) return null;
  return { text:`${Number(match[1])}.${Number(match[2])}.${Number(match[3])}`, parts:match.slice(1).map(Number) };
}
function isNewerVersion(local, remote) {
  const left=safeVersion(local),right=safeVersion(remote);
  if (!left || !right) return false;
  for(let i=0;i<3;i++){if(right.parts[i]!==left.parts[i])return right.parts[i]>left.parts[i]}
  return false;
}
function validRepository(value) {
  const text=String(value||'').trim().replace(/^https:\/\/github\.com\//i,'').replace(/\.git$/i,'').replace(/^\/+|\/+$/g,'');
  return /^[A-Za-z0-9_.-]+\/[A-Za-z0-9_.-]+$/.test(text) ? text : null;
}
function trustedUrl(value) {
  const parsed=new URL(value);
  if(parsed.protocol!=='https:'||!TRUSTED_HOSTS.has(parsed.hostname))throw new Error('GitHub returned an untrusted download address.');
  return parsed;
}
function githubHeaders(accept='application/vnd.github+json') {
  const headers={'User-Agent':'VCC-Attendance-System','Accept':accept,'X-GitHub-Api-Version':'2022-11-28'};
  if(process.env.GITHUB_TOKEN)headers.Authorization='Bearer '+process.env.GITHUB_TOKEN;
  return headers;
}
function getBuffer(url,{headers={},maxBytes=MAX_UPDATE_BYTES,redirects=0,onProgress}={}) {
  return new Promise((resolve,reject)=>{
    let parsed;try{parsed=trustedUrl(url)}catch(error){return reject(error)}
    const request=https.get(parsed,{headers},response=>{
      if([301,302,303,307,308].includes(response.statusCode)){
        response.resume();if(redirects>=5)return reject(new Error('Too many GitHub redirects.'));
        if(!response.headers.location)return reject(new Error('GitHub redirect has no destination.'));
        return getBuffer(new URL(response.headers.location,parsed).toString(),{headers,maxBytes,redirects:redirects+1,onProgress}).then(resolve,reject);
      }
      if(response.statusCode!==200){response.resume();return reject(new Error('GitHub request failed (HTTP '+response.statusCode+').'))}
      const declared=Number(response.headers['content-length']||0);if(declared>maxBytes){response.resume();return reject(new Error('Update package is larger than the allowed limit.'))}
      const chunks=[];let size=0;
      response.on('error',reject);
      response.on('aborted',()=>reject(new Error('GitHub interrupted the update download.')));
      onProgress?.(0,declared);
      response.on('data',chunk=>{size+=chunk.length;if(size>maxBytes){request.destroy(new Error('Update package exceeded the allowed limit.'));return}chunks.push(chunk);onProgress?.(size,declared)});
      response.on('end',()=>resolve(Buffer.concat(chunks,size)));
    });
    request.setTimeout(30000,()=>request.destroy(new Error('GitHub request timed out.')));
    request.on('error',reject);
  });
}
async function githubJson(url){const buffer=await getBuffer(url,{headers:githubHeaders(),maxBytes:5*1024*1024});try{return JSON.parse(buffer.toString('utf8'))}catch(_){throw new Error('GitHub returned an invalid response.')}}
async function configuredRepository(){
  const rows=await query("SELECT value FROM settings WHERE key='update_repository' LIMIT 1").catch(()=>[]);
  const stored=rows[0]?.value;
  return validRepository(stored)||validRepository(process.env.GITHUB_REPOSITORY)||validRepository(process.env.GITHUB_OWNER&&process.env.GITHUB_REPO?process.env.GITHUB_OWNER+'/'+process.env.GITHUB_REPO:'');
}
function currentVersion(){try{return safeVersion(JSON.parse(fs.readFileSync(path.join(ROOT_DIR,'package.json'),'utf8')).version)?.text||'1.0.0'}catch(_){return '1.0.0'}}
async function latestRelease(repo){
  // New updater feed: the source repository stays private while a separate
  // public repository exposes only the current verified update package.
  // Keeping a tiny latest.json file also means client PCs need no GitHub
  // account, token or stored credential.
  try {
    const feedUrl=`https://raw.githubusercontent.com/${repo}/main/latest.json`;
    const feed=await githubJson(feedUrl);
    const feedVersion=safeVersion(feed.version);
    if(!feedVersion)throw new Error('Public update feed has an invalid version.');
    const zipName=String(feed.zip||`VCC-Update-v${feedVersion.text}.zip`);
    const checksumName=String(feed.checksum||zipName+'.sha256');
    const expectedZip=`VCC-Update-v${feedVersion.text}.zip`;
    if(zipName!==expectedZip||checksumName!==expectedZip+'.sha256')throw new Error('Public update feed has invalid package names.');
    const rawBase=`https://raw.githubusercontent.com/${repo}/main/`;
    return {
      body:{body:String(feed.releaseNotes||''),published_at:String(feed.publishedAt||'')},
      version:feedVersion.text,
      zip:{name:zipName,size:Number(feed.zipSize||0),url:rawBase+zipName},
      checksum:{name:checksumName,size:Number(feed.checksumSize||0),url:rawBase+checksumName},
      zipName
    };
  } catch (feedError) {
    // Compatibility path for the first upgrade from older installations and
    // for repositories that still publish conventional GitHub Releases.
    if(!/HTTP 404/.test(String(feedError.message||'')) && !/invalid/i.test(String(feedError.message||'')))throw feedError;
  }
  const body=await githubJson(`https://api.github.com/repos/${repo}/releases/latest`);
  if(body.message==='Not Found')throw new Error('GitHub repository or release was not found. Check repository access.');
  const version=safeVersion(body.tag_name||body.name);
  if(!version)throw new Error('Latest GitHub release must use a version tag such as v1.0.1.');
  const zipName=`VCC-Update-v${version.text}.zip`;
  const zip=(body.assets||[]).find(asset=>asset.name===zipName);
  const checksum=(body.assets||[]).find(asset=>asset.name===zipName+'.sha256');
  return{body,version:version.text,zip,checksum,zipName};
}
function ensureInside(base,target){const root=path.resolve(base)+path.sep,resolved=path.resolve(target);if(resolved!==path.resolve(base)&&!resolved.startsWith(root))throw new Error('Unsafe update path detected.');return resolved}
function walkFiles(root,current=root,result=[]){for(const entry of fs.readdirSync(current,{withFileTypes:true})){const full=ensureInside(root,path.join(current,entry.name));if(entry.isSymbolicLink())throw new Error('Update package contains an unsupported link.');if(entry.isDirectory())walkFiles(root,full,result);else if(entry.isFile())result.push(full);else throw new Error('Update package contains an unsupported item.')}return result}
function locateSource(extractDir){const entries=fs.readdirSync(extractDir,{withFileTypes:true});if(entries.length===1&&entries[0].isDirectory())return path.join(extractDir,entries[0].name);return extractDir}
async function validateStaging(source,expectedVersion,onProgress){
  const manifestPath=path.join(source,'vcc-update.json');if(!fs.existsSync(manifestPath))throw new Error('Update manifest is missing.');
  const manifest=JSON.parse(fs.readFileSync(manifestPath,'utf8'));
  if(manifest.format!==1||safeVersion(manifest.version)?.text!==expectedVersion||!Array.isArray(manifest.files)||!manifest.files.length)throw new Error('Update manifest is invalid.');
  const actual=walkFiles(source).map(file=>path.relative(source,file).replace(/\\/g,'/')).filter(rel=>rel!=='vcc-update.json').sort();
  const declared=manifest.files.map(item=>String(item.path||'').replace(/\\/g,'/')).sort();
  if(new Set(declared).size!==declared.length||JSON.stringify(actual)!==JSON.stringify(declared))throw new Error('Update package contents do not match its manifest.');
  let verified=0;
  onProgress?.(verified,manifest.files.length);
  for(const item of manifest.files){
    const rel=String(item.path).replace(/\\/g,'/');if(rel.startsWith('/')||rel.includes('../')||rel.includes('..\\'))throw new Error('Unsafe file path in update manifest.');
    const top=rel.split('/')[0];if(!ALLOWED_ROOT_DIRS.has(top)&&!ALLOWED_ROOT_FILES.has(rel))throw new Error('Update contains a protected or unsupported file: '+rel);
    const file=ensureInside(source,path.join(source,...rel.split('/')));const digest=crypto.createHash('sha256').update(await fs.promises.readFile(file)).digest('hex');if(digest!==String(item.sha256||'').toLowerCase())throw new Error('File verification failed: '+rel);
    onProgress?.(++verified,manifest.files.length);
  }
  const pkg=JSON.parse(fs.readFileSync(path.join(source,'package.json'),'utf8'));if(safeVersion(pkg.version)?.text!==expectedVersion)throw new Error('Package version does not match the release.');
  return manifest;
}
async function releaseInfo(){
  const repository=await configuredRepository();
  if(!repository)return{success:false,configurationRequired:true,currentVersion:currentVersion(),error:'Enter the GitHub repository (owner/repository) below and save it first.'};
  const release=await latestRelease(repository);const local=currentVersion();
  return{success:true,repository,currentVersion:local,latestVersion:release.version,hasUpdate:isNewerVersion(local,release.version),releaseNotes:release.body.body||'',publishedAt:release.body.published_at||'',packageReady:!!release.zip&&!!release.checksum,release};
}

router.get('/check',async(_req,res)=>{try{const info=await releaseInfo();if(!info.success)return res.status(400).json(info);res.json({...info,release:undefined})}catch(error){res.status(502).json({success:false,currentVersion:currentVersion(),error:error.message})}});
let prepareProgress=null;
router.get('/status',(_req,res)=>{let pending=null,lastResult=null;try{pending=JSON.parse(fs.readFileSync(path.join(UPDATE_DIR,'pending.json'),'utf8'))}catch(_){}try{lastResult=JSON.parse(fs.readFileSync(path.join(UPDATE_DIR,'last-result.json'),'utf8'))}catch(_){}res.set('Cache-Control','no-store').json({success:true,pending,lastResult,currentVersion:currentVersion(),prepareProgress})});
router.post('/download',async(_req,res)=>{
  if(prepareProgress)return res.status(409).json({success:false,inProgress:true,error:'An update is already being prepared.'});
  prepareProgress={phase:'checking'};
  try{
    if(fs.existsSync(path.join(UPDATE_DIR,'pending.json'))){const pending=JSON.parse(fs.readFileSync(path.join(UPDATE_DIR,'pending.json'),'utf8'));return res.json({success:true,staged:true,version:pending.version,message:'A verified update is already ready for restart.'})}
    const info=await releaseInfo();if(!info.success)return res.status(400).json(info);if(!info.hasUpdate)return res.status(409).json({success:false,error:'This PC is already on the latest version.'});
    const {release}=info;if(!release.zip||!release.checksum)return res.status(409).json({success:false,error:'Release is incomplete: verified update ZIP and SHA256 file are both required.'});
    if(Number(release.zip.size||0)>MAX_UPDATE_BYTES)throw new Error('Update package is larger than 100 MB.');
    fs.mkdirSync(UPDATE_DIR,{recursive:true});
    const zipPath=path.join(UPDATE_DIR,release.zipName),extractDir=path.join(UPDATE_DIR,'staging-'+release.version.replace(/\./g,'-'));
    await fs.promises.rm(extractDir,{recursive:true,force:true});fs.mkdirSync(extractDir,{recursive:true});
    const startedAt=Date.now();
    const downloadProgress={phase:'downloading',received:0,total:Number(release.zip.size)||0,startedAt};
    prepareProgress=downloadProgress;
    const [zip,checksumBody]=await Promise.all([
      getBuffer(release.zip.url,{headers:githubHeaders('application/octet-stream'),onProgress(received,total){
        downloadProgress.received=received;
        downloadProgress.total=total||Number(release.zip.size)||0;
      }}),
      getBuffer(release.checksum.url,{headers:githubHeaders('application/octet-stream'),maxBytes:4096})
    ]);
    prepareProgress={phase:'checksum'};
    const expected=(checksumBody.toString('utf8').match(/\b[a-f0-9]{64}\b/i)||[])[0]?.toLowerCase();
    const actual=crypto.createHash('sha256').update(zip).digest('hex');if(!expected||expected!==actual)throw new Error('Update checksum verification failed; nothing was staged.');
    await fs.promises.writeFile(zipPath,zip,{flag:'w'});
    prepareProgress={phase:'extracting'};
    try {
      await extractZip('tar.exe',['-xf',zipPath,'-C',extractDir],{windowsHide:true});
    } catch (_) {
      throw new Error('Could not extract the verified update package.');
    }
    const source=locateSource(extractDir);
    prepareProgress={phase:'verifying',verified:0,total:0};
    await validateStaging(source,release.version,(verified,total)=>{
      prepareProgress={phase:'verifying',verified,total};
    });
    const pending={format:1,version:release.version,repository:info.repository,source:path.relative(ROOT_DIR,source),sha256:actual,createdAt:new Date().toISOString()};
    fs.writeFileSync(path.join(UPDATE_DIR,'pending.json'),JSON.stringify(pending,null,2));
    try{fs.unlinkSync(zipPath)}catch(_){}
    res.json({success:true,staged:true,version:release.version,message:'Update verified and ready. Close VCC and run start.bat; it will apply automatically with backup and rollback.'});
  }catch(error){res.status(500).json({success:false,error:error.message})}finally{prepareProgress=null}
});

module.exports=router;
module.exports._test={safeVersion,isNewerVersion,validRepository,trustedUrl,validateStaging,ensureInside,ALLOWED_ROOT_FILES,ALLOWED_ROOT_DIRS};
