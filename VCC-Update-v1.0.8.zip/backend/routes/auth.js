const express = require('express');
const router = express.Router();
const fs = require('fs');
const path = require('path');

// Simple in-memory brute-force guard for /login and /verify.
// Keyed by session ID for /verify (already logged in), and by IP for /login
// (not logged in yet, so no session identity to trust).
// 5 wrong attempts → 15-minute lockout.
const verifyAttempts = new Map(); // sessionId → { count, lockedUntil }
const loginAttempts = new Map();  // ip → { count, lockedUntil }
const MAX_ATTEMPTS = 5;
const LOCKOUT_MS = 15 * 60 * 1000;

// Prune expired lockout entries every 30 minutes to prevent memory leak
setInterval(() => {
  const now = Date.now();
  for (const [key, record] of verifyAttempts) {
    if (record.lockedUntil <= now) verifyAttempts.delete(key);
  }
  for (const [key, record] of loginAttempts) {
    if (record.lockedUntil <= now) loginAttempts.delete(key);
  }
}, 30 * 60 * 1000);

function getClientIP(req) {
  return (req.socket.remoteAddress || 'unknown').replace('::ffff:', '').trim();
}

router.post('/login', (req, res) => {
  const ip = getClientIP(req);
  const now = Date.now();

  const record = loginAttempts.get(ip) || { count: 0, lockedUntil: 0 };
  if (record.lockedUntil > now) {
    const secsLeft = Math.ceil((record.lockedUntil - now) / 1000);
    return res.status(429).json({ success: false, error: `Too many attempts. Try again in ${secsLeft}s.` });
  }

  const { username, password } = req.body;
  const correctUser = process.env.ADMIN_USERNAME || 'admin';
  const correctPass = process.env.ADMIN_PASSWORD || 'vcc1234';

  if (username === correctUser && password === correctPass) {
    loginAttempts.delete(ip); // reset on success
    req.session.loggedIn = true;
    req.session.username = username;
    res.json({ success: true });
  } else {
    record.count = (record.lockedUntil > 0 && record.lockedUntil <= now) ? 1 : record.count + 1;
    record.lockedUntil = record.count >= MAX_ATTEMPTS ? now + LOCKOUT_MS : 0;
    loginAttempts.set(ip, record);
    const attemptsLeft = Math.max(0, MAX_ATTEMPTS - record.count);
    const msg = record.lockedUntil
      ? `Too many failed attempts. Locked for 15 minutes.`
      : `Invalid username or password. ${attemptsLeft} attempt${attemptsLeft !== 1 ? 's' : ''} left.`;
    res.status(401).json({ success: false, error: msg });
  }
});

router.post('/verify', (req, res) => {
  const sessionId = req.sessionID || 'unknown';
  const now = Date.now();

  // Check lockout
  const record = verifyAttempts.get(sessionId) || { count: 0, lockedUntil: 0 };
  if (record.lockedUntil > now) {
    const secsLeft = Math.ceil((record.lockedUntil - now) / 1000);
    return res.status(429).json({ success: false, error: `Too many attempts. Try again in ${secsLeft}s.` });
  }

  const { password } = req.body;
  const correctPass = process.env.ADMIN_PASSWORD || 'vcc1234';

  if (password === correctPass) {
    verifyAttempts.delete(sessionId); // reset on success
    res.json({ success: true });
  } else {
    record.count = (record.lockedUntil > 0 && record.lockedUntil <= now) ? 1 : record.count + 1;
    record.lockedUntil = record.count >= MAX_ATTEMPTS ? now + LOCKOUT_MS : 0;
    verifyAttempts.set(sessionId, record);
    const attemptsLeft = Math.max(0, MAX_ATTEMPTS - record.count);
    const msg = record.lockedUntil
      ? `Too many failed attempts. Locked for 15 minutes.`
      : `Incorrect password. ${attemptsLeft} attempt${attemptsLeft !== 1 ? 's' : ''} left.`;
    res.status(401).json({ success: false, error: msg });
  }
});

router.post('/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

router.get('/status', (req, res) => {
  res.json({ loggedIn: !!(req.session && req.session.loggedIn) });
});


router.post('/change-password', (req, res) => {
  if (!req.session || !req.session.loggedIn) {
    return res.status(401).json({ success: false, error: 'Not authenticated' });
  }

  const { currentPassword, newPassword } = req.body;
  if (!currentPassword || !newPassword) {
    return res.status(400).json({ success: false, error: 'Both currentPassword and newPassword are required' });
  }
  if (newPassword.length < 6) {
    return res.status(400).json({ success: false, error: 'New password must be at least 6 characters' });
  }

  const correctPass = process.env.ADMIN_PASSWORD || 'vcc1234';
  if (currentPassword !== correctPass) {
    return res.status(401).json({ success: false, error: 'Current password is incorrect' });
  }

  try {
    const envPath = path.join(__dirname, '../../.env');

    // Read as buffer first so we can strip BOM and normalise line endings.
    // Without this, Windows-saved .env files (CRLF or BOM) would corrupt the
    // file on write — the regex would miss the key and append a duplicate line.
    let envContent = fs.readFileSync(envPath, 'utf8')
      .replace(/^\uFEFF/, '')        // strip UTF-8 BOM if present
      .replace(/\r\n/g, '\n')        // normalise CRLF → LF
      .replace(/\r/g, '\n');         // normalise lone CR → LF

    if (/^ADMIN_PASSWORD=.*/m.test(envContent)) {
      envContent = envContent.replace(/^ADMIN_PASSWORD=.*/m, `ADMIN_PASSWORD=${newPassword}`);
    } else {
      envContent = envContent.trimEnd() + `\nADMIN_PASSWORD=${newPassword}\n`;
    }

    fs.writeFileSync(envPath, envContent, 'utf8');
    process.env.ADMIN_PASSWORD = newPassword;

    res.json({ success: true, message: 'Password updated successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: 'Failed to update password: ' + err.message });
  }
});
module.exports = router;