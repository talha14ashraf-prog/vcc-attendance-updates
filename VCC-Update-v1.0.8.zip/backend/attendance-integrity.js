// A scan pre-check alone cannot protect concurrent requests. The unique index
// also covers manual entries, edits and writes without a scan request ID.
const indexName = 'idx_attendance_one_type_per_day';
async function migrate(client) {
  await client.batch([
    {sql:`CREATE TABLE IF NOT EXISTS attendance_duplicate_archive (
      original_id INTEGER, student_uid TEXT, type TEXT, timestamp TEXT,
      manual_no_time INTEGER, archived_at TEXT DEFAULT CURRENT_TIMESTAMP,
      reason TEXT DEFAULT 'Duplicate student/day/type; earliest punch retained',
      PRIMARY KEY(original_id,student_uid,type,timestamp)
    )`,args:[]},
    {sql:`INSERT OR IGNORE INTO attendance_duplicate_archive
      (original_id,student_uid,type,timestamp,manual_no_time)
      SELECT a.id,a.student_uid,a.type,a.timestamp,a.manual_no_time
      FROM attendance a WHERE a.type IN ('IN','OUT') AND EXISTS (
        SELECT 1 FROM attendance first WHERE first.student_uid=a.student_uid
        AND first.type=a.type AND date(first.timestamp)=date(a.timestamp)
        AND (first.timestamp<a.timestamp OR (first.timestamp=a.timestamp AND first.id<a.id))
      )`,args:[]},
    {sql:`DELETE FROM attendance WHERE id IN (
      SELECT a.id FROM attendance a WHERE a.type IN ('IN','OUT') AND EXISTS (
        SELECT 1 FROM attendance first WHERE first.student_uid=a.student_uid
        AND first.type=a.type AND date(first.timestamp)=date(a.timestamp)
        AND (first.timestamp<a.timestamp OR (first.timestamp=a.timestamp AND first.id<a.id))
      ))`,args:[]},
    {sql:`CREATE UNIQUE INDEX IF NOT EXISTS ${indexName}
      ON attendance(student_uid,date(timestamp),type)`,args:[]}
  ], 'immediate');
}
function isDuplicate(error) {
  const text = String(error && (error.message || error));
  return text.includes(indexName)
    || /UNIQUE constraint failed: attendance\.\(student_uid,\s*date\s*\(timestamp\),\s*type\)/i.test(text)
    || /UNIQUE constraint failed: attendance\.student_uid,\s*attendance\.date\s*\(timestamp\),\s*attendance\.type/i.test(text);
}
module.exports = {migrate,isDuplicate};
