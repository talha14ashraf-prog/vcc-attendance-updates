function validId(id) { return typeof id === 'string' && /^[a-zA-Z0-9_-]{16,100}$/.test(id); }
function snapshot(result) { const {student_photo,...data}=result;return JSON.stringify(data); }
async function read(db,id,uid) {
  if (!id) return null;
  if (!validId(id)) throw new Error('Invalid scan request ID');
  const rows=await db.query('SELECT scanned_uid,response_json FROM scan_receipts WHERE request_id=?',[id]);
  if (!rows.length) return null;
  if (rows[0].scanned_uid!==uid) throw new Error('Scan request ID does not match this card');
  return JSON.parse(rows[0].response_json);
}
async function save(db,id,uid,result,timestamp) {
  const insert={sql:'INSERT INTO attendance (student_uid,type,timestamp) VALUES (?,?,?)',args:[result.student_uid,result.type,timestamp]};
  if (id && !validId(id)) throw new Error('Invalid scan request ID');
  try {
    if (!id) { await db.run(insert.sql,insert.args);return {replayed:false}; }
    await db.batchRun([
      {sql:'INSERT INTO scan_receipts(request_id,scanned_uid,response_json,created_at) VALUES(?,?,?,?)',args:[id,uid,snapshot(result),new Date().toISOString()]},
      insert
    ]);
    return {replayed:false};
  } catch(error) {
    const existing=await read(db,id,uid);
    if(existing)return {replayed:true,result:existing};
    if(require('./attendance-integrity').isDuplicate(error)) {
      const duplicate={success:false,duplicate:true,student:result.student,class:result.class,
        lastType:result.type,error:result.type+' attendance already recorded for today.'};
      return {replayed:true,result:await remember(db,id,uid,duplicate)};
    }
    throw error;
  }
}
async function remember(db,id,uid,result) {
  if(!id || result.success || !validId(id))return result;
  await db.run('INSERT OR IGNORE INTO scan_receipts(request_id,scanned_uid,response_json,created_at) VALUES(?,?,?,?)',[id,uid,snapshot(result),new Date().toISOString()]);
  return await read(db,id,uid) || result;
}
module.exports={read,save,remember,validId};
