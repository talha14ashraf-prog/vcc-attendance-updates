/**
 * VCC WhatsApp Module — WPPConnect Library Edition
 * All WhatsApp sends share one visible WhatsApp Web browser session.
 */
const fs = require('fs');
const path = require('path');
const wppconnect = require('@wppconnect-team/wppconnect');

const SESSION_NAME = 'vcc-attendance';
const TOKEN_DIR = path.join(process.cwd(), 'wppconnect_tokens');
const CHROME_PATHS = [
  process.env.WPP_CHROME_PATH,
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files (x86)\\Google\\Chrome\\Application\\chrome.exe',
  'C:\\Program Files\\Microsoft\\Edge\\Application\\msedge.exe',
].filter(Boolean);

let client = null;
let initPromise = null;
let isReady = false;
let qrCodeData = null;
let qrImageBase64 = null;
let status = 'disconnected';
let reconnectTimer = null;
let reconnectAttempts = 0;
const browserVisible = process.env.WPP_BROWSER_VISIBLE !== 'false';
let browserClosedByUser = false;

function findBrowserPath() {
  return CHROME_PATHS.find(browserPath => fs.existsSync(browserPath)) || undefined;
}

function normalizeBase64Image(image) {
  if (!image) return null;
  return image.startsWith('data:image') ? image : `data:image/png;base64,${image}`;
}

function extractMessageId(message) {
  const id = message?.id;
  if (!id) return null;
  if (typeof id === 'string') return id;
  return id.id || id._serialized || null;
}

function formatPhone(phone) {
  let num = String(phone || '').replace(/\D/g, '');
  if (num.startsWith('0')) num = '92' + num.slice(1);
  if (!num.startsWith('92')) num = '92' + num;
  return `${num}@c.us`;
}

function isValidPhone(phone) {
  return String(phone || '').replace(/\D/g, '').length >= 10;
}

async function bringWhatsAppToFront() {
  if (!browserVisible) return;
  try {
    if (client?.page && !client.page.isClosed()) await client.page.bringToFront();
  } catch (_) {
    // Windows refusing focus must not fail a message send.
  }
}

function updateConnectionStatus(nextStatus) {
  const normalized = String(nextStatus || '').toLowerCase();
  if (normalized === 'inchat' || normalized === 'islogged' || normalized === 'connected') {
    isReady = true;
    status = 'connected';
    qrCodeData = null;
    qrImageBase64 = null;
    reconnectAttempts = 0;
    return;
  }
  if (['notlogged', 'qrreadfail', 'qrreaderror'].includes(normalized)) {
    isReady = false;
    status = qrImageBase64 ? 'qr_ready' : 'connecting';
    return;
  }
  if (normalized === 'qrreadsuccess') {
    isReady = false;
    status = 'connecting';
    qrCodeData = null;
    qrImageBase64 = null;
    return;
  }
  if (['browserclose', 'serverclose', 'disconnectedmobile', 'phonenotconnected', 'autoclosecalled'].includes(normalized)) {
    isReady = false;
    status = 'disconnected';
    if (normalized === 'browserclose') {
      browserClosedByUser = true;
      if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
    } else scheduleReconnect();
  }
}

async function refreshConnection() {
  if (!client) return false;
  try {
    const logged = await client.isLoggedIn();
    if (logged) {
      isReady = true;
      status = 'connected';
      qrCodeData = null;
      qrImageBase64 = null;
      reconnectAttempts = 0;
      return true;
    }
    isReady = false;
    status = qrImageBase64 ? 'qr_ready' : 'disconnected';
  } catch (_) {
    isReady = false;
    status = 'disconnected';
  }
  return false;
}

async function attachClientListeners(activeClient) {
  activeClient.onMessage(message => {
    if (!message?.fromMe) console.log(`[WhatsApp] Incoming message from ${message?.from || 'unknown'}`);
  });
  activeClient.onAck(ack => {
    const msgId = ack?.id?.id || ack?.id?._serialized || null;
    const rawAck = Number(ack?.ack);
    if (!msgId || !Number.isFinite(rawAck) || rawAck < 1) return;
    const normalizedAck = rawAck >= 3 ? 3 : rawAck;
    try {
      const { run } = require('./database');
      run('UPDATE whatsapp_log SET ack = ? WHERE msg_id = ?', [normalizedAck, msgId]).catch(() => {});
    } catch (_) {}
  });
}

async function initWhatsApp() {
  if (!require('./sender-role').enabled()) return;
  if (browserClosedByUser) return null;
  if (initPromise) return initPromise;
  if (isReady && client) return client;
  if (client) {
    if (await refreshConnection()) return client;
    try {
      if (client.page && !client.page.isClosed()) return client;
    } catch (_) {}
    client = null;
  }

  initPromise = (async () => {
    status = 'connecting';
    const executablePath = findBrowserPath();
    console.log(`[WhatsApp] Starting WPPConnect (${browserVisible ? 'visible window' : 'background browser'})...`);
    try {
      const activeClient = await wppconnect.create({
        session: SESSION_NAME,
        headless: !browserVisible,
        useChrome: true,
        logQR: false,
        updatesLog: false,
        disableWelcome: true,
        autoClose: 0,
        deviceSyncTimeout: 0,
        waitForLogin: false,
        folderNameToken: TOKEN_DIR,
        deviceName: 'VCC Attendance System',
        puppeteerOptions: {
          ...(executablePath ? { executablePath } : {}),
          headless: !browserVisible,
          defaultViewport: null,
        },
        browserArgs: [
          '--start-maximized',
          '--disable-background-timer-throttling',
          '--disable-backgrounding-occluded-windows',
          '--disable-renderer-backgrounding',
        ],
        catchQR: (base64Qr, asciiQr, attempt, urlCode) => {
          qrImageBase64 = normalizeBase64Image(base64Qr);
          qrCodeData = urlCode || asciiQr || null;
          status = 'qr_ready';
          isReady = false;
          console.log(`[WhatsApp] QR ready (attempt ${attempt}). Scan from the VCC Connect modal.`);
        },
        statusFind: connectionStatus => {
          console.log(`[WhatsApp] WPPConnect status: ${connectionStatus}`);
          updateConnectionStatus(String(connectionStatus));
        },
      });
      client = activeClient;
      // create() can return before the QR has been scanned when waitForLogin
      // is disabled. Never report a false "connected" state during that gap.
      isReady = await activeClient.isLoggedIn().catch(() => false);
      status = isReady ? 'connected' : (qrImageBase64 ? 'qr_ready' : 'connecting');
      if (isReady) {
        qrCodeData = null;
        qrImageBase64 = null;
        reconnectAttempts = 0;
      }
      await attachClientListeners(activeClient);
      await bringWhatsAppToFront();
      console.log(isReady ? '✅ WhatsApp connected successfully! (WPPConnect)' : '[WhatsApp] Waiting for WPPConnect QR scan...');
      return activeClient;
    } catch (error) {
      client = null;
      isReady = false;
      status = 'disconnected';
      console.error('[WhatsApp] WPPConnect initialization failed:', error.message || error);
      scheduleReconnect();
      return null;
    } finally {
      initPromise = null;
    }
  })();
  return initPromise;
}

function scheduleReconnect() {
  if (browserClosedByUser || !require('./sender-role').enabled()) return;
  if (reconnectTimer) return;
  reconnectAttempts += 1;
  const delay = Math.min(5000 * (2 ** Math.min(reconnectAttempts - 1, 4)), 60000);
  console.log(`[WhatsApp] Reconnecting WPPConnect in ${Math.round(delay / 1000)}s...`);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    initWhatsApp().catch(() => {});
  }, delay);
}

let whatsappSendQueue = Promise.resolve();
let hasAttemptedWhatsAppSend = false;

function queueWhatsAppSend(sendOperation) {
  const queued = whatsappSendQueue.then(async () => {
    if (hasAttemptedWhatsAppSend) {
      const delaySeconds = Math.floor(Math.random() * 16) + 5;
      console.log(`[WhatsApp] Waiting ${delaySeconds}s before next send...`);
      await new Promise(resolve => setTimeout(resolve, delaySeconds * 1000));
    }
    hasAttemptedWhatsAppSend = true;
    await bringWhatsAppToFront();
    return sendOperation();
  });
  whatsappSendQueue = queued.catch(() => {});
  return queued;
}

async function sendMessage(phone, message) {
  if (!require('./sender-role').enabled()) return { success:false, reason:'Use the Sender PC', msgId:null };
  if (!isValidPhone(phone)) return { success:false, msgId:null, reason:'No valid phone number' };
  if ((!isReady || !client) && !(await refreshConnection())) {
    initWhatsApp().catch(() => {});
    return { success:false, msgId:null, reason:'WhatsApp not connected' };
  }
  try {
    const sent = await queueWhatsAppSend(() => client.sendText(formatPhone(phone), String(message || '')));
    return { success:true, msgId:extractMessageId(sent), reason:null };
  } catch (error) {
    console.error('[WhatsApp] Text send failed:', error.message || error);
    return { success:false, msgId:null, reason:error.message || 'Send failed' };
  }
}

async function sendFile(chatId, buffer, filename, caption) {
  require('./sender-role').assertSender();
  if (!isReady || !client) return false;
  try {
    const to = String(chatId || '').includes('@') ? String(chatId) : formatPhone(chatId);
    const dataUri = `data:application/pdf;base64,${Buffer.from(buffer).toString('base64')}`;
    await queueWhatsAppSend(() => client.sendFile(to, dataUri, {
      filename: filename || 'document.pdf',
      caption: caption || '',
      type: 'document',
    }));
    return true;
  } catch (error) {
    console.error('[WhatsApp] File send failed:', error.message || error);
    return false;
  }
}

async function checkOnWhatsApp(phone) {
  if (!isReady || !client) return null;
  if (!isValidPhone(phone)) return false;
  try {
    const result = await client.checkNumberStatus(formatPhone(phone));
    return result?.numberExists === true && result?.canReceiveMessage !== false;
  } catch (error) {
    console.warn('[WhatsApp] Number check failed:', error.message || error);
    return null;
  }
}

async function smartSend(student, message, db) {
  return require('./message-channel').send(student, message, db);
}
async function smartSendWhatsApp(student, message, db) {
  const phone1 = student.parent_phone || '';
  const phone2 = student.parent_phone2 || '';
  const uid = student.student_uid;
  async function setWaStatus(value) {
    if (db && uid) try { await db.run('UPDATE students SET wa_status = ? WHERE student_uid = ?', [value, uid]); } catch (_) {}
  }

  let phone1OnWA = null;
  if (isValidPhone(phone1)) {
    if (student.wa_status === 'not_on_wa') phone1OnWA = false;
    else {
      phone1OnWA = await checkOnWhatsApp(phone1);
      if (phone1OnWA === false) await setWaStatus('not_on_wa');
      else if (phone1OnWA === true && student.wa_status !== 'on_wa') await setWaStatus('on_wa');
    }
  }
  if (isValidPhone(phone1) && phone1OnWA !== false) {
    const result = await sendMessage(phone1, message);
    return { sent:result.success, phone:phone1, usedFallback:false, msgId:result.msgId, reason:result.reason };
  }
  if (isValidPhone(phone2)) {
    const phone2OnWA = await checkOnWhatsApp(phone2);
    if (phone2OnWA === false) return { sent:false, phone:phone2, usedFallback:true, msgId:null, reason:isValidPhone(phone1) ? 'Both numbers not on WhatsApp' : 'Backup number not on WhatsApp' };
    const result = await sendMessage(phone2, message);
    return { sent:result.success, phone:phone2, usedFallback:true, msgId:result.msgId, reason:result.reason };
  }
  if (!isValidPhone(phone1)) return { sent:false, phone:'', usedFallback:false, msgId:null, reason:'No valid phone number on file' };
  return { sent:false, phone:phone1, usedFallback:false, msgId:null, reason:'Primary number not on WhatsApp, no backup number on file' };
}

async function smartSendFile(student, buffer, filename, caption, db) {
  return require('./message-channel').sendFile(student, buffer, filename, caption, db);
}
async function smartSendFileWhatsApp(student, buffer, filename, caption, db) {
  const phone1 = student.parent_phone || '';
  const phone2 = student.parent_phone2 || '';
  const uid = student.student_uid;
  async function setWaStatus(value) {
    if (db && uid) try { await db.run('UPDATE students SET wa_status = ? WHERE student_uid = ?', [value, uid]); } catch (_) {}
  }
  async function attempt(phone, usedFallback) {
    const sent = await sendFile(phone, buffer, filename, caption);
    return { sent, phone, usedFallback, reason:sent ? null : 'File send failed (WhatsApp not connected or send error)' };
  }

  let phone1OnWA = null;
  if (isValidPhone(phone1)) {
    if (student.wa_status === 'not_on_wa') phone1OnWA = false;
    else {
      phone1OnWA = await checkOnWhatsApp(phone1);
      if (phone1OnWA === false) await setWaStatus('not_on_wa');
      else if (phone1OnWA === true && student.wa_status !== 'on_wa') await setWaStatus('on_wa');
    }
  }
  if (isValidPhone(phone1) && phone1OnWA !== false) return attempt(phone1, false);
  if (isValidPhone(phone2)) {
    const phone2OnWA = await checkOnWhatsApp(phone2);
    if (phone2OnWA === false) return { sent:false, phone:phone2, usedFallback:true, reason:isValidPhone(phone1) ? 'Both numbers not on WhatsApp' : 'Backup number not on WhatsApp' };
    return attempt(phone2, true);
  }
  if (!isValidPhone(phone1)) return { sent:false, phone:'', usedFallback:false, reason:'No valid phone number on file' };
  return { sent:false, phone:phone1, usedFallback:false, reason:'Primary number not on WhatsApp, no backup number on file' };
}

function getStatus() {
  return { isReady, qrCodeData, qrImageBase64, status, provider:'wppconnect', browserVisible };
}

async function reconnectWhatsApp() {
  if (reconnectTimer) { clearTimeout(reconnectTimer); reconnectTimer = null; }
  const oldClient = client;
  client = null;
  isReady = false;
  status = 'connecting';
  qrCodeData = null;
  qrImageBase64 = null;
  if (oldClient) {
    try { await oldClient.close(); } catch (_) {}
  }
  browserClosedByUser = false;
  return initWhatsApp();
}

module.exports = { initWhatsApp, reconnectWhatsApp, refreshConnection, sendMessage, sendFile, getStatus, isValidPhone, checkOnWhatsApp, smartSend, smartSendFile, smartSendWhatsApp, smartSendFileWhatsApp };
