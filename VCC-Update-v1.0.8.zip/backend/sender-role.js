function enabled() { return String(process.env.MESSAGE_SENDER_ENABLED || 'true').toLowerCase() === 'true'; }
function assertSender() { if (!enabled()) throw new Error('This PC is in data-only mode. Send messages from the Sender PC.'); }
module.exports = { enabled, assertSender };
