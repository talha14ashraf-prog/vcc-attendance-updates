// Abort the real HTTP request INCLUDING its body. Never release the database
// lock using Promise.race while the native sync operation is still running.
function createSyncTransport({fetchImpl=(...args)=>fetch(...args),requestTimeoutMs=4000,operationTimeoutMs=6000}={}) {
  let operationSignal=null,operationController=null,activeRequestTimeoutMs=requestTimeoutMs;
  async function boundedFetch(input,options={}) {
    const signals=[AbortSignal.timeout(activeRequestTimeoutMs),operationSignal,options.signal].filter(Boolean);
    const response=await fetchImpl(input,{...options,signal:AbortSignal.any(signals)});
    const body=await response.arrayBuffer();
    return new Response([204,205,304].includes(response.status)?null:body,{status:response.status,statusText:response.statusText,headers:response.headers});
  }
  async function run(task,overrides={}) {
    const previous=operationSignal,previousController=operationController,previousRequestTimeoutMs=activeRequestTimeoutMs;
    const runRequestTimeoutMs=Number(overrides.requestTimeoutMs)>0?Number(overrides.requestTimeoutMs):requestTimeoutMs;
    const runOperationTimeoutMs=Number(overrides.operationTimeoutMs)>0?Number(overrides.operationTimeoutMs):operationTimeoutMs;
    operationController=new AbortController();
    operationSignal=AbortSignal.any([operationController.signal,AbortSignal.timeout(runOperationTimeoutMs)]);
    activeRequestTimeoutMs=runRequestTimeoutMs;
    try{return await task()}finally{operationSignal=previous;operationController=previousController;activeRequestTimeoutMs=previousRequestTimeoutMs}
  }
  function yieldToScan(){operationController?.abort(new Error('Cloud sync yielded to local scan'))}
  return {fetch:boundedFetch,run,yieldToScan};
}
module.exports={createSyncTransport};
