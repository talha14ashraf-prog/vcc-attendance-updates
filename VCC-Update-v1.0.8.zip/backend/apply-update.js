// Runs from start.bat before the server opens the database. Uses only Node
// built-ins so it can repair/rollback even when dependencies need updating.
const fs=require('fs');
const path=require('path');
const crypto=require('crypto');
const {spawnSync}=require('child_process');

const ROOT=path.resolve(__dirname,'..');
const UPDATES=path.join(ROOT,'_updates');
const PENDING=path.join(UPDATES,'pending.json');
const RESULT=path.join(UPDATES,'last-result.json');
function inside(base,target){const root=path.resolve(base)+path.sep,resolved=path.resolve(target);if(resolved!==path.resolve(base)&&!resolved.startsWith(root))throw Error('Unsafe update path.');return resolved}
function hash(file){return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex')}
function json(file){return JSON.parse(fs.readFileSync(file,'utf8'))}
function writeResult(value){fs.mkdirSync(UPDATES,{recursive:true});fs.writeFileSync(RESULT,JSON.stringify({...value,at:new Date().toISOString()},null,2))}
function dependencySignature(pkg){const value=json(pkg),sort=o=>Object.fromEntries(Object.entries(o||{}).sort(([a],[b])=>a.localeCompare(b)));return JSON.stringify({dependencies:sort(value.dependencies),optionalDependencies:sort(value.optionalDependencies)})}
function copyFile(source,target){inside(ROOT,target);fs.mkdirSync(path.dirname(target),{recursive:true});fs.copyFileSync(source,target)}
function removeExact(file){const resolved=inside(ROOT,file);if(fs.existsSync(resolved))fs.rmSync(resolved,{force:true})}

async function applyPending(){
  if(!fs.existsSync(PENDING))return{applied:false};
  const pending=json(PENDING);if(pending.format!==1||!/^\d+\.\d+\.\d+$/.test(String(pending.version||'')))throw Error('Pending update record is invalid.');
  const source=inside(UPDATES,path.join(ROOT,pending.source||''));
  if(!fs.existsSync(source)||!source.startsWith(path.resolve(UPDATES)+path.sep))throw Error('Pending update files are missing.');
  const manifest=json(path.join(source,'vcc-update.json'));if(manifest.format!==1||manifest.version!==pending.version||!Array.isArray(manifest.files))throw Error('Pending update manifest is invalid.');
  const allowedDirs=new Set(['backend','frontend']),allowedFiles=new Set(['package.json','package-lock.json','start.bat','setup.bat','kiosk.bat','kiosk-launcher.ps1','Create Kiosk Shortcut.bat','README.md','SETUP.md','.env.example']);
  for(const item of manifest.files){const rel=String(item.path||'').replace(/\\/g,'/');if(!rel||rel.startsWith('/')||rel.includes('../'))throw Error('Unsafe update file path.');if(!allowedDirs.has(rel.split('/')[0])&&!allowedFiles.has(rel))throw Error('Protected update target: '+rel);const src=inside(source,path.join(source,...rel.split('/')));if(!fs.existsSync(src)||hash(src)!==String(item.sha256||'').toLowerCase())throw Error('Pending update file failed verification: '+rel)}

  const stamp=new Date().toISOString().replace(/[:.]/g,'-');
  const backup=inside(path.join(ROOT,'backups'),path.join(ROOT,'backups',`app-update-${stamp}-from-${json(path.join(ROOT,'package.json')).version||'unknown'}`));
  const backupFiles=path.join(backup,'files');fs.mkdirSync(backupFiles,{recursive:true});
  const record={version:pending.version,files:[],createdAt:new Date().toISOString()};
  const oldDependencySignature=dependencySignature(path.join(ROOT,'package.json'));
  let modulesBackup=null;
  try{
    for(const item of manifest.files){
      const rel=item.path.replace(/\\/g,'/'),target=inside(ROOT,path.join(ROOT,...rel.split('/'))),src=inside(source,path.join(source,...rel.split('/')));
      const existed=fs.existsSync(target);record.files.push({path:rel,existed});if(existed)copyFile(target,path.join(backupFiles,...rel.split('/')));copyFile(src,target);
    }
    fs.writeFileSync(path.join(backup,'rollback.json'),JSON.stringify(record,null,2));
    const newDependencySignature=dependencySignature(path.join(ROOT,'package.json'));
    if(oldDependencySignature!==newDependencySignature){
      const modules=path.join(ROOT,'node_modules');modulesBackup=inside(UPDATES,path.join(UPDATES,'node_modules-before-'+pending.version.replace(/\./g,'-')));
      if(fs.existsSync(modulesBackup))fs.rmSync(modulesBackup,{recursive:true,force:true});if(fs.existsSync(modules))fs.renameSync(modules,modulesBackup);
      const install=spawnSync('npm.cmd',['ci','--omit=dev','--no-audit','--no-fund'],{cwd:ROOT,stdio:'inherit',windowsHide:false});if(install.status!==0)throw Error('Dependency installation failed.');
    }
    removeExact(PENDING);
    writeResult({success:true,version:pending.version,backup:path.relative(ROOT,backup)});
    if(modulesBackup&&fs.existsSync(modulesBackup))fs.rmSync(modulesBackup,{recursive:true,force:true});
    console.log(`[UPDATE] Successfully applied VCC v${pending.version}. Backup: ${path.relative(ROOT,backup)}`);
    return{applied:true,version:pending.version};
  }catch(error){
    console.error('[UPDATE] Apply failed; restoring previous files:',error.message);
    for(const item of record.files.reverse()){
      const target=inside(ROOT,path.join(ROOT,...item.path.split('/'))),saved=path.join(backupFiles,...item.path.split('/'));
      if(item.existed&&fs.existsSync(saved))copyFile(saved,target);else if(!item.existed)removeExact(target);
    }
    if(modulesBackup&&fs.existsSync(modulesBackup)){
      const modules=inside(ROOT,path.join(ROOT,'node_modules'));if(fs.existsSync(modules))fs.rmSync(modules,{recursive:true,force:true});fs.renameSync(modulesBackup,modules);
    }
    writeResult({success:false,version:pending.version,error:error.message,backup:path.relative(ROOT,backup)});
    throw error;
  }
}

if(require.main===module){applyPending().catch(error=>{console.error('[UPDATE] Previous version restored. VCC will start normally.');process.exitCode=1})}
module.exports={applyPending};
