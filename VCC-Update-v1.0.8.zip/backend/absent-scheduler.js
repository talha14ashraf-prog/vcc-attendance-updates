/**
 * VCC Absent Scheduler
 * ─────────────────────
 * Runs every minute. For each configured slot (class + section + time),
 * auto-sends absent WhatsApp notifications at the set PKT time.
 *
 * Schedule stored in settings DB as JSON under key 'absent_schedule':
 * [{ class: 'IX', section: 'A', time: '17:00' }, ...]
 *
 * Tracks fired slots per day so it doesn't double-send.
 */

const { query, run, todayPKT } = require('./database');
const { smartSend, getStatus } = require('./whatsapp');

function formatTime(pktDate) {
  const h = pktDate.getUTCHours();
  const m = pktDate.getUTCMinutes();
  const ampm = h >= 12 ? 'PM' : 'AM';
  const h12  = (h % 12 || 12);
  return `${String(h12).padStart(2,'0')}:${String(m).padStart(2,'0')} ${ampm}`;
}
function formatDate(pktDate) {
  const months = ['January','February','March','April','May','June','July','August','September','October','November','December'];
  const d = pktDate.getUTCDate();
  const mo = months[pktDate.getUTCMonth()];
  const y  = pktDate.getUTCFullYear();
  return `${String(d).padStart(2,'0')} ${mo} ${y}`;
}
function buildMessage(template, student, contact) {
  const pktNow = new Date(Date.now() + 5 * 60 * 60 * 1000);
  return template
    .replace(/{name}/g,    student.name)
    .replace(/{time}/g,    formatTime(pktNow))
    .replace(/{date}/g,    formatDate(pktNow))
    .replace(/{contact}/g, contact)
    .replace(/{class}/g,   student.class)
    .replace(/{section}/g, student.section || '');
}

// firedToday: "YYYY-MM-DD|IX|A|17:00" → true  (resets automatically each new day)
// This is a local fast-path cache only — the real lock that prevents duplicate
// sends ACROSS MULTIPLE PCs lives in the DB (see claimSlot below), because each
// PC runs its own Node process with its own memory.
const firedToday = new Set();

// Lazy-load db to avoid circular dependency
function getDb() {
  return require('./database');
}

// Ensure the lock table exists (id is the fire-key itself — INSERT fails if
// another PC already claimed it, which is exactly the lock behaviour we want).
let lockTableReady = false;
async function ensureLockTable() {
  if (lockTableReady) return;
  try {
    await query(`CREATE TABLE IF NOT EXISTS scheduler_fired_log (
      fire_key TEXT PRIMARY KEY,
      fired_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )`);
    lockTableReady = true;
  } catch (e) {
    // will retry next tick
  }
}

// Atomically claim a slot. Returns true only for the ONE PC that wins the
// race — every other PC (and this PC on a later tick) gets false.
// Because writes go through run(), this claim itself gets pushed to Turso,
// so other PCs see it on their next sync (within ~10s) and also skip it
// even if they haven't tried to claim it yet.
async function claimSlot(fireKey) {
  await ensureLockTable();
  try {
    await run('INSERT INTO scheduler_fired_log (fire_key) VALUES (?)', [fireKey]);
    return true; // insert succeeded — we won the claim
  } catch (e) {
    return false; // PRIMARY KEY collision — another PC already claimed this slot
  }
}

// Old keys (>2 days) — keep the lock table from growing forever.
async function cleanupOldLocks(todayStr) {
  try {
    await run('DELETE FROM scheduler_fired_log WHERE fire_key < ?', [todayStr]);
  } catch (e) {}
}

async function runSchedulerTick() {
  try {
    const pktNow  = new Date(Date.now() + 5 * 60 * 60 * 1000);
    const hour    = pktNow.getUTCHours();
    const min     = pktNow.getUTCMinutes();
    const todayStr = pktNow.toISOString().split('T')[0];

    // Clean up yesterday's fired keys (local cache)
    for (const key of [...firedToday]) {
      if (!key.startsWith(todayStr)) firedToday.delete(key);
    }

    // Skip if holiday
    const holidayRows = await query('SELECT id FROM holidays WHERE date = ?', [todayStr]);
    if (holidayRows.length) {
      console.log(`[AbsentScheduler] Today (${todayStr}) is a holiday — skipping all slots.`);
      return;
    }

    // Load schedule
    const rows = await query("SELECT value FROM settings WHERE key = 'absent_schedule'");
    if (!rows.length || !rows[0].value) return;

    let schedule;
    try { schedule = JSON.parse(rows[0].value); } catch(e) { return; }
    if (!Array.isArray(schedule) || !schedule.length) return;

    const allSettings = await query('SELECT * FROM settings');
    const sm = {};
    allSettings.forEach(s => sm[s.key] = s.value);
    const template = sm['absent_message'] ||
      'Dear Parent, your child {name} was absent from VCC today ({date}). Please ensure regular attendance. For queries: {contact}';
    const contact = sm['contact'] || '';

    const PKT_DAY_NAMES = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
    const todayDayName  = PKT_DAY_NAMES[pktNow.getUTCDay()];

    for (const slot of schedule) {
      if (!slot.class || !slot.time) continue;
      const [slotH, slotM] = slot.time.split(':').map(Number);
      if (isNaN(slotH) || isNaN(slotM)) continue;
      if (hour !== slotH || min !== slotM) continue;

      if (slot.days && slot.days.length > 0 && !slot.days.includes(todayDayName)) {
        continue;
      }

      const fireKey = `${todayStr}|${slot.class}|${slot.section || ''}|${slot.time}`;
      if (firedToday.has(fireKey)) continue; // already handled by this PC this tick-cycle

      // Cross-PC lock: only the PC that successfully INSERTs wins the claim.
      const won = await claimSlot(fireKey);
      if (!won) {
        // Another PC already fired this slot — mark locally too so we stop re-checking it.
        firedToday.add(fireKey);
        continue;
      }
      firedToday.add(fireKey);

      const selectedChannel = await require('./message-channel').channel('absent');
      const waReady = selectedChannel === 'sms' || getStatus().isReady;
      if (!waReady) {
        console.log(`[AbsentScheduler] WhatsApp not connected — logging as not_sent: ${slot.class}${slot.section ? '-'+slot.section : ''} at ${slot.time}`);
      } else {
        console.log(`[AbsentScheduler] Sending absent notifications: ${slot.class}${slot.section ? '-'+slot.section : ''} at ${slot.time} PKT`);
      }

      // Find absent students
      let sql = `SELECT * FROM students WHERE (status = 'active' OR status IS NULL OR status = '')
                 AND class = ?
                 AND student_uid NOT IN (
                   SELECT DISTINCT student_uid FROM attendance WHERE date(timestamp) = ?
                 )`;
      const params = [slot.class, todayStr];
      if (slot.section) { sql += ' AND section = ?'; params.push(slot.section); }
      sql += ' ORDER BY name';

      const absentStudents = await query(sql, params);
      console.log(`[AbsentScheduler] ${absentStudents.length} absent students found`);

      const db = getDb();
      let sent = 0, failed = 0;

      for (const student of absentStudents) {
        if (!student.parent_phone && !student.parent_phone2) continue;
        const message = buildMessage(template, student, contact);

        let logStatus = 'not_sent';
        let retryUntil = null;
        let usedPhone = student.parent_phone;
        let usedFallback = false;
        let failReason = null;

        let result = null;
        if (waReady) {
          result = await require('./message-channel').send(student, message, db, 'absent', selectedChannel);
          usedPhone = result.phone;
          usedFallback = result.usedFallback;

          if (result.queued) {
            logStatus = 'queued';
          } else if (result.sent) {
            logStatus = 'sent';
            sent++;
          } else {
            logStatus = 'failed';
            failed++;
            failReason = result.reason;
            retryUntil = new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
          }
        } else {
          logStatus = 'failed';
          failed++;
          failReason = 'WhatsApp not connected';
          retryUntil = new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
        }

        try {
          await run(
            `INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, student_uid, msg_id, used_phone2, fail_reason)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [student.name, student.class, usedPhone, message,
             usedFallback ? 'ABSENT_FALLBACK' : 'ABSENT', logStatus, retryUntil, student.student_uid,
             result ? (result.msgId || null) : null, usedFallback ? 1 : 0, failReason]
          );
        } catch(e) {}

      }
      console.log(`[AbsentScheduler] Done: ${sent} sent, ${failed} failed`);
    }

    // Housekeeping — drop lock rows older than today (runs every tick, cheap no-op most of the time)
    await cleanupOldLocks(todayStr);
  } catch(err) {
    console.error('[AbsentScheduler] Error:', err.message);
  }
}

function startAbsentScheduler() {
  runSchedulerTick();
  setInterval(runSchedulerTick, 60 * 1000);
  console.log('[AbsentScheduler] Active — checking every minute.');
}

module.exports = { startAbsentScheduler };
