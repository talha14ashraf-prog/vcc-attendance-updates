require('dotenv').config();

// ── GLOBAL ERROR GUARDS ──────────────────────────────────────────────────────
// Prevents the server dying due to unhandled errors from libraries
// (e.g. Chromium throws EBUSY on Windows when session .db files are
// locked by the OS during logout cleanup — this would otherwise crash Node).
process.on('uncaughtException', (err) => {
  console.error('[uncaughtException] Server kept alive. Error:', err.message);
  if (err.code === 'EBUSY' || err.code === 'EPERM') {
    console.error('[uncaughtException] Windows file lock — WhatsApp session cleanup failed, will retry on reconnect.');
  }
});
process.on('unhandledRejection', (reason) => {
  console.error('[unhandledRejection] Server kept alive. Reason:', reason?.message || reason);
});
// ─────────────────────────────────────────────────────────────────────────────

const express = require('express');
const cors = require('cors');
const path = require('path');
const http = require('http');
const session = require('express-session');
const { getDb, ensureWhatsappLog, ensureStudentColumns, ensureRetryColumns, ensureClassSectionSettings, ensurePhotoColumn, ensureHolidaysTable, ensureFrozenColumn, ensureWaColumns, backupDb, todayPKT, flushDb } = require('./database');
const { initWhatsApp, getStatus } = require('./whatsapp');
const requireLogin = require('./middleware/auth');

const app = express();
const server = http.createServer(app);

// CORS: only allow requests originating from localhost / LAN.
// This prevents arbitrary websites from hitting the API if the server
// is ever accidentally reachable from the internet.
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(express.json({ limit: '10mb' }));

// Session setup - stays active for 8 hours
// SESSION_SECRET must be set in .env — never falls back to a hardcoded string.
// Generate once with: node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET === 'vcc-secret-key-2026') {
  console.error('FATAL: SESSION_SECRET is not set or is still the default weak value.');
  console.error("Run: node -e \"console.log(require('crypto').randomBytes(48).toString('hex'))\"");
  console.error('Paste the output as SESSION_SECRET in your .env file, then restart.');
  process.exit(1);
}
app.use(session({
  secret: process.env.SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 8 * 60 * 60 * 1000 }
}));

// Auth routes - no login required
app.use('/api/auth', require('./routes/auth'));

// Login page - no login required
app.get('/login', async (req, res) => {
  if (req.session && req.session.loggedIn) return res.redirect('/');
  res.sendFile(path.join(__dirname, '../frontend/login.html'));
});

// ── KIOSK: IP-locked, no login required ──
// Set KIOSK_IP in your .env file to the entrance PC's IP e.g. KIOSK_IP=192.168.0.108
const KIOSK_IP = process.env.KIOSK_IP || null;

function getClientIP(req) {
  // Use only the real TCP connection address — never trust x-forwarded-for on a LAN.
  // That header can be set by any HTTP client and would let anyone spoof the kiosk IP.
  return (req.socket.remoteAddress || '').replace('::ffff:', '').trim();
}

function kioskIPCheck(req, res, next) {
  if (!KIOSK_IP) return next(); // if not set, allow all (during setup)
  const ip = getClientIP(req);
  if (ip === KIOSK_IP || ip === '127.0.0.1' || ip === '::1') return next();
  return res.status(403).send(`
    <!DOCTYPE html><html><head><title>Access Denied</title>
    <style>
      body{background:#080808;color:#EF4444;font-family:'Arial',sans-serif;
      display:flex;align-items:center;justify-content:center;height:100vh;
      flex-direction:column;gap:1rem;margin:0;}
      h1{font-size:2.5rem;margin:0;}
      p{color:#666;font-size:0.95rem;}
      small{color:#333;font-size:0.75rem;}
    </style></head>
    <body>
      <h1>⛔ Access Denied</h1>
      <p>The kiosk is only accessible from the entrance terminal.</p>
      <small>Your IP: ${ip}</small>
    </body></html>
  `);
}

// Kiosk page - IP locked
app.get('/kiosk', kioskIPCheck, (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/kiosk.html'));
});

// Kiosk scan API - IP locked (no session required)
// `uid` may be the student's own barcode UID OR a linked RFID card UID —
// either one resolves to the same student and marks the same attendance.
app.post('/api/kiosk/scan', kioskIPCheck, async (req, res) => {
  try {
    const { uid, request_id, tapped_at } = req.body;
    const scanDb = require('./database');
    scanDb.noteScanActivity?.();
    const receipts = require('./scan-receipts');
    if (request_id && !receipts.validId(request_id)) return res.status(400).json({success:false,error:'Invalid scan request ID'});
    const reply = async data => res.json(await receipts.remember(scanDb,request_id,uid,data));
    const previous = await receipts.read(scanDb,request_id,uid);
    if (previous) return await reply(previous);
    let tap;
    try { tap = require('./scan-time').resolve(tapped_at); }
    catch(error) { return res.status(400).json({success:false,review_required:true,error:error.message}); }
    if (!uid) return res.status(400).json({ success: false, error: 'No UID provided' });
    const { query, run } = require('./database');
    const { smartSend } = require('./whatsapp');

    const students = await query(
      'SELECT id, name, class, section, parent_phone, parent_phone2, student_uid, rfid_uid, gr_number, is_frozen, freeze_reason, student_photo FROM students WHERE student_uid = ? OR rfid_uid = ?',
      [uid, uid]
    );
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const student = students[0];
    // Attendance / whatsapp_log always keyed on the student's own student_uid,
    // regardless of whether the barcode or the RFID card was scanned.
    const uidForRecords = student.student_uid;

    // ── FROZEN / DEFAULTER CHECK ─────────────────────────────────────────────
    if (student.is_frozen === 1 || student.is_frozen === '1') {
      return await reply({
        success: false,
        frozen: true,
        student: student.name,
        class: student.class,
        gr_number: student.gr_number || '',
        freeze_reason: student.freeze_reason || '',
        error: `DEFAULTER — Submit the fees. ${student.name}'s attendance is not being marked.`
      });
    }

    const today = tap.day;
    const todayRecords = await query(
      'SELECT type, timestamp FROM attendance WHERE student_uid = ? AND date(timestamp) = ? ORDER BY timestamp DESC LIMIT 1',
      [uidForRecords, today]
    );

    if (todayRecords.length) {
      // Timestamp stored as PKT — subtract 5h offset to compare against UTC Date.now()
      const lastTs = new Date(todayRecords[0].timestamp.replace(' ', 'T') + '+05:00');
      const diffMs = tap.date.getTime() - lastTs.getTime();
      if (diffMs < 2 * 60 * 1000) {
        const secsLeft = Math.ceil((2 * 60) - (diffMs / 1000));
        const minsLeft = Math.floor(secsLeft / 60);
        const sLeft = secsLeft % 60;
        return await reply({
          success: false, duplicate: true,
          student: student.name, class: student.class,
          lastType: todayRecords[0].type,
          error: 'Already scanned. Wait ' + minsLeft + 'm ' + sLeft + 's'
        });
      }
    }

    // If last record today is OUT — block further scans
    if (todayRecords.length && todayRecords[0].type === 'OUT') {
      return await reply({
        success: false,
        duplicate: true,
        student: student.name,
        class: student.class,
        lastType: 'OUT',
        error: 'Attendance already marked. OUT already recorded for today.'
      });
    }

    const type = (todayRecords.length && todayRecords[0].type === 'IN') ? 'OUT' : 'IN';
    const pktNow = tap.timestamp;
    const scanResult = {
      success:true,student:student.name,class:student.class,type,whatsapp_sent:null,
      student_uid:student.student_uid,student_photo:student.student_photo || null,via_rfid:uid===student.rfid_uid,timestamp:pktNow
    };
    const saved = await receipts.save(scanDb,request_id,uid,scanResult,pktNow);
    if (saved.replayed) return await reply(saved.result);

    // Respond to the kiosk immediately — attendance is already saved.
    // Settings lookup + WhatsApp delivery happen after, in the background,
    // so the scan UI never waits on them.
    await reply({
      success: true, student: student.name, class: student.class, type, whatsapp_sent: null,
      student_uid: student.student_uid, student_photo: student.student_photo || null,
      via_rfid: uid === student.rfid_uid, timestamp:pktNow
    });

    // Fire-and-forget: build the message, send WhatsApp, log the outcome.
    // Every outcome — sent, failed, or a thrown error — must land a row in
    // whatsapp_log, otherwise failures just vanish instead of showing up
    // in the WA Log page.
    (async () => {
      let message = '';
      try {
        const settings = await query('SELECT * FROM settings');
        const sm = {};
        settings.forEach(s => sm[s.key] = s.value);
        const viaSms = sm.attendance_channel === 'sms';
        const template = viaSms
          ? (type === 'IN' ? sm.sms_in_message : sm.sms_out_message)
          : (type === 'IN' ? sm.in_message : sm.out_message);
        const now = tap.date;
        message = (template || '')
          .replace(/{name}/g, student.name)
          .replace(/{time}/g, now.toLocaleTimeString('en-PK', { timeZone:'Asia/Karachi', hour:'2-digit', minute:'2-digit', hour12:true }))
          .replace(/{date}/g, now.toLocaleDateString('en-PK', { timeZone:'Asia/Karachi', day:'2-digit', month:'long', year:'numeric' }))
          .replace(/{class}/g, student.class)
          .replace(/{section}/g, student.section || '')
          .replace(/{contact}/g, sm['contact'] || '');

        if (!require('./sender-role').enabled()) return;
        if (viaSms) {
          try { await require('./sms').enqueue(student, message, type); }
          catch (e) { console.warn('[SMS] Could not queue attendance alert:', e.message); }
          return;
        }
        const result = await require('./whatsapp').smartSendWhatsApp(student, message, require('./database'));
        const retryUntil = result.sent ? null : new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
        await run(`INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, msg_id, used_phone2, fail_reason, student_uid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [student.name, student.class, result.phone, message, type, result.sent ? 'sent' : 'failed', retryUntil, result.msgId || null, result.usedFallback ? 1 : 0, result.sent ? null : result.reason, student.student_uid || null]);
      } catch(e) {
        // smartSend (or settings/message build) threw — still record it as
        // failed so it shows up and can be retried, instead of disappearing.
        try {
          const retryUntil = new Date(Date.now() + 12*60*60*1000).toISOString().replace('T',' ').split('.')[0];
          await run(`INSERT INTO whatsapp_log (student_name, student_class, phone, message, type, status, retry_until, msg_id, used_phone2, fail_reason, student_uid) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [student.name, student.class, student.parent_phone || '', message, type, 'failed', retryUntil, null, 0, (e.message || 'Unknown error').slice(0,200), student.student_uid || null]);
        } catch(e2) {}
      }
    })();
  } catch(err) {
    // Never show raw internals (DB/network error text) on the physical
    // kiosk screen — log it here for diagnosis, show a plain message to
    // whoever is standing at the entrance.
    console.error('[kiosk/scan] error:', err.message || err);
    res.status(500).json({ success: false, error: 'Scan failed — please try again.' });
  }
});

// Kiosk today log - IP locked
app.get('/api/kiosk/today', kioskIPCheck, async (req, res) => {
  try {
    const { query } = require('./database');
    const today = todayPKT();
    const records = await query(
      'SELECT a.*, s.name, s.class FROM attendance a JOIN students s ON a.student_uid = s.student_uid WHERE date(a.timestamp) = ? ORDER BY a.timestamp DESC',
      [today]
    );
    res.json({ success: true, records });
  } catch(err) {
    console.error('[kiosk/today] error:', err.message || err);
    res.status(500).json({ success: false, error: 'Could not load today\'s log — please try again.' });
  }
});

// Kiosk has no admin session. Expose only display-safe sync fields, IP locked.
app.get('/api/kiosk/sync-status', kioskIPCheck, (req, res) => {
  const status = require('./database').getSyncStatus();
  res.set('Cache-Control','no-store').json({
    isOnline:status.isOnline, state:status.state,
    lastSyncAt:status.lastSyncAt, pendingLocalChanges:status.pendingLocalChanges
  });
});

// Public, token-protected copy receiving page for printed award-list QR codes.
// The random token grants access only to this one confirmation action; it does
// not expose Marks Entry, attendance, student records, or the admin system.
app.get('/award-list-receive/:token', async (req, res) => {
  try {
    const token = String(req.params.token || '');
    if (!/^[a-f0-9]{48}$/.test(token)) return res.status(404).send('Invalid award-list QR code.');
    const { query } = require('./database');
    const [award] = await query(`
      SELECT class, section, group_name, subject, test_date, teacher, copy_handed_over_at, copy_handed_over_method, copy_received_at, copy_received_method
      FROM award_lists WHERE qr_token = ? LIMIT 1
    `, [token]);
    if (!award) return res.status(404).send('Award list not found.');

    const esc = value => String(value || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    const handedOver = Boolean(award.copy_handed_over_at) || award.copy_handed_over_method === 'tentative';
    const received = Boolean(award.copy_received_at) || award.copy_received_method === 'tentative';
    const action = !handedOver ? 'handover' : (!received ? 'receive' : 'complete');
    const noticeText = action === 'handover'
      ? 'Confirm only after the physical answer copies have been handed over to the teacher.'
      : action === 'receive'
        ? `Copies were handed over on ${esc(award.copy_handed_over_at)}. Confirm only after they have been returned to the examination department.`
        : `Custody completed. Handed over: ${esc(award.copy_handed_over_at)} · Returned: ${esc(award.copy_received_at)}.`;
    const buttonText = action === 'handover'
      ? 'Confirm Copies Handed Over'
      : action === 'receive' ? 'Confirm Copies Returned' : 'Copies Returned Successfully';
    res.send(`<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Award List Copy Receiving</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f7f4ec;color:#171717;font-family:'Trebuchet MS',Arial,sans-serif;min-height:100vh;display:grid;place-items:center;padding:18px}
.card{width:min(520px,100%);background:#fff;border:1px solid #e4dfd2;border-radius:20px;box-shadow:0 18px 50px rgba(0,0,0,.1);overflow:hidden}
.head{background:#111;color:#fff;padding:22px;text-align:center;border-bottom:5px solid #d5a313}.head h1{font-size:20px;margin:0 0 5px}.head p{margin:0;color:#d7d7d7;font-size:13px}
.body{padding:22px}.details{border:1px solid #ebe6da;border-radius:12px;overflow:hidden;margin-bottom:18px}.row{display:grid;grid-template-columns:125px 1fr;gap:12px;padding:11px 13px;border-bottom:1px solid #eee9df}.row:last-child{border:0}.label{color:#777;font-size:12px;text-transform:uppercase;font-weight:700}.value{font-size:14px;font-weight:700}
.notice{padding:13px;border-radius:10px;font-size:13px;line-height:1.45;margin-bottom:15px;background:${received ? '#eaf8ef' : '#fff7dc'};color:${received ? '#176c36' : '#705400'};border:1px solid ${received ? '#bce2c8' : '#ecd98d'}}
button,.action-link{width:100%;border:0;border-radius:11px;padding:14px;background:#d5a313;color:#111;font:700 15px inherit;cursor:pointer;text-align:center;text-decoration:none;display:block}.action-link{background:#171717;color:#fff;margin-top:10px}button:disabled{background:#d8d8d8;color:#777}.foot{text-align:center;color:#888;font-size:11px;margin-top:14px}
</style></head><body><main class="card"><div class="head"><h1>VCC Award List</h1><p>Copy Receiving Confirmation</p></div><div class="body">
<div class="details">
<div class="row"><span class="label">Class / Section</span><span class="value">${esc(award.class)}${award.section ? ' — ' + esc(award.section) : ''}</span></div>
<div class="row"><span class="label">Subject</span><span class="value">${esc(award.subject)}</span></div>
<div class="row"><span class="label">Test Date</span><span class="value">${esc(award.test_date)}</span></div>
<div class="row"><span class="label">Teacher</span><span class="value">${esc(award.teacher) || '—'}</span></div>
</div>
<div class="notice" id="notice">${noticeText}</div>
<button id="confirm" ${action === 'complete' ? 'disabled' : ''}>${buttonText}</button>
${handedOver ? `<a class="action-link" href="/award-list-marks/${token}">Enter Marks</a>` : ''}
<div class="foot">Secure QR confirmation · No attendance-system login required</div>
</div></main><script>
document.getElementById('confirm').addEventListener('click',async function(){
  const action='${action}';if(action==='complete')return;
  const question=action==='handover'?'Confirm that the physical answer copies have been handed over to the teacher?':'Confirm that the physical answer copies have been returned to the examination department?';
  if(!confirm(question))return;
  this.disabled=true;this.textContent='Saving...';
  try{const response=await fetch('/api/public/award-list-receive/${token}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action})});const data=await response.json();if(!response.ok)throw new Error(data.error||'Could not save');document.getElementById('notice').textContent=data.message+(action==='handover'?' To record the return later, scan the QR again or manually reload this page.':'');document.getElementById('notice').style.cssText='padding:13px;border-radius:10px;font-size:13px;line-height:1.45;margin-bottom:15px;background:#eaf8ef;color:#176c36;border:1px solid #bce2c8';this.textContent=action==='handover'?'Handed Over Successfully':'Returned Successfully'}catch(error){this.disabled=false;this.textContent=action==='handover'?'Confirm Copies Handed Over':'Confirm Copies Returned';alert(error.message)}
});
</script></body></html>`);
  } catch (err) {
    console.error('[award-list-receive] page error:', err.message || err);
    res.status(500).send('Could not open this award list. Please try again.');
  }
});

app.post('/api/public/award-list-receive/:token', async (req, res) => {
  try {
    const token = String(req.params.token || '');
    if (!/^[a-f0-9]{48}$/.test(token)) return res.status(404).json({ success:false, error:'Invalid award-list QR code.' });
    const { query, run } = require('./database');
    const action = String(req.body.action || '');
    if (!['handover', 'receive'].includes(action)) return res.status(400).json({ success:false, error:'Invalid confirmation action.' });
    const [award] = await query('SELECT id, copy_handed_over_at, copy_handed_over_method, copy_received_at, copy_received_method FROM award_lists WHERE qr_token = ? LIMIT 1', [token]);
    if (!award) return res.status(404).json({ success:false, error:'Award list not found.' });
    const nowPkt = new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0];
    if (action === 'handover') {
      if (award.copy_handed_over_at || award.copy_handed_over_method === 'tentative') return res.json({ success:true, already_handed_over:true, copy_handed_over_at:award.copy_handed_over_at, message:'Copies were already marked as handed over.' });
      await run('UPDATE award_lists SET copy_handed_over_at = ? WHERE id = ? AND copy_handed_over_at IS NULL', [nowPkt, award.id]);
      return res.json({ success:true, copy_handed_over_at:nowPkt, message:`Copies handed over successfully on ${nowPkt}.` });
    }
    if (!award.copy_handed_over_at && award.copy_handed_over_method !== 'tentative') return res.status(409).json({ success:false, error:'Copies must be marked as handed over before they can be returned.' });
    if (award.copy_received_at || award.copy_received_method === 'tentative') return res.json({ success:true, already_received:true, copy_received_at:award.copy_received_at, message:'Copies were already marked as returned.' });
    await run('UPDATE award_lists SET copy_received_at = ? WHERE id = ? AND copy_received_at IS NULL', [nowPkt, award.id]);
    res.json({ success:true, copy_received_at:nowPkt, message:`Copies returned successfully on ${nowPkt}.` });
  } catch (err) {
    console.error('[award-list-receive] confirmation error:', err.message || err);
    res.status(500).json({ success:false, error:'Could not save confirmation. Please try again.' });
  }
});

app.get('/award-list-marks/:token', async (req, res) => {
  try {
    const token = String(req.params.token || '');
    if (!/^[a-f0-9]{48}$/.test(token)) return res.status(404).send('Invalid award-list QR code.');
    const { query } = require('./database');
    const [award] = await query(`
      SELECT id, class, section, subject, test_date, teacher, total_marks, locked, copy_handed_over_at
      FROM award_lists WHERE qr_token = ? LIMIT 1
    `, [token]);
    if (!award) return res.status(404).send('Award list not found.');
    if (!award.copy_handed_over_at) return res.status(403).send('Copies must be handed over before marks can be entered.');
    const entries = await query(`
      SELECT id, gr_number, name, father_name, marks_obtained, special_status
      FROM award_list_entries WHERE award_list_id = ?
      ORDER BY CASE WHEN CAST(gr_number AS INTEGER) > 0 THEN CAST(gr_number AS INTEGER) ELSE 2147483647 END, id
    `, [award.id]);
    const esc = value => String(value ?? '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
    const hasSavedMarks = entries.some(entry => entry.marks_obtained !== null && entry.marks_obtained !== undefined || entry.special_status);
    const startsReadOnly = Boolean(award.locked || hasSavedMarks);
    const rows = entries.map((entry, index) => {
      // Fresh/blank entries begin as Absent; previously saved marks/statuses
      // remain unchanged when this page is reopened.
      const hasMarks = entry.marks_obtained !== null && entry.marks_obtained !== undefined;
      const status = entry.special_status || (hasMarks ? 'MARKS' : 'ABSENT');
      const statusLabel = status === 'ABSENT' ? 'Absent' : status === 'NOT_ADMITTED' ? 'Not Admitted' : 'Enter Marks';
      const marks = entry.marks_obtained === null || entry.marks_obtained === undefined ? '' : entry.marks_obtained;
      const searchText = `${entry.gr_number || ''} ${entry.name || ''} ${entry.father_name || ''}`.toLowerCase();
      return `<tr data-entry-id="${entry.id}" data-search="${esc(searchText)}"><td class="serial" data-label="S.No">${index + 1}</td><td class="gr" data-label="GR Number">${esc(entry.gr_number) || '—'}</td><td class="student" data-label="Student"><strong>${esc(entry.name)}</strong><small>Father: ${esc(entry.father_name) || '—'}</small></td><td class="marks-cell" data-label="Marks / ${award.total_marks}"><input class="marks" aria-label="Marks for ${esc(entry.name)}" inputmode="decimal" type="number" min="0" max="${award.total_marks}" step="0.01" placeholder="0–${award.total_marks}" value="${esc(marks)}" ${status !== 'MARKS' || startsReadOnly ? 'disabled' : ''}></td><td class="status-cell" data-label="Result Status"><div class="status-picker ${startsReadOnly ? 'picker-disabled' : ''}" data-status="${status}"><button type="button" class="status-toggle" ${startsReadOnly ? 'disabled' : ''}><span class="status-label">${statusLabel}</span><span class="chevron">⌄</span></button><div class="status-options"><button type="button" data-value="MARKS">Enter Marks</button><button type="button" data-value="ABSENT">Absent</button><button type="button" data-value="NOT_ADMITTED">Not Admitted</button></div><input type="hidden" class="status" value="${status}"></div></td></tr>`;
    }).join('');
    res.send(`<!DOCTYPE html><html lang="en" style="color-scheme:only light;background:#fff"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="only light"><meta name="supported-color-schemes" content="light"><meta name="theme-color" content="#ffffff"><title>Enter Award List Marks</title><style>
:root{color-scheme:only light;--ink:#211d16;--accent:#b7791f;--accent-soft:#fff8e8;--paper:#fff;--line:#eadfca;--muted:#746a5d;--green:#15803d;--red:#b42318}*{box-sizing:border-box}html{scroll-behavior:smooth;background:#fff!important;color:#211d16!important}body{margin:0;background:#fff!important;color:var(--ink)!important;font-family:'Trebuchet MS',Arial,sans-serif;font-size:13px;padding:12px 12px 94px}.wrap{max-width:1040px;margin:auto;background:#fff!important}.head{background:linear-gradient(135deg,#fff 0%,#fff8e8 100%)!important;color:var(--ink)!important;border:1px solid #ead7ad;border-left:5px solid var(--accent);border-radius:16px;padding:16px 18px;box-shadow:0 8px 24px rgba(123,82,20,.08);position:relative;overflow:hidden}.head:after{content:'';position:absolute;width:130px;height:130px;background:#f7e8bf;border-radius:50%;right:-60px;top:-72px;opacity:.8}.eyebrow{color:var(--accent);text-transform:uppercase;letter-spacing:1.2px;font-size:10px;font-weight:800}.head h1{margin:4px 0;font-size:22px}.head p{margin:0;color:#6f6251;font-size:13px}.meta{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin:9px 0}.meta div{background:#fff!important;color:var(--ink)!important;border:1px solid var(--line);border-radius:11px;padding:9px 11px}.meta small{display:block;color:var(--muted);font-size:10px;margin-bottom:3px}.meta strong{font-size:13px}.tools{position:sticky;top:4px;z-index:20;background:rgba(255,255,255,.97)!important;backdrop-filter:blur(10px);padding:6px 0 8px}.search-box{background:#fff!important;border:1.5px solid var(--line);border-radius:11px;padding:0 11px;display:flex;align-items:center;gap:8px;box-shadow:0 4px 14px rgba(123,82,20,.06)}.search-box:focus-within{border-color:var(--accent);box-shadow:0 0 0 3px rgba(183,121,31,.12)}.search-box span{font-size:17px;color:var(--accent)}.search-box input{border:0;outline:0;width:100%;font:700 14px inherit;padding:11px 0;background:#fff!important;color:var(--ink)!important}.progress{display:flex;justify-content:space-between;align-items:center;margin-top:6px;color:var(--muted);font-size:10.5px;font-weight:700}.progress-track{height:5px;background:#eee5d5;border-radius:99px;overflow:hidden;margin-top:5px}.progress-bar{height:100%;width:0;background:linear-gradient(90deg,#a86f16,#e0ad35);transition:width .2s}.card{background:#fff!important;border:1px solid var(--line);border-radius:15px;overflow:visible;box-shadow:0 8px 26px rgba(123,82,20,.06)}.table-wrap{overflow:visible;background:#fff!important}table{width:100%;border-collapse:collapse;background:#fff!important;color:var(--ink)!important}th{background:#fff8e8!important;color:#6f6251!important;text-align:left;font-size:10px;text-transform:uppercase;letter-spacing:.4px;padding:10px;border-bottom:1px solid var(--line)}td{padding:9px 10px;border-bottom:1px solid #f0eadf;font-size:12.5px;background:#fff!important;color:var(--ink)!important}tbody tr:last-child td{border-bottom:0}td small{display:block;color:var(--muted);font-size:10px;margin-top:3px}.serial{color:#9b9184;width:42px}.gr{font-weight:800;width:78px;color:var(--accent)}.marks-cell{width:150px}.status-cell{width:145px;position:relative}.marks,.status-toggle{width:100%;min-height:42px;padding:8px 9px;border:1.5px solid #dfd2bc;border-radius:9px;background:#fff!important;color:var(--ink)!important;font:700 13px inherit}.marks{text-align:center;font-size:16px}.marks:focus,.status-toggle:focus{outline:0;border-color:var(--accent);box-shadow:0 0 0 3px rgba(183,121,31,.12)}.marks:disabled,.status-toggle:disabled{background:#f5f1ea!important;color:#999084!important}.status-picker{position:relative}.status-toggle{display:flex;align-items:center;justify-content:space-between;gap:6px;cursor:pointer;text-align:left}.chevron{color:var(--accent);transition:transform .2s ease}.status-options{display:grid;position:static;max-height:0;opacity:0;overflow:hidden;min-width:155px;background:#fff;border:0;border-radius:9px;padding:0;box-shadow:none;transition:max-height .22s ease,opacity .18s ease,padding .22s ease}.status-picker.open .status-options{max-height:140px;opacity:1;padding:4px;margin-top:4px;border:1px solid #dfd2bc}.status-picker.open .chevron{transform:rotate(180deg)}.status-options button{border:0;background:#fff;color:var(--ink);padding:9px 10px;border-radius:6px;text-align:left;font:700 12px inherit;cursor:pointer}.status-options button:hover{background:#fff8e8}.status-picker[data-status="ABSENT"] .status-toggle{border-color:#fecaca;background:#fff5f5!important;color:#b42318!important}.status-picker[data-status="NOT_ADMITTED"] .status-toggle{border-color:#f5d18a;background:#fff9e8!important;color:#875a10!important}.empty{display:none;text-align:center;padding:28px;color:var(--muted);background:#fff!important}.locked{margin:9px 0;padding:11px;background:#fff1f2!important;color:#9f1239;border:1px solid #fecdd3;border-radius:9px;font-weight:700}.actions{position:fixed;left:0;right:0;bottom:0;z-index:30;background:#fff!important;backdrop-filter:blur(12px);border-top:1px solid var(--line);padding:9px max(12px,calc((100vw - 1040px)/2));display:flex;gap:8px;align-items:center;box-shadow:0 -5px 20px rgba(123,82,20,.08)}.save,.edit,.back{border:0;border-radius:10px;min-height:46px;padding:11px 17px;font:800 13px inherit;text-decoration:none;text-align:center}.save{background:linear-gradient(135deg,#a86f16,#d9a526)!important;color:#fff!important;cursor:pointer;min-width:170px}.save:disabled{background:#d7d0c5!important;color:#756d62!important}.edit{background:#211d16;color:#fff;cursor:pointer}.edit[hidden]{display:none}.back{background:#fff8e8!important;color:#8a5b12!important;border:1px solid #e7d2a6}.msg{font-size:12px;font-weight:700;flex:1;text-align:center}.saved-flash{animation:flash .7s ease}@keyframes flash{50%{background:#fff6dc}}
@media(max-width:680px){body{padding:7px 7px 91px;font-size:12px;background:#fff!important}.head{border-radius:13px;padding:11px 12px}.head h1{font-size:18px;margin:2px 0}.head p{font-size:11.5px}.eyebrow{font-size:8.5px}.meta{grid-template-columns:1fr 1fr;gap:5px;margin:6px 0}.meta div{padding:7px 9px;border-radius:9px}.meta small{font-size:9px;margin-bottom:2px}.meta strong{font-size:11.5px}.tools{top:0;padding:4px 0 6px}.search-box{border-radius:9px;padding:0 9px}.search-box input{font-size:12.5px;padding:9px 0}.search-box span{font-size:15px}.progress{font-size:9.5px;margin-top:5px}.card{background:transparent!important;border:0;box-shadow:none;overflow:visible}.table-wrap{overflow:visible;background:#fff!important}table,tbody{display:block;background:#fff!important}thead{display:none}tr[data-entry-id]{display:grid;grid-template-columns:minmax(112px,1fr) minmax(120px,1.05fr);gap:6px;background:#fff!important;color:var(--ink)!important;border:1px solid var(--line);border-left:4px solid #d5a12b;border-radius:11px;padding:8px 9px;margin-bottom:6px;box-shadow:0 3px 10px rgba(123,82,20,.06);position:relative}td{display:block;border:0!important;padding:0;background:#fff!important}.serial{grid-column:1;width:auto;color:#9b9184;font-size:9.5px}.serial:before{content:'#'}.gr{grid-column:2;grid-row:1;text-align:right;width:auto;color:var(--accent);font-size:11px}.student{grid-column:1/-1;padding-bottom:6px!important;border-bottom:1px solid #f0eadf!important}.student strong{font-size:13.5px;line-height:1.15}.student small{font-size:9.5px;margin-top:2px}.marks-cell,.status-cell{width:auto}.marks-cell{grid-column:1}.status-cell{grid-column:2}.marks-cell:before,.status-cell:before{display:block;color:var(--muted);font-size:8px;font-weight:800;text-transform:uppercase;margin-bottom:3px}.marks-cell:before{content:'Marks / ${award.total_marks}'}.status-cell:before{content:'Result Status'}.marks,.status-toggle{min-height:40px;padding:7px;font-size:11.5px;border-radius:8px}.marks{font-size:15px}.status-options{min-width:145px}.actions{padding:7px}.back{width:62px;padding:9px 5px}.save{flex:1;min-width:0}.save,.edit,.back{min-height:44px;font-size:12px;padding:9px}.msg{position:absolute;left:8px;right:8px;bottom:59px;background:#fff!important;border-radius:8px;padding:6px;box-shadow:0 4px 14px rgba(0,0,0,.12);display:none}.msg:not(:empty){display:block}}
@media(prefers-color-scheme:dark){html,body,.wrap,.meta div,.tools,.search-box,.search-box input,.card,.table-wrap,table,tbody,tr[data-entry-id],td,.actions,.marks,.status-toggle,.status-options,.status-options button{background:#fff!important;color:#211d16!important}.head{background:linear-gradient(135deg,#fff,#fff8e8)!important;color:#211d16!important}.marks,.status-toggle,.search-box input{-webkit-text-fill-color:#211d16!important}}
</style></head><body><main class="wrap"><header class="head"><div class="eyebrow">VCC · Secure Award List</div><h1>Enter Student Marks</h1><p>${esc(award.subject)} · Class ${esc(award.class)}${award.section ? ' — Section ' + esc(award.section) : ''}</p></header><section class="meta"><div><small>Test Date</small><strong>${esc(award.test_date)}</strong></div><div><small>Teacher</small><strong>${esc(award.teacher) || '—'}</strong></div><div><small>Total Marks</small><strong>${esc(award.total_marks)}</strong></div><div><small>Total Students</small><strong>${entries.length}</strong></div></section>${award.locked ? '<div class="locked">🔒 This award list is locked. Marks can be viewed but cannot be changed.</div>' : ''}<section class="tools"><label class="search-box"><span>⌕</span><input id="student-search" type="search" autocomplete="off" placeholder="Search by student name or GR number"></label><div class="progress"><span id="visible-count">Showing ${entries.length} students</span><span id="entry-count">0 of ${entries.length} completed</span></div><div class="progress-track"><div class="progress-bar" id="progress-bar"></div></div></section><section class="card"><div class="table-wrap"><table><thead><tr><th>#</th><th>GR#</th><th>Student</th><th>Marks</th><th>Status</th></tr></thead><tbody>${rows}</tbody></table><div class="empty" id="empty-state">No student found. Check the name or GR number.</div></div></section></main><footer class="actions"><a class="back" href="/award-list-receive/${token}">← Back</a><span class="msg" id="msg"></span><button class="edit" id="edit" ${hasSavedMarks && !award.locked ? '' : 'hidden'}>Edit Marks</button><button class="save" id="save" ${startsReadOnly ? 'disabled' : ''}>${award.locked ? 'Locked' : hasSavedMarks ? 'Marks Saved ✓' : 'Save Marks'}</button></footer><script>
const allRows=Array.from(document.querySelectorAll('tr[data-entry-id]'));const search=document.getElementById('student-search');const visibleCount=document.getElementById('visible-count');const entryCount=document.getElementById('entry-count');const progressBar=document.getElementById('progress-bar');const saveButton=document.getElementById('save');const editButton=document.getElementById('edit');const msg=document.getElementById('msg');const isLocked=${award.locked ? 'true' : 'false'};let editing=${startsReadOnly ? 'false' : 'true'};
function updateSummary(){let completed=0;allRows.forEach(function(row){const status=row.querySelector('.status').value;const value=row.querySelector('.marks').value;if(status!=='MARKS'||value!=='')completed++});entryCount.textContent=completed+' of '+allRows.length+' completed';progressBar.style.width=(allRows.length?completed/allRows.length*100:0)+'%'}
function labelForStatus(value){return value==='ABSENT'?'Absent':value==='NOT_ADMITTED'?'Not Admitted':'Enter Marks'}
function closePickers(except){document.querySelectorAll('.status-picker.open').forEach(function(picker){if(picker!==except)picker.classList.remove('open')})}
function setStatus(picker,value,clearMarks){const hidden=picker.querySelector('.status');const row=picker.closest('tr');const input=row.querySelector('.marks');hidden.value=value;picker.dataset.status=value;picker.querySelector('.status-label').textContent=labelForStatus(value);if(clearMarks&&value!=='MARKS')input.value='';input.disabled=!editing||value!=='MARKS'||isLocked;picker.classList.remove('open');updateSummary();if(value==='MARKS'&&editing)setTimeout(function(){input.focus()},0)}
document.querySelectorAll('.status-picker').forEach(function(picker){const toggle=picker.querySelector('.status-toggle');toggle.addEventListener('click',function(event){event.stopPropagation();if(!editing||isLocked)return;const willOpen=!picker.classList.contains('open');closePickers();picker.classList.toggle('open',willOpen)});picker.querySelectorAll('.status-options button').forEach(function(option){option.addEventListener('click',function(event){event.stopPropagation();setStatus(picker,this.dataset.value,true)})})});document.addEventListener('click',function(){closePickers()});document.querySelectorAll('.marks').forEach(function(input){input.addEventListener('input',updateSummary)});
function setEditing(enabled){editing=Boolean(enabled&&!isLocked);closePickers();allRows.forEach(function(row){const picker=row.querySelector('.status-picker');const toggle=picker.querySelector('.status-toggle');const status=row.querySelector('.status').value;toggle.disabled=!editing;picker.classList.toggle('picker-disabled',!editing);row.querySelector('.marks').disabled=!editing||status!=='MARKS'});saveButton.disabled=!editing;editButton.hidden=editing||isLocked;if(editing){saveButton.textContent='Save Marks';msg.style.color='#8a5b12';msg.textContent='Editing enabled — make corrections and save again.'}}
editButton.addEventListener('click',function(){setEditing(true)});
search.addEventListener('input',function(){const term=this.value.trim().toLowerCase();let shown=0;allRows.forEach(function(row){const match=!term||row.dataset.search.includes(term);row.style.display=match?'':'none';if(match)shown++});visibleCount.textContent='Showing '+shown+' student'+(shown===1?'':'s');document.getElementById('empty-state').style.display=shown?'none':'block'});updateSummary();
saveButton.addEventListener('click',async function(){const invalidRow=allRows.find(function(row){const status=row.querySelector('.status').value;const value=row.querySelector('.marks').value;if(status!=='MARKS'||value==='')return false;const marks=Number(value);const validPrecision=Math.abs(marks*100-Math.round(marks*100))<1e-8;return!Number.isFinite(marks)||!validPrecision||marks<0||marks>${Number(award.total_marks)}});if(invalidRow){msg.style.color='#a51d1d';msg.textContent='Enter marks from 0 to ${award.total_marks} (up to 2 decimal places).';invalidRow.scrollIntoView({behavior:'smooth',block:'center'});invalidRow.querySelector('.marks').focus();return}const entries=allRows.map(function(row){const status=row.querySelector('.status').value;const value=row.querySelector('.marks').value;return{entry_id:Number(row.dataset.entryId),marks_obtained:status==='MARKS'&&value!==''?value:null,special_status:status==='MARKS'?null:status}});saveButton.disabled=true;saveButton.textContent='Saving...';msg.textContent='';try{const response=await fetch('/api/public/award-list-marks/${token}',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({entries})});const data=await response.json();if(!response.ok)throw new Error(data.error||'Could not save marks');msg.style.color='#176c36';msg.textContent='✓ Marks saved successfully';document.querySelector('.card').classList.add('saved-flash');setEditing(false);saveButton.textContent='Marks Saved ✓';setTimeout(function(){msg.textContent='';document.querySelector('.card').classList.remove('saved-flash')},1800)}catch(error){msg.style.color='#a51d1d';msg.textContent=error.message;saveButton.disabled=false;saveButton.textContent='Save Marks'}});
</script></body></html>`);
  } catch (err) {
    console.error('[award-list-marks] page error:', err.message || err);
    res.status(500).send('Could not open marks entry. Please try again.');
  }
});

app.post('/api/public/award-list-marks/:token', async (req, res) => {
  try {
    const token = String(req.params.token || '');
    if (!/^[a-f0-9]{48}$/.test(token)) return res.status(404).json({ success:false, error:'Invalid award-list QR code.' });
    const { query, run } = require('./database');
    const [award] = await query('SELECT id, total_marks, locked, copy_handed_over_at FROM award_lists WHERE qr_token = ? LIMIT 1', [token]);
    if (!award) return res.status(404).json({ success:false, error:'Award list not found.' });
    if (!award.copy_handed_over_at) return res.status(403).json({ success:false, error:'Copies must be handed over before marks can be entered.' });
    if (award.locked) return res.status(409).json({ success:false, error:'This award list is locked and cannot be edited.' });
    const entries = req.body.entries;
    if (!Array.isArray(entries)) return res.status(400).json({ success:false, error:'Marks entries are required.' });
    const validRows = await query('SELECT id FROM award_list_entries WHERE award_list_id = ?', [award.id]);
    const validIds = new Set(validRows.map(row => Number(row.id)));
    for (const entry of entries) {
      const entryId = Number(entry.entry_id);
      if (!validIds.has(entryId)) return res.status(400).json({ success:false, error:'Invalid student entry.' });
      if (entry.special_status === 'ABSENT' || entry.special_status === 'NOT_ADMITTED') {
        await run('UPDATE award_list_entries SET marks_obtained = NULL, special_status = ? WHERE id = ? AND award_list_id = ?', [entry.special_status, entryId, award.id]);
      } else if (entry.marks_obtained === null || entry.marks_obtained === undefined || entry.marks_obtained === '') {
        await run('UPDATE award_list_entries SET marks_obtained = NULL, special_status = NULL WHERE id = ? AND award_list_id = ?', [entryId, award.id]);
      } else {
        const marks = Number(entry.marks_obtained);
        const validPrecision = Math.abs(marks * 100 - Math.round(marks * 100)) < 1e-8;
        if (!Number.isFinite(marks) || !validPrecision || marks < 0 || marks > Number(award.total_marks)) return res.status(400).json({ success:false, error:`Marks must be from 0 to ${award.total_marks}, with up to 2 decimal places.` });
        const normalizedMarks = Math.round((marks + Number.EPSILON) * 100) / 100;
        await run('UPDATE award_list_entries SET marks_obtained = ?, special_status = NULL WHERE id = ? AND award_list_id = ?', [normalizedMarks, entryId, award.id]);
      }
    }
    res.json({ success:true });
  } catch (err) {
    console.error('[award-list-marks] save error:', err.message || err);
    res.status(500).json({ success:false, error:'Could not save marks. Please try again.' });
  }
});

app.get('/sms-document/:token', require('./message-channel').documentRoute);
// Everything below requires login
app.use(requireLogin);

// Static files
app.use(express.static(path.join(__dirname, '../frontend')));

// API routes
app.use('/api', require('./message-channel').middleware);
app.use('/api/students', require('./routes/students'));
app.use('/api/reports', require('./routes/reports'));
app.use('/api/attendance', require('./routes/attendance'));
app.use('/api/flagged', require('./routes/flagged'));
app.use('/api/daily-summary', require('./routes/daily-summary'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/holidays', require('./routes/holidays'));
app.use('/api/notes', require('./routes/notes'));
app.use('/api/examination', require('./routes/examination'));
app.use('/api/update', require('./routes/update'));
// Sync status endpoint — shows online/offline + last sync time
app.get('/api/sync-status', (req, res) => {
  const { getSyncStatus } = require('./database');
  res.json(getSyncStatus());
});


// Backup DB
app.post('/api/backup', async (req, res) => {
  try {
    const backupPath = await backupDb();
    const filename = require('path').basename(backupPath);
    res.json({ success: true, message: 'Backup created successfully', filename });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Reasons that won't fix themselves by simply waiting and retrying the same
// number again — no point burning the full 12h retry window on these.
const PERMANENT_FAIL_REASONS = [
  'No valid phone number to retry',
  'No valid phone number on file',
  'Primary number not on WhatsApp, no backup number on file',
  'Both numbers not on WhatsApp',
  'Backup number not on WhatsApp',
  'Number not on WhatsApp'
];

// ── Retry a single whatsapp_log row ──────────────────────────────────────────
// If the row has a student_uid, re-run the FULL smartSend logic (phone1 on-WA
// check → phone2 fallback) — exactly what would happen on a fresh send.
// Only old rows with no student_uid fall back to a plain on-WA check + resend
// on the single phone stored on the row (no phone2 to fall back to anyway).
async function retryWhatsappLogRow(row) {
  if (String(row.msg_id || '').startsWith('sms:')) return {sent:false,phone:row.phone,reason:'Retry this message from the SMS log; its channel is SMS.'};
  const { query } = require('./database');
  const { sendMessage, smartSendWhatsApp: smartSend, checkOnWhatsApp, isValidPhone } = require('./whatsapp');

  if (row.student_uid) {
    const students = await query('SELECT * FROM students WHERE student_uid = ?', [row.student_uid]);
    if (students.length) {
      return await smartSend(students[0], row.message, require('./database')); // { sent, phone, usedFallback, msgId, reason }
    }
  }

  if (!isValidPhone(row.phone)) {
    return { sent: false, phone: row.phone, usedFallback: false, msgId: null, reason: 'No valid phone number to retry' };
  }
  const onWA = await checkOnWhatsApp(row.phone);
  if (onWA === false) {
    return { sent: false, phone: row.phone, usedFallback: false, msgId: null, reason: 'Number not on WhatsApp' };
  }
  const res = await sendMessage(row.phone, row.message);
  return { sent: res.success, phone: row.phone, usedFallback: false, msgId: res.msgId, reason: res.reason };
}

// ── WHATSAPP RETRY QUEUE ──
// Runs every 2 minutes. Picks all failed rows where retry_until is still in future.
// On success → status = 'sent'. On expiry → status = 'expired'.
// Guard flag prevents overlap: if previous run takes >2 min, next tick is skipped.
function startRetryLoop() {
  const INTERVAL = 2 * 60 * 1000; // 2 minutes
  let retryRunning = false;

  setInterval(async () => {
    if (retryRunning) return; // previous run still in progress — skip to avoid duplicates
    retryRunning = true;

    try {
      const { query, run } = require('./database');
      const { getStatus, refreshConnection, initWhatsApp } = require('./whatsapp');
      if (!getStatus().isReady) {
        await refreshConnection();
        if (!getStatus().isReady) await initWhatsApp();
        if (!getStatus().isReady) return;
      }

      const now = new Date().toISOString().replace('T', ' ').split('.')[0];

      // Expire rows past their retry_until
      await run(
        `UPDATE whatsapp_log SET status='expired' WHERE status='failed' AND retry_until IS NOT NULL AND retry_until < ?`,
        [now]
      );

      // Get pending rows still within retry window
      // (PDF-based sends — monthly reports, exam reports, test plans — have their
      // own retry flow that regenerates the file; this loop only handles plain-text
      // resends and would otherwise send the placeholder text instead of the PDF)
      const pending = await query(
        `SELECT * FROM whatsapp_log WHERE status='failed' AND COALESCE(msg_id,'') NOT LIKE 'sms:%' AND retry_until IS NOT NULL AND retry_until >= ? AND (log_type IS NULL OR log_type NOT IN ('MONTHLY_REPORT','EXAM_REPORT','TEST_PLAN_PDF')) ORDER BY timestamp ASC`,
        [now]
      );

      for (const row of pending) {
        const result = await retryWhatsappLogRow(row);

        if (result.sent) {
          await run(`UPDATE whatsapp_log SET status='sent', retry_count=retry_count+1, phone=?, used_phone2=?, msg_id=?, fail_reason=NULL WHERE id=?`,
            [result.phone, result.usedFallback ? 1 : 0, result.msgId, row.id]);
        } else if (PERMANENT_FAIL_REASONS.includes(result.reason)) {
          // Permanently unreachable — stop wasting retry cycles on it
          await run(`UPDATE whatsapp_log SET status='expired', retry_count=retry_count+1, fail_reason=? WHERE id=?`, [result.reason, row.id]);
        } else {
          await run(`UPDATE whatsapp_log SET retry_count=retry_count+1, phone=?, used_phone2=?, fail_reason=? WHERE id=?`,
            [result.phone, result.usedFallback ? 1 : 0, result.reason, row.id]);
        }
      }
    } finally {
      retryRunning = false; // always release lock, even if an error occurs
    }
  }, INTERVAL);
}

// Manually resend selected failed messages (by IDs)
app.post('/api/whatsapp/retry', async (req, res) => {
  try {
    const { ids } = req.body; // array of whatsapp_log row IDs
    if (!ids || !ids.length) return res.status(400).json({ success: false, error: 'No IDs provided' });
    const { query, run } = require('./database');

    let sent = 0, failed = 0;
    const RETRY_HOURS = 12;
    const retryUntil = new Date(Date.now() + RETRY_HOURS * 60 * 60 * 1000)
      .toISOString().replace('T', ' ').split('.')[0];

    for (const id of ids) {
      const rows = await query(`SELECT * FROM whatsapp_log WHERE id=?`, [id]);
      if (!rows.length) continue;
      const row = rows[0];

      // PDF-based sends (exam reports, test plans) can't be resent as plain
      // text — the stored "message" is just a placeholder. Resending here
      // would deliver garbage text instead of the actual PDF. These must be
      // regenerated and resent from their source page (Examination tab).
      if (row.log_type === 'EXAM_REPORT' || row.log_type === 'TEST_PLAN_PDF') {
        await run(`UPDATE whatsapp_log SET fail_reason=? WHERE id=?`,
          ['This is a PDF send — resend from the Examination page, not from here', id]);
        failed++;
        continue;
      }

      const result = await retryWhatsappLogRow(row);

      if (result.sent) {
        await run(`UPDATE whatsapp_log SET status='sent', retry_count=retry_count+1, retry_until=NULL, phone=?, used_phone2=?, msg_id=?, fail_reason=NULL WHERE id=?`,
          [result.phone, result.usedFallback ? 1 : 0, result.msgId, id]);
        sent++;
      } else if (PERMANENT_FAIL_REASONS.includes(result.reason)) {
        await run(`UPDATE whatsapp_log SET status='expired', retry_count=retry_count+1, retry_until=NULL, fail_reason=? WHERE id=?`, [result.reason, id]);
        failed++;
      } else {
        // Mark for auto-retry queue (12 hrs from now)
        await run(`UPDATE whatsapp_log SET retry_count=retry_count+1, retry_until=?, phone=?, used_phone2=?, fail_reason=? WHERE id=?`,
          [retryUntil, result.phone, result.usedFallback ? 1 : 0, result.reason, id]);
        failed++;
      }
    }
    res.json({ success: true, sent, failed });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── Data Management Routes ────────────────────────────────────────────────────

// Preview count for a date range
app.post('/api/data/preview-range', requireLogin, async (req, res) => {
  try {
    const { from, to, type } = req.body;
    if (!from || !to) return res.json({ success: false, error: 'Missing dates' });
    const { query } = require('./database');
    let count;
    if (type === 'attendance') {
      const [row] = await query('SELECT COUNT(*) as cnt FROM attendance WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
      count = row.cnt;
    } else {
      const [row] = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
      count = row.cnt;
    }
    res.json({ success: true, count });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Delete records in a date range
app.post('/api/data/delete-range', requireLogin, async (req, res) => {
  try {
    const { from, to, type } = req.body;
    if (!from || !to) return res.json({ success: false, error: 'Missing dates' });
    const { run, query } = require('./database');
    let deleted;
    if (type === 'attendance') {
      const [row] = await query('SELECT COUNT(*) as cnt FROM attendance WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
      deleted = row.cnt;
      await run('DELETE FROM attendance WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
    } else {
      const [row] = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
      deleted = row.cnt;
      await run('DELETE FROM whatsapp_log WHERE date(timestamp) BETWEEN ? AND ?', [from, to]);
    }
    res.json({ success: true, deleted });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Delete attendance records older than N months
app.post('/api/data/delete-attendance', requireLogin, async (req, res) => {
  try {
    const { months } = req.body;
    if (!months || isNaN(months) || months < 1) return res.json({ success: false, error: 'Invalid months value' });
    const { run, query } = require('./database');
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - parseInt(months));
    const cutoffStr = cutoff.toISOString().split('T')[0];
    const before = await query('SELECT COUNT(*) as cnt FROM attendance WHERE date(timestamp) < ?', [cutoffStr]);
    await run('DELETE FROM attendance WHERE date(timestamp) < ?', [cutoffStr]);
    res.json({ success: true, deleted: before[0].cnt, cutoff: cutoffStr });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Delete WhatsApp logs older than N months
app.post('/api/data/delete-wlogs', requireLogin, async (req, res) => {
  try {
    const { months } = req.body;
    if (!months || isNaN(months) || months < 1) return res.json({ success: false, error: 'Invalid months value' });
    const { run, query } = require('./database');
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - parseInt(months));
    const cutoffStr = cutoff.toISOString().split('T')[0];
    const before = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE date(timestamp) < ?', [cutoffStr]);
    await run('DELETE FROM whatsapp_log WHERE date(timestamp) < ?', [cutoffStr]);
    res.json({ success: true, deleted: before[0].cnt, cutoff: cutoffStr });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Delete students with status = left/inactive + their attendance + WA logs
app.post('/api/data/delete-old-students', requireLogin, async (req, res) => {
  try {
    const { status } = req.body; // 'left' or 'inactive' or 'all-inactive'
    const { run, query } = require('./database');
    let students;
    if (status === 'all-inactive') {
      students = await query("SELECT student_uid FROM students WHERE LOWER(status) IN ('left','inactive','dropped','withdrawn')");
    } else {
      students = await query("SELECT student_uid FROM students WHERE LOWER(status) = ?", [status.toLowerCase()]);
    }
    const uids = students.map(s => s.student_uid);
    if (uids.length === 0) return res.json({ success: true, deleted: 0 });
    const placeholders = uids.map(() => '?').join(',');
    await run(`DELETE FROM attendance WHERE student_uid IN (${placeholders})`, uids);
    await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${placeholders})`, uids);
    await run(`DELETE FROM students WHERE student_uid IN (${placeholders})`, uids);
    res.json({ success: true, deleted: uids.length });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// Get counts for preview before delete
app.post('/api/data/preview', requireLogin, async (req, res) => {
  try {
    const { query } = require('./database');
    const { months } = req.body;
    const cutoff = new Date();
    cutoff.setMonth(cutoff.getMonth() - parseInt(months || 6));
    const cutoffStr = cutoff.toISOString().split('T')[0];
    const att  = await query('SELECT COUNT(*) as cnt FROM attendance WHERE date(timestamp) < ?', [cutoffStr]);
    const wlog = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE date(timestamp) < ?', [cutoffStr]);
    const left = await query("SELECT COUNT(*) as cnt FROM students WHERE LOWER(status) IN ('left','inactive','dropped','withdrawn')");
    res.json({ success: true, attendance: att[0].cnt, wlogs: wlog[0].cnt, oldStudents: left[0].cnt, cutoff: cutoffStr });
  } catch (e) {
    res.json({ success: false, error: e.message });
  }
});

// ── Advanced Delete Routes ────────────────────────────────────────────────────

// Search students by name or GR for delete UI
app.get('/api/data/search-students', requireLogin, async (req, res) => {
  try {
    const { q } = req.query;
    if (!q || q.length < 2) return res.json({ success: true, students: [] });
    const { query } = require('./database');
    const students = await query(
      "SELECT student_uid, name, gr_number, class, group_name, status FROM students WHERE name LIKE ? OR gr_number LIKE ? LIMIT 20",
      [`%${q}%`, `%${q}%`]
    );
    res.json({ success: true, students });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Preview by student UID
app.post('/api/data/preview-student', requireLogin, async (req, res) => {
  try {
    const { uid } = req.body;
    const { query } = require('./database');
    const [attRow]  = await query('SELECT COUNT(*) as cnt FROM attendance WHERE student_uid = ?', [uid]);
    const [wlogRow] = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE student_uid = ?', [uid]);
    res.json({ success: true, attendance: attRow.cnt, wlogs: wlogRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Preview multiple students by GR number before a bulk delete.
// Keep this separate from the destructive endpoint so the settings page can
// show the exact matched students and any GR numbers that were not found.
app.post('/api/data/preview-bulk-students', requireLogin, async (req, res) => {
  try {
    const rawGRs = Array.isArray(req.body.grNumbers) ? req.body.grNumbers : [];
    const grNumbers = [...new Set(rawGRs.map(value => String(value).trim()).filter(Boolean))];
    if (!grNumbers.length) {
      return res.status(400).json({ success: false, error: 'At least one GR number is required.' });
    }
    if (grNumbers.length > 500) {
      return res.status(400).json({ success: false, error: 'A maximum of 500 GR numbers can be processed at once.' });
    }

    const { query } = require('./database');
    const placeholders = grNumbers.map(() => '?').join(',');
    const rows = await query(
      `SELECT student_uid, name, father_name, gr_number, class, section, status
       FROM students
       WHERE TRIM(gr_number) IN (${placeholders})`,
      grNumbers
    );
    const order = new Map(grNumbers.map((gr, index) => [gr, index]));
    rows.sort((a, b) => (order.get(String(a.gr_number).trim()) ?? 999999) - (order.get(String(b.gr_number).trim()) ?? 999999));
    const found = new Set(rows.map(row => String(row.gr_number).trim()));

    res.json({
      success: true,
      matched: rows,
      notFound: grNumbers.filter(gr => !found.has(gr))
    });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Update only the students identified in the GR preview, even if a GR is
// reassigned to another student before the operator confirms the change.
app.post('/api/data/update-bulk-student-status', requireLogin, async (req, res) => {
  try {
    const { status, students } = req.body || {};
    if (status !== 'active' && status !== 'inactive') {
      return res.status(400).json({ success: false, error: 'Choose Active or Inactive.' });
    }
    if (!Array.isArray(students) || !students.length || students.length > 500 ||
        students.some(student => typeof student?.student_uid !== 'string' || !student.student_uid.trim() ||
          typeof student.gr_number !== 'string' || !student.gr_number.trim())) {
      return res.status(400).json({ success: false, error: 'Preview and select between 1 and 500 students by GR number.' });
    }

    const { run } = require('./database');
    const pairs = students.map(student => [student.student_uid, student.gr_number.trim()]);
    const placeholders = pairs.map(() => '(?, ?)').join(', ');
    const result = await run(
      `UPDATE students SET status = ?
       WHERE (student_uid, TRIM(gr_number)) IN (VALUES ${placeholders})
         AND (status IS NULL OR status <> ?)`,
      [status, ...pairs.flat(), status]
    );
    res.json({ success: true, updated: result.rowsAffected });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Delete records for multiple students selected by GR number. Award-list
// snapshots are intentionally left intact so historical examination records
// are not destroyed when a current student record is removed.
app.post('/api/data/delete-bulk-students', requireLogin, async (req, res) => {
  try {
    const rawGRs = Array.isArray(req.body.grNumbers) ? req.body.grNumbers : [];
    const grNumbers = [...new Set(rawGRs.map(value => String(value).trim()).filter(Boolean))];
    const what = String(req.body.what || '');
    const allowed = new Set(['attendance', 'wlog', 'att+wlog', 'all']);
    if (!grNumbers.length) {
      return res.status(400).json({ success: false, error: 'At least one GR number is required.' });
    }
    if (grNumbers.length > 500) {
      return res.status(400).json({ success: false, error: 'A maximum of 500 GR numbers can be processed at once.' });
    }
    if (!allowed.has(what)) {
      return res.status(400).json({ success: false, error: 'Invalid bulk delete option.' });
    }

    const { query, run } = require('./database');
    const grPlaceholders = grNumbers.map(() => '?').join(',');
    const students = await query(
      `SELECT student_uid, gr_number FROM students WHERE TRIM(gr_number) IN (${grPlaceholders})`,
      grNumbers
    );
    const uids = students.map(student => student.student_uid).filter(Boolean);
    if (!uids.length) return res.json({ success: true, count: 0 });

    const uidPlaceholders = uids.map(() => '?').join(',');
    if (what === 'all' || what === 'attendance' || what === 'att+wlog') {
      await run(`DELETE FROM attendance WHERE student_uid IN (${uidPlaceholders})`, uids);
    }
    if (what === 'all' || what === 'wlog' || what === 'att+wlog') {
      await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${uidPlaceholders})`, uids);
    }
    if (what === 'all') {
      await run(`DELETE FROM students WHERE student_uid IN (${uidPlaceholders})`, uids);
    }

    res.json({ success: true, count: uids.length });
  } catch (e) {
    res.status(500).json({ success: false, error: e.message });
  }
});

// Delete by student — full (student + attendance + wlog) or partial
app.post('/api/data/delete-student', requireLogin, async (req, res) => {
  try {
    const { uid, what } = req.body; // what: 'all' | 'attendance' | 'wlog' | 'att+wlog'
    const { run } = require('./database');
    if (what === 'all' || what === 'attendance' || what === 'att+wlog') await run('DELETE FROM attendance WHERE student_uid = ?', [uid]);
    if (what === 'all' || what === 'wlog'       || what === 'att+wlog') await run('DELETE FROM whatsapp_log WHERE student_uid = ?', [uid]);
    if (what === 'all') await run('DELETE FROM students WHERE student_uid = ?', [uid]);
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Preview by class
app.post('/api/data/preview-class', requireLogin, async (req, res) => {
  try {
    const { cls, from, to } = req.body;
    const { query } = require('./database');
    const dateFilter = from && to ? ' AND date(a.timestamp) BETWEEN ? AND ?' : '';
    const params = from && to ? [cls, from, to] : [cls];
    const [attRow]  = await query(`SELECT COUNT(*) as cnt FROM attendance a JOIN students s ON a.student_uid=s.student_uid WHERE s.class=?${dateFilter}`, params);
    const [wlogRow] = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE student_class = ?', [cls]);
    const [studRow] = await query('SELECT COUNT(*) as cnt FROM students WHERE class = ?', [cls]);
    res.json({ success: true, attendance: attRow.cnt, wlogs: wlogRow.cnt, students: studRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete by class
app.post('/api/data/delete-class', requireLogin, async (req, res) => {
  try {
    const { cls, what, from, to } = req.body;
    const { run, query } = require('./database');
    const uidRows = await query('SELECT student_uid FROM students WHERE class = ?', [cls]);
    const uids = uidRows.map(r => r.student_uid);
    if (!uids.length) return res.json({ success: true, deleted: 0 });
    const ph = uids.map(() => '?').join(',');
    const dateFilter = from && to ? ' AND date(timestamp) BETWEEN ? AND ?' : '';
    const dateParams = from && to ? [from, to] : [];
    if (what === 'attendance' || what === 'all') await run(`DELETE FROM attendance WHERE student_uid IN (${ph})${dateFilter}`, [...uids, ...dateParams]);
    if (what === 'wlog'       || what === 'all') await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${ph})`, uids);
    if (what === 'students'   || what === 'all') { await run(`DELETE FROM attendance WHERE student_uid IN (${ph})`, uids); await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${ph})`, uids); await run(`DELETE FROM students WHERE class = ?`, [cls]); }
    res.json({ success: true });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete by attendance type (IN/OUT) in date range
app.post('/api/data/delete-by-type', requireLogin, async (req, res) => {
  try {
    const { attType, from, to } = req.body; // attType: 'IN' | 'OUT'
    const { run, query } = require('./database');
    const dateFilter = from && to ? ' AND date(timestamp) BETWEEN ? AND ?' : '';
    const params = from && to ? [attType, from, to] : [attType];
    const [beforeRow] = await query(`SELECT COUNT(*) as cnt FROM attendance WHERE type=?${dateFilter}`, params);
    await run(`DELETE FROM attendance WHERE type=?${dateFilter}`, params);
    res.json({ success: true, deleted: beforeRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete manual attendance records
app.post('/api/data/delete-manual', requireLogin, async (req, res) => {
  try {
    const { from, to } = req.body;
    const { run, query } = require('./database');
    const dateFilter = from && to ? ' AND date(timestamp) BETWEEN ? AND ?' : '';
    const params = from && to ? [from, to] : [];
    const [beforeRow] = await query(`SELECT COUNT(*) as cnt FROM attendance WHERE manual_no_time=1${dateFilter}`, params);
    await run(`DELETE FROM attendance WHERE manual_no_time=1${dateFilter}`, params);
    res.json({ success: true, deleted: beforeRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete WA logs by type (ABSENT/ATTENDANCE/failed etc)
app.post('/api/data/delete-wlog-type', requireLogin, async (req, res) => {
  try {
    const { logType, from, to } = req.body;
    const { run, query } = require('./database');
    let whereClause, params;
    if (logType === 'failed') {
      whereClause = "status IN ('failed','not_on_wa','dead_number')";
      params = from && to ? [from, to] : [];
      if (from && to) whereClause += ' AND date(timestamp) BETWEEN ? AND ?';
    } else {
      whereClause = 'type = ?';
      params = [logType];
      if (from && to) { whereClause += ' AND date(timestamp) BETWEEN ? AND ?'; params.push(from, to); }
    }
    const [beforeRow] = await query(`SELECT COUNT(*) as cnt FROM whatsapp_log WHERE ${whereClause}`, params);
    await run(`DELETE FROM whatsapp_log WHERE ${whereClause}`, params);
    res.json({ success: true, deleted: beforeRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete duplicate attendance (keep first record per student per day)
app.post('/api/data/delete-duplicates', requireLogin, async (req, res) => {
  try {
    const { run, query } = require('./database');
    const [beforeRow] = await query('SELECT COUNT(*) as cnt FROM attendance');
    await run(`DELETE FROM attendance WHERE rowid NOT IN (
      SELECT MIN(rowid) FROM attendance GROUP BY student_uid, date(timestamp), type
    )`);
    const [afterRow] = await query('SELECT COUNT(*) as cnt FROM attendance');
    res.json({ success: true, deleted: beforeRow.cnt - afterRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete orphan records (attendance/wlog for deleted students)
app.post('/api/data/delete-orphans', requireLogin, async (req, res) => {
  try {
    const { run, query } = require('./database');
    const [attRow]  = await query('SELECT COUNT(*) as cnt FROM attendance WHERE student_uid NOT IN (SELECT student_uid FROM students)');
    const [wlogRow] = await query('SELECT COUNT(*) as cnt FROM whatsapp_log WHERE student_uid IS NOT NULL AND student_uid NOT IN (SELECT student_uid FROM students)');
    await run('DELETE FROM attendance WHERE student_uid NOT IN (SELECT student_uid FROM students)');
    await run('DELETE FROM whatsapp_log WHERE student_uid IS NOT NULL AND student_uid NOT IN (SELECT student_uid FROM students)');
    res.json({ success: true, attendance: attRow.cnt, wlogs: wlogRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete all data for a specific year
app.post('/api/data/delete-year', requireLogin, async (req, res) => {
  try {
    const { year } = req.body;
    if (!year || isNaN(year)) return res.json({ success: false, error: 'Invalid year' });
    const { run, query } = require('./database');
    const [attRow]  = await query("SELECT COUNT(*) as cnt FROM attendance WHERE strftime('%Y', timestamp) = ?", [String(year)]);
    const [wlogRow] = await query("SELECT COUNT(*) as cnt FROM whatsapp_log WHERE strftime('%Y', timestamp) = ?", [String(year)]);
    await run("DELETE FROM attendance WHERE strftime('%Y', timestamp) = ?", [String(year)]);
    await run("DELETE FROM whatsapp_log WHERE strftime('%Y', timestamp) = ?", [String(year)]);
    res.json({ success: true, attendance: attRow.cnt, wlogs: wlogRow.cnt });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Delete frozen/defaulter students data
app.post('/api/data/delete-frozen', requireLogin, async (req, res) => {
  try {
    const { what } = req.body; // 'attendance' | 'wlog' | 'all'
    const { run, query } = require('./database');
    const frozenRows = await query('SELECT student_uid FROM students WHERE is_frozen = 1');
    const uids = frozenRows.map(r => r.student_uid);
    if (!uids.length) return res.json({ success: true, deleted: 0 });
    const ph = uids.map(() => '?').join(',');
    if (what === 'attendance' || what === 'all') await run(`DELETE FROM attendance WHERE student_uid IN (${ph})`, uids);
    if (what === 'wlog'       || what === 'all') await run(`DELETE FROM whatsapp_log WHERE student_uid IN (${ph})`, uids);
    res.json({ success: true, deleted: uids.length });
  } catch (e) { res.json({ success: false, error: e.message }); }
});

// Dismiss selected failed/expired messages (remove from queue, mark dismissed)
app.post('/api/whatsapp/dismiss', async (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids || !ids.length) return res.status(400).json({ success: false, error: 'No IDs provided' });
    const { run } = require('./database');
    for (const id of ids) {
      await run(`UPDATE whatsapp_log SET status='dismissed', retry_until=NULL WHERE id=?`, [id]);
    }
    res.json({ success: true, dismissed: ids.length });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Queue selected failed messages for auto-retry (12 hrs)
app.post('/api/whatsapp/queue', async (req, res) => {
  try {
    const { ids } = req.body;
    if (!ids || !ids.length) return res.status(400).json({ success: false, error: 'No IDs provided' });
    const { run } = require('./database');
    const RETRY_HOURS = 12;
    const retryUntil = new Date(Date.now() + RETRY_HOURS * 60 * 60 * 1000)
      .toISOString().replace('T', ' ').split('.')[0];
    for (const id of ids) {
      await run(`UPDATE whatsapp_log SET retry_until=? WHERE id=? AND status='failed'`, [retryUntil, id]);
    }
    res.json({ success: true, queued: ids.length, retry_until: retryUntil });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// WhatsApp status
app.get('/api/whatsapp/status', async (req, res) => {
  if (!getStatus().isReady) await require('./whatsapp').refreshConnection();
  const s = getStatus();
  res.json({ success: true, isReady: s.isReady, status: s.status, hasQR: !!s.qrImageBase64, provider:s.provider, browserVisible:s.browserVisible });
});
app.post('/api/whatsapp/reconnect', async (req, res) => {
  try {
    await require('./whatsapp').reconnectWhatsApp();
    const s = getStatus();
    res.json({ success:true, isReady:s.isReady, status:s.status, hasQR:!!s.qrImageBase64 });
  } catch (e) { res.status(500).json({success:false,error:e.message}); }
});

// WhatsApp QR image - returns base64 PNG
app.get('/api/whatsapp/qr', async (req, res) => {
  const s = getStatus();
  if (!s.qrImageBase64) return res.json({ success: false, qr: null });
  res.json({ success: true, qr: s.qrImageBase64 });
});

// WhatsApp log API — supports single date (?date=) or range (?date=&dateTo=)
app.get('/api/whatsapp/log', async (req, res) => {
  try {
    const { query } = require('./database');
    const dateFrom  = req.query.date || todayPKT();
    const dateTo    = req.query.dateTo || dateFrom;
    const logType   = req.query.log_type || '';   // 'ATTENDANCE', 'MONTHLY_REPORT', or '' for all
    // whatsapp_log.timestamp is stored as UTC (SQLite CURRENT_TIMESTAMP default).
    // To match PKT dates correctly, convert the filter range to UTC by subtracting 5h:
    //   PKT 00:00 = UTC 19:00 previous day  →  from: dateFrom-1 19:00
    //   PKT 23:59 = UTC 18:59 same day      →  to:   dateTo 18:59
    const utcFrom = `${dateFrom} 00:00:00`;
    const utcTo   = `${dateTo} 23:59:59`;
    let sql = `SELECT * FROM whatsapp_log WHERE (COALESCE(msg_id,'') NOT LIKE 'sms:%' OR msg_id='sms:rejected') AND datetime(timestamp, '+5 hours') >= ? AND datetime(timestamp, '+5 hours') <= ?`;
    const params = [utcFrom, utcTo];
    if (logType) { sql += ` AND COALESCE(log_type,'ATTENDANCE') = ?`; params.push(logType); }
    sql += ` ORDER BY timestamp DESC`;
    const logs = await query(sql, params);
    {
      await require('./sms').init();
      const smsRows = await query(
        `SELECT q.*, (SELECT COALESCE(w.log_type,'ATTENDANCE') FROM whatsapp_log w WHERE w.msg_id='sms:' || q.id ORDER BY w.id DESC LIMIT 1) AS source_log_type FROM sms_queue q WHERE datetime(created_at, '+5 hours') >= ? AND datetime(created_at, '+5 hours') <= ? ORDER BY created_at DESC`,
        [utcFrom, utcTo]
      );
      smsRows.filter(row => !logType || require('./sms-log').category(row) === logType).forEach(row => logs.push({
        id: 'sms:' + row.id,
        source_id: row.id,
        channel: 'SMS',
        log_type: require('./sms-log').category(row),
        timestamp: String(row.created_at || '').replace('T',' ').replace(/\.\d{3}Z$/,''),
        student_name: row.student_name || '—',
        student_class: row.student_class || '',
        phone: row.phone || '',
        type: row.type || '',
        message: row.message || '',
        status: row.status || 'pending',
        fail_reason: row.error || null,
        retry_until: null,
        retry_count: Number(row.retry_count || 0),
        parts: row.parts || 1
      }));
      logs.sort((a,b) => String(b.timestamp || '').localeCompare(String(a.timestamp || '')));
    }
    logs.forEach(row => { if (!row.channel) row.channel = String(row.msg_id || '').startsWith('sms:') ? 'SMS' : 'WhatsApp'; });
    res.json({ success: true, logs });
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});



// Pages
// ── ID Card print tracking ────────────────────────────────────────────────────
// POST /api/students/mark-printed  body: { uids: ['uid1','uid2',...] }
app.post('/api/students/mark-printed', requireLogin, async (req, res) => {
  try {
    const { uids } = req.body;
    if (!uids || !uids.length) return res.status(400).json({ success: false, error: 'No UIDs provided' });
    const { run } = require('./database');
    const now = new Date().toISOString();
    for (const uid of uids) {
      await run('UPDATE students SET card_printed = 1, card_printed_at = ? WHERE student_uid = ?', [now, uid]);
    }
    res.json({ success: true, marked: uids.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/students/unmark-printed  body: { uids: ['uid1',...] }
app.post('/api/students/unmark-printed', requireLogin, async (req, res) => {
  try {
    const { uids } = req.body;
    if (!uids || !uids.length) return res.status(400).json({ success: false, error: 'No UIDs provided' });
    const { run } = require('./database');
    for (const uid of uids) {
      await run('UPDATE students SET card_printed = 0, card_printed_at = NULL WHERE student_uid = ?', [uid]);
    }
    res.json({ success: true, unmarked: uids.length });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/students/mark-issued  body: { uids: ['uid1','uid2',...] }
app.post('/api/students/mark-issued', requireLogin, async (req, res) => {
  try {
    const { uids, issued_date } = req.body;
    if (!Array.isArray(uids) || !uids.length) return res.status(400).json({ success:false, error:'No UIDs provided' });
    if (issued_date && !/^\d{4}-\d{2}-\d{2}$/.test(String(issued_date))) {
      return res.status(400).json({ success:false, error:'Invalid issue date' });
    }
    const { run } = require('./database');
    const issuedAt = issued_date || todayPKT();
    for (const uid of uids) {
      await run('UPDATE students SET card_issued = 1, card_issued_at = ? WHERE student_uid = ?', [issuedAt, uid]);
    }
    res.json({ success:true, marked:uids.length, issued_date:issuedAt });
  } catch (err) {
    res.status(500).json({ success:false, error:err.message });
  }
});

// POST /api/students/unmark-issued  body: { uids: ['uid1','uid2',...] }
app.post('/api/students/unmark-issued', requireLogin, async (req, res) => {
  try {
    const { uids } = req.body;
    if (!Array.isArray(uids) || !uids.length) return res.status(400).json({ success:false, error:'No UIDs provided' });
    const { run } = require('./database');
    for (const uid of uids) {
      await run('UPDATE students SET card_issued = 0, card_issued_at = NULL WHERE student_uid = ?', [uid]);
    }
    res.json({ success:true, unmarked:uids.length });
  } catch (err) {
    res.status(500).json({ success:false, error:err.message });
  }
});

app.get('/', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/index.html')));
app.get('/dashboard', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/dashboard.html')));
app.get('/students', async (req, res) => res.redirect('/enroll-student'));
app.get('/enroll-student', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/enroll-student.html')));
app.get('/student-info', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/student-info.html')));
app.get('/settings', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/settings.html')));
app.get('/absent-notify', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/absent-notify.html')));
app.get('/attendance-entries', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/attendance-entries.html')));
app.get('/attendance-report', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/attendance-report.html')));
app.get('/idcard', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/idcard.html')));
app.get('/whatsapp-log', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/whatsapp-log.html')));
app.get('/notes', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/notes.html')));
app.get('/reports', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/reports.html')));
app.get('/flagged', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/flagged.html')));
app.get('/daily-summary', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/daily-summary.html')));
app.get('/report-template', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/report-template.html')));
app.get('/exam-pg1', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg1.html')));
app.get('/exam-pg2', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg2.html')));
app.get('/exam-marks-entry', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg3.html')));
app.get('/exam-pg3', async (req, res) => {
  if (req.query.award_list_id) {
    return res.redirect(`/exam-pg2?award_list_id=${encodeURIComponent(req.query.award_list_id)}#tab-marks-entry`);
  }
  res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg3-placeholder.html'));
});
app.get('/exam-pg4', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg4.html')));
app.get('/exam-pg5', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg5.html')));
app.get('/exam-pg6', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg6.html')));
app.get('/exam-pg7', async (req, res) => res.sendFile(path.join(__dirname, '../frontend/pages/exam-pg7.html')));

const PORT = 3000;

async function start() {
  // ── Database must come up before anything else. If this throws (e.g. no
  // internet on a brand-new machine's first-ever launch), we still want to
  // print a clear message and exit cleanly rather than an opaque crash —
  // database.js's initDb() itself now falls back to local-only mode on a
  // failed first connection, so this catch is a last-resort safety net,
  // not the primary fix. ──
  try {
    const { initDb, registerShutdownHandlers } = require('./database');
    await initDb();
    // Must be registered only after initDb() succeeds — before that, the
    // lock/db state isn't set up yet and there's nothing to clean up.
    registerShutdownHandlers();
  } catch (err) {
    console.error('\n❌ Could not start: database failed to initialize.');
    console.error('   Reason:', err.message || err);
    console.error('   If this is the very first time running on this PC, an internet');
    console.error('   connection is needed once to set up the local database.');
    console.error('   Please connect to the internet and try again.\n');
    process.exit(1);
  }

  // ── Everything below is "nice to have" at startup — WhatsApp, the absent-
  // notification scheduler, and Google Sheets sync all depend on external
  // services that may be unavailable. None of them should be able to stop
  // the kiosk/dashboard from coming up, since attendance scanning itself
  // only needs the local database, not these. ──
  try {
    if (require('./sender-role').enabled()) { require('./sms').start(); initWhatsApp(); }
  } catch (err) {
    console.error('⚠️  WhatsApp did not start:', err.message || err);
    console.error('⚠️  Attendance scanning will still work — WhatsApp messages will queue and retry once it reconnects.');
  }

  try {
    if (require('./sender-role').enabled()) startRetryLoop();
  } catch (err) {
    console.error('⚠️  WhatsApp retry loop did not start:', err.message || err);
  }

  // ── Absent notifications scheduler ──
  try {
    const { startAbsentScheduler } = require('./absent-scheduler');
    if (require('./sender-role').enabled()) startAbsentScheduler();
  } catch (err) {
    console.error('⚠️  Absent-notification scheduler did not start:', err.message || err);
  }

  try {
    const { startCopyReminderScheduler } = require('./copy-reminder-scheduler');
    if (require('./sender-role').enabled()) startCopyReminderScheduler();
  } catch (err) {
    console.error('⚠️  Award-list copy reminder scheduler did not start:', err.message || err);
  }

  // ── Google Sheets daily sync ──
  try {
    const { startSheetsScheduler } = require('./sheets-sync');
    const { query: dbQuery, todayPKT } = require('./database');
    startSheetsScheduler(dbQuery, todayPKT);
  } catch (err) {
    console.error('⚠️  Google Sheets sync did not start:', err.message || err);
  }

  server.listen(PORT, () => {
    console.log('\n🚀 VCC Attendance System running at http://localhost:' + PORT);
    console.log('🔐 Login — Username: ' + (process.env.ADMIN_USERNAME || 'admin'));
    console.log('📱 Open browser: http://localhost:3000');
    console.log('🖥  Kiosk IP lock: ' + (KIOSK_IP ? KIOSK_IP : 'NOT SET (open to all — add KIOSK_IP to .env)') + '\n');
  });
}

// Google Sheets manual sync endpoint
app.post('/api/sheets/sync', requireLogin, async (req, res) => {
  const spreadsheetId       = process.env.GOOGLE_SPREADSHEET_ID;
  const serviceAccountPath  = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;
  if (!spreadsheetId || !serviceAccountPath) {
    return res.status(400).json({ success: false, error: 'Google Sheets not configured.' });
  }
  try {
    const { syncToSheets }    = require('./sheets-sync');
    const { query, todayPKT } = require('./database');
    const result = await syncToSheets({ query, todayPKT, spreadsheetId, serviceAccountPath });
    res.json(result);
  } catch(err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

start();
