const { query, run, batchRun, todayPKT } = require('./database');
const { randomUUID } = require('crypto');
const owner = require('os').hostname();
let ready, busy = false;
const LIMITS = Object.freeze({ quarterHour:100, hour:200, day:700 });
function init() {
  if (!ready) ready = run(`CREATE TABLE IF NOT EXISTS sms_queue (
    id TEXT PRIMARY KEY, owner TEXT NOT NULL, student_name TEXT, student_class TEXT, phone TEXT,
    message TEXT, type TEXT, parts INTEGER, status TEXT DEFAULT 'pending',
    gateway_id TEXT, error TEXT, budget_day TEXT, created_at TEXT, updated_at TEXT
  )`).then(() => run('ALTER TABLE sms_queue ADD COLUMN student_class TEXT').catch(() => {}))
    .then(() => run('ALTER TABLE sms_queue ADD COLUMN retry_count INTEGER DEFAULT 0').catch(() => {}))
    .then(() => run('ALTER TABLE sms_queue ADD COLUMN next_attempt TEXT').catch(() => {}))
    .then(() => run('ALTER TABLE sms_queue ADD COLUMN award_entry_id INTEGER').catch(() => {}))
    .then(() => run('ALTER TABLE sms_queue ADD COLUMN polled_at TEXT').catch(() => {}))
    .then(() => run('ALTER TABLE sms_queue ADD COLUMN rate_held INTEGER DEFAULT 0').catch(() => {}))
    .then(() => run(`CREATE TABLE IF NOT EXISTS sms_attempts (
      id TEXT PRIMARY KEY, queue_id TEXT NOT NULL, parts INTEGER NOT NULL CHECK(parts>0),
      reserved_at TEXT NOT NULL, budget_day TEXT NOT NULL
    )`))
    .then(() => run('CREATE INDEX IF NOT EXISTS idx_sms_attempts_time ON sms_attempts(reserved_at)'))
    .then(() => run('CREATE INDEX IF NOT EXISTS idx_sms_attempts_day ON sms_attempts(budget_day)'))
    // Preserve known usage when upgrading; never reset today's allowance on restart.
    .then(() => run(`INSERT OR IGNORE INTO sms_attempts(id,queue_id,parts,reserved_at,budget_day)
      SELECT 'legacy:' || id,id,MAX(1,COALESCE(parts,1))*(1+COALESCE(retry_count,0)),
      COALESCE(updated_at,created_at),budget_day FROM sms_queue
      WHERE budget_day IS NOT NULL AND NOT EXISTS(SELECT 1 FROM sms_attempts a WHERE a.queue_id=sms_queue.id)`))
    .catch(e => { ready = null; throw e; });
  return ready;
}
async function settings() {
  return Object.fromEntries((await query('SELECT key,value FROM settings')).map(x => [x.key,x.value]));
}
function parts(text) {
  const basic = '@£$¥èéùìòÇ\nØø\rÅåΔ_ΦΓΛΩΠΨΣΘΞÆæßÉ !"#¤%&\'()*+,-./0123456789:;<=>?¡ABCDEFGHIJKLMNOPQRSTUVWXYZÄÖÑÜ§¿abcdefghijklmnopqrstuvwxyzäöñüà';
  const ext = '^{}\\[~]|€';
  let units = 0;
  for (const c of text) { if (basic.includes(c)) units++; else if (ext.includes(c)) units += 2; else return text.length <= 70 ? 1 : Math.ceil(text.length / 67); }
  return units <= 160 ? 1 : Math.ceil(units / 153);
}
function phoneNumber(value) {
  let n = String(value || '').replace(/\D/g, '');
  if (n.startsWith('00')) n = n.slice(2);
  if (/^03\d{9}$/.test(n)) n = '92' + n.slice(1);
  if (!/^923\d{9}$/.test(n)) throw new Error('A valid Pakistani mobile number is required');
  return '+' + n;
}
function validate(s) {
  const u = new URL(String(s.sms_gateway_url || '').trim());
  if (!['http:', 'https:'].includes(u.protocol) || u.username || u.password || u.search || u.hash) throw new Error('Enter a valid phone gateway URL');
  if (!String(s.sms_gateway_user || '').trim() || !String(s.sms_gateway_password || '').trim()) throw new Error('Phone gateway username and password are required');
  return u.origin;
}
async function request(s, path, body) {
  const user = String(s.sms_gateway_user || '').trim();
  const password = String(s.sms_gateway_password || '').trim();
  const res = await fetch(validate(s) + path, {
    method: body ? 'POST' : 'GET', redirect: 'error', signal: AbortSignal.timeout(10000),
    headers: { Authorization: 'Basic ' + Buffer.from(user + ':' + password).toString('base64'), 'Content-Type': 'application/json' },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  // A local phone can report unhealthy solely because internet is offline.
  // Its authenticated SMS service is still usable over the LAN.
  if (!res.ok && !(path === '/health' && res.status === 503)) {
    const error = new Error('Phone gateway HTTP ' + res.status);
    error.status = res.status;
    throw error;
  }
  return res.json();
}
async function checkCredentials(s) {
  const user = String(s.sms_gateway_user || '').trim();
  const password = String(s.sms_gateway_password || '').trim();
  const res = await fetch(validate(s) + '/messages/vcc-auth-check', {
    method: 'GET', redirect: 'error', signal: AbortSignal.timeout(10000),
    headers: { Authorization: 'Basic ' + Buffer.from(user + ':' + password).toString('base64') }
  });
  if (res.status === 401 || res.status === 403) throw new Error('Username or password rejected by phone');
  // A missing fake message (404) proves that authentication passed.
  if (res.ok || res.status === 404) return true;
  throw new Error('Phone gateway HTTP ' + res.status);
}
async function enqueue(student, message, type) {
  require('./sender-role').assertSender();
  await init();
  const phone = phoneNumber(student.parent_phone);
  if (!message.trim()) throw new Error('SMS template is empty');
  const id = randomUUID(), stamp = new Date().toISOString();
  const studentClass = [student.class,student.section].filter(Boolean).join('-');
  await run(`INSERT INTO sms_queue (id,owner,student_name,student_class,phone,message,type,parts,created_at,updated_at,award_entry_id) VALUES (?,?,?,?,?,?,?,?,?,?,?)`, [id,owner,student.name,studentClass,phone,message,type,parts(message),stamp,stamp,student.award_entry_id || null]);
  return id;
}
async function reserveAttempt(row, now = new Date()) {
  const stamp=now.toISOString(), day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Karachi',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const units=Math.max(parts(String(row.message || '')),Number(row.parts)||1);
  const id=randomUUID(), quarter=new Date(now.getTime()-15*60000).toISOString(), hour=new Date(now.getTime()-60*60000).toISOString();
  // Atomic reservation + queue claim: simultaneous ticks cannot spend the same slot.
  await batchRun([
    {sql:`INSERT INTO sms_attempts(id,queue_id,parts,reserved_at,budget_day)
      SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM sms_queue WHERE id=? AND status='pending')
      AND COALESCE((SELECT SUM(parts) FROM sms_attempts WHERE julianday(reserved_at)>=julianday(?)),0)+?<=?
      AND COALESCE((SELECT SUM(parts) FROM sms_attempts WHERE julianday(reserved_at)>=julianday(?)),0)+?<=?
      AND COALESCE((SELECT SUM(parts) FROM sms_attempts WHERE budget_day=?),0)+?<=?`,
      args:[id,row.id,units,stamp,day,row.id,quarter,units,LIMITS.quarterHour,hour,units,LIMITS.hour,day,units,LIMITS.day]},
    {sql:`UPDATE sms_queue SET status='sending',budget_day=?,updated_at=?,rate_held=0,error=NULL
      WHERE id=? AND status='pending' AND EXISTS(SELECT 1 FROM sms_attempts WHERE id=?)`,args:[day,stamp,row.id,id]}
  ]);
  return (await query('SELECT id FROM sms_attempts WHERE id=?',[id])).length>0;
}
async function usage(now = new Date()) {
  const day=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Karachi',year:'numeric',month:'2-digit',day:'2-digit'}).format(now);
  const [row]=await query(`SELECT
    COALESCE(SUM(CASE WHEN julianday(reserved_at)>=julianday(?) THEN parts ELSE 0 END),0) AS quarterHour,
    COALESCE(SUM(CASE WHEN julianday(reserved_at)>=julianday(?) THEN parts ELSE 0 END),0) AS hour,
    COALESCE(SUM(CASE WHEN budget_day=? THEN parts ELSE 0 END),0) AS day FROM sms_attempts`,
    [new Date(now.getTime()-15*60000).toISOString(),new Date(now.getTime()-3600000).toISOString(),day]);
  return {quarterHour:Number(row.quarterHour),hour:Number(row.hour),day:Number(row.day)};
}
async function tick() {
  if (!require('./sender-role').enabled()) return;
  if (busy) return;
  busy = true;
  try {
    await init();
    const s = await settings();
    // Mirrored records retain SMS identity and must never enter WhatsApp retries.
    await run(`UPDATE whatsapp_log SET retry_until=NULL,
      status=COALESCE((SELECT CASE WHEN q.status IN ('delivered','sent') THEN 'sent' WHEN q.status IN ('failed','expired','review') THEN 'failed' ELSE 'queued' END FROM sms_queue q WHERE 'sms:' || q.id=whatsapp_log.msg_id), 'failed')
      WHERE msg_id LIKE 'sms:%'`);
    if (!s.sms_gateway_url) return;
    validate(s);
    // Never resubmit an uncertain send: the phone may already have accepted it.
    const active = await query("SELECT * FROM sms_queue WHERE owner=? AND status IN ('sending','submitted','sent') ORDER BY COALESCE(polled_at,''), created_at, id LIMIT 20", [owner]);
    for (const row of active) {
      // Rotate even unavailable/error responses, so older jobs cannot starve newer ones.
      await run('UPDATE sms_queue SET polled_at=? WHERE id=?',[new Date().toISOString(),row.id]);
      if (!row.gateway_id) {
        await run("UPDATE sms_queue SET status='review',error='Send interrupted; check phone history before resending' WHERE id=?", [row.id]);
        continue;
      }
      let result;
      try { result = await request(s, '/messages/' + encodeURIComponent(row.gateway_id)); }
      catch (e) { continue; }
      const state = String(result.state || '').toLowerCase();
      const status = ({sent:'sent', delivered:'delivered', failed:'failed', cancelled:'failed'})[state] || 'submitted';
      await run('UPDATE sms_queue SET status=?,error=?,updated_at=? WHERE id=?', [status,result.reason || null,new Date().toISOString(),row.id]);
      if ((status === 'sent' || status === 'delivered') && row.award_entry_id) {
        await recordMarksSent(row.award_entry_id);
      }
      if (status === 'failed' && Number(row.retry_count || 0) < 3) {
        await run("UPDATE sms_queue SET status='pending',gateway_id=NULL,retry_count=COALESCE(retry_count,0)+1,next_attempt=?,error=? WHERE id=?",[new Date(Date.now()+120000).toISOString(),'Confirmed SMS failure; retry scheduled on SIM SMS',row.id]);
      }
    }
    const rows = await query("SELECT * FROM sms_queue WHERE owner=? AND status='pending' AND (next_attempt IS NULL OR next_attempt<=?) ORDER BY created_at LIMIT 1", [owner,new Date().toISOString()]);
    if (!rows.length) return;
    const row = rows[0], day = todayPKT();
    // Old arrival alerts should not unexpectedly reach parents on a later day.
    if (!row.rate_held && new Date(row.created_at).toLocaleDateString('en-CA',{timeZone:'Asia/Karachi'}) !== day) {
      await run("UPDATE sms_queue SET status='expired',error='Previous-day alert expired' WHERE id=?", [row.id]); return;
    }
    // Check connectivity before claiming the send, so offline messages remain pending.
    await request(s, '/health');
    if (!(await reserveAttempt(row))) {
      await run("UPDATE sms_queue SET rate_held=1,error='SMS safety limit reached; waiting in queue',updated_at=? WHERE owner=? AND status='pending'",[new Date().toISOString(),owner]);
      return;
    }
    try {
      const result = await request(s, '/message', { textMessage: { text: row.message }, phoneNumbers: [row.phone], withDeliveryReport: true });
      if (!result.id) throw new Error('Phone accepted request without a tracking ID');
      await run("UPDATE sms_queue SET status='submitted',gateway_id=?,error=NULL WHERE id=?", [result.id,row.id]);
    } catch (e) {
      if (e.status === 401 || e.status === 403) {
        await run("UPDATE sms_queue SET status='failed',error=? WHERE id=?", ['Phone rejected username/password; SMS was not sent',row.id]);
      } else {
        await run("UPDATE sms_queue SET status='review',error=? WHERE id=?", ['Send outcome uncertain; check phone history. ' + e.message,row.id]);
      }
    }
  } catch (e) { /* Connection failures leave queued messages pending. */ }
  finally { busy = false; }
}
function start() { init().catch(e => console.warn('[SMS]', e.message)); const timer = setInterval(tick, 15000); timer.unref(); }
async function recordMarksSent(entryId) {
  await run('UPDATE award_list_entries SET sent=1, sent_at=COALESCE(sent_at,CURRENT_TIMESTAMP) WHERE id=?',[entryId]);
  const entries=await query('SELECT award_list_id FROM award_list_entries WHERE id=?',[entryId]);
  if (!entries.length) return;
  const listId=entries[0].award_list_id;
  await run(`UPDATE award_lists SET marks_sent_at=COALESCE(marks_sent_at,?), marks_sent_method=COALESCE(marks_sent_method,'system')
    WHERE id=? AND NOT EXISTS (SELECT 1 FROM award_list_entries WHERE award_list_id=? AND COALESCE(sent,0)!=1)`,
    [new Date(Date.now()+5*3600000).toISOString().replace('T',' ').slice(0,19),listId,listId]);
}
async function overview() {
  await init();
  const counts = await usage();
  const rows = await query('SELECT id,student_name,phone,type,parts,status,error,created_at,gateway_id FROM sms_queue ORDER BY created_at DESC LIMIT 50');
  rows.forEach(row => { row.retryable = row.status === 'failed' || (!row.gateway_id && /HTTP 40[13]|rejected username|rejected by phone/i.test(row.error || '')); });
  return { used: counts.day, usage:counts, limits:LIMITS, rows };
}
async function retryRejected(id) {
  await init();
  const rows = await query('SELECT * FROM sms_queue WHERE id=? AND owner=?', [id,owner]);
  if (!rows.length) throw new Error('SMS record not found on this server');
  const row = rows[0];
  const rowDay = new Date(row.created_at).toLocaleDateString('en-CA',{timeZone:'Asia/Karachi'});
  if (rowDay !== todayPKT()) throw new Error('Previous-day attendance alerts cannot be retried');
  if (row.status !== 'failed' && (row.gateway_id || !/HTTP 40[13]|rejected username|rejected by phone/i.test(row.error || ''))) throw new Error('Only confirmed failed SMS can be retried. Check phone history for uncertain sends.');
  await run("UPDATE sms_queue SET status='pending',gateway_id=NULL,error=NULL,budget_day=NULL,next_attempt=NULL,retry_count=0,updated_at=? WHERE id=?", [new Date().toISOString(),id]);
}
module.exports = { init, start, enqueue, overview, retryRejected, settings, validate, request, checkCredentials, parts, phoneNumber, tick, reserveAttempt, usage, LIMITS };
