/**
 * VCC Google Sheets Daily Sync
 * ────────────────────────────
 * Syncs attendance to Google Sheets at end of day (configurable time, default 11:00 PM PKT).
 * 
 * Sheet structure (matches your sample):
 *   - One sheet tab per class (e.g. "IX-A", "X-B")
 *   - Columns: S NO | Gr No | Student Name | Father's Name | Roll No# | Date of Admission |
 *              [date columns: "1st June\nMonday", "2nd June\nTuesday", ...] | TOTAL PRESENT | TOTAL ABSENT
 *   - Students appear from their admission_date onward (blank before)
 *   - Each day column shows P / A / ------ (Sunday/holiday = dashes)
 *
 * Setup:
 *   1. Go to https://console.cloud.google.com → New Project
 *   2. Enable "Google Sheets API"
 *   3. Create "Service Account" credentials → download JSON key
 *   4. Set env vars:
 *        GOOGLE_SERVICE_ACCOUNT_JSON = full path to the downloaded JSON key file
 *        GOOGLE_SPREADSHEET_ID       = the ID from your sheet URL
 *        SHEETS_SYNC_TIME            = "23:00" (optional, default 11 PM PKT)
 *   5. Share your Google Sheet with the service account email (Editor access)
 */

const fs   = require('fs');
const path = require('path');
const https = require('https');

// ── JWT / OAuth2 for Google Sheets API (no external deps needed) ──────────────
function base64url(buf) {
  return buf.toString('base64').replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

async function getGoogleToken(serviceAccountPath) {
  const sa = JSON.parse(fs.readFileSync(serviceAccountPath, 'utf8'));
  const now = Math.floor(Date.now() / 1000);

  const header  = base64url(Buffer.from(JSON.stringify({ alg: 'RS256', typ: 'JWT' })));
  const payload = base64url(Buffer.from(JSON.stringify({
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets',
    aud: 'https://oauth2.googleapis.com/token',
    iat: now,
    exp: now + 3600,
  })));

  const sigInput  = `${header}.${payload}`;
  const crypto    = require('crypto');
  const sign      = crypto.createSign('RSA-SHA256');
  sign.update(sigInput);
  const signature = base64url(sign.sign(sa.private_key));
  const jwt       = `${sigInput}.${signature}`;

  return new Promise((resolve, reject) => {
    const body = `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`;
    const req  = https.request({
      hostname: 'oauth2.googleapis.com',
      path: '/token',
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'Content-Length': body.length }
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data).access_token); }
        catch(e) { reject(new Error('Token parse fail: ' + data)); }
      });
    });
    req.on('error', reject);
    req.write(body);
    req.end();
  });
}

// ── Google Sheets API helpers ─────────────────────────────────────────────────
function sheetsRequest(method, path, token, body = null) {
  return new Promise((resolve, reject) => {
    const bodyStr = body ? JSON.stringify(body) : null;
    const req = https.request({
      hostname: 'sheets.googleapis.com',
      path,
      method,
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json',
        ...(bodyStr ? { 'Content-Length': Buffer.byteLength(bodyStr) } : {})
      }
    }, res => {
      let data = '';
      res.on('data', d => data += d);
      res.on('end', () => {
        try { resolve(JSON.parse(data)); }
        catch(e) { reject(new Error('Response parse fail: ' + data)); }
      });
    });
    req.on('error', reject);
    if (bodyStr) req.write(bodyStr);
    req.end();
  });
}

async function getSheetsList(spreadsheetId, token) {
  const res = await sheetsRequest('GET', `/v4/spreadsheets/${spreadsheetId}?fields=sheets.properties`, token);
  return (res.sheets || []).map(s => ({ title: s.properties.title, sheetId: s.properties.sheetId }));
}

async function createSheet(spreadsheetId, title, token) {
  const res = await sheetsRequest('POST', `/v4/spreadsheets/${spreadsheetId}:batchUpdate`, token, {
    requests: [{ addSheet: { properties: { title } } }]
  });
  return res.replies?.[0]?.addSheet?.properties?.sheetId;
}

async function clearSheet(spreadsheetId, sheetTitle, token) {
  await sheetsRequest('POST', `/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!A1:ZZ1000:clear`, token, {});
}

async function writeValues(spreadsheetId, sheetTitle, range, values, token) {
  await sheetsRequest('PUT',
    `/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(sheetTitle)}!${range}?valueInputOption=RAW`,
    token,
    { range: `${sheetTitle}!${range}`, majorDimension: 'ROWS', values }
  );
}

async function applyFormatting(spreadsheetId, sheetId, requests, token) {
  if (!requests.length) return;
  await sheetsRequest('POST', `/v4/spreadsheets/${spreadsheetId}:batchUpdate`, token, { requests });
}

// ── Date helpers ──────────────────────────────────────────────────────────────
const DAYS   = ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday'];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];

function ordinal(n) {
  const s = ['th','st','nd','rd'];
  const v = n % 100;
  return n + (s[(v-20)%10] || s[v] || s[0]);
}

// Returns all dates in a given month as { dateStr: 'YYYY-MM-DD', label: '1st June\nMonday' }
function getDatesOfMonth(year, month) { // month: 1-indexed
  const days = [];
  const daysInMonth = new Date(year, month, 0).getDate();
  for (let d = 1; d <= daysInMonth; d++) {
    const date = new Date(year, month - 1, d);
    const dateStr = `${year}-${String(month).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
    days.push({
      dateStr,
      label: `${ordinal(d)} ${MONTHS[month-1]}\n${DAYS[date.getDay()]}`,
      dayOfWeek: date.getDay(), // 0=Sun
    });
  }
  return days;
}

// ── Core sync logic ───────────────────────────────────────────────────────────
async function syncToSheets({ query, todayPKT, spreadsheetId, serviceAccountPath }) {
  console.log('[Sheets] Starting sync...');

  const token = await getGoogleToken(serviceAccountPath);
  const today = todayPKT(); // YYYY-MM-DD
  const [year, month] = today.split('-').map(Number);

  // Month label for tab names e.g. "Jun-2026"
  const MONTH_SHORT = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  const monthLabel = `${MONTH_SHORT[month-1]}-${year}`;

  // Get all dates of current month
  const monthDates = getDatesOfMonth(year, month);
  const todayStr   = today;

  // Get all students grouped by class+section
  const allStudents = await query(
    `SELECT student_uid, name, father_name, gr_number, roll_no, admission_date,
            class, section
     FROM students
     WHERE status='active' OR status='' OR status IS NULL
     ORDER BY class, section, CAST(gr_number AS INTEGER), name`
  );

  // Declared holidays this month → dashes, same as Sundays
  const holidayRows = await query(
    `SELECT date FROM holidays WHERE date BETWEEN ? AND ?`,
    [`${year}-${String(month).padStart(2,'0')}-01`, `${year}-${String(month).padStart(2,'0')}-${String(new Date(year, month, 0).getDate()).padStart(2,'0')}`]
  );
  const holidaySet = new Set(holidayRows.map(h => h.date));

  // Get ALL attendance for this month in one query
  const monthStart = `${year}-${String(month).padStart(2,'0')}-01`;
  const monthEnd   = `${year}-${String(month).padStart(2,'0')}-${String(new Date(year, month, 0).getDate()).padStart(2,'0')}`;
  const attRows    = await query(
    `SELECT student_uid, date(timestamp) as day FROM attendance
     WHERE type='IN' AND date(timestamp) BETWEEN ? AND ?`,
    [monthStart, monthEnd]
  );

  // Build presence map: uid → Set of 'YYYY-MM-DD'
  const presenceMap = {};
  attRows.forEach(r => {
    if (!presenceMap[r.student_uid]) presenceMap[r.student_uid] = new Set();
    presenceMap[r.student_uid].add(r.day);
  });

  // Group students by tab name (class + section → "IX-A", "X", etc.)
  const classGroups = {};
  allStudents.forEach(s => {
    const tabName = s.section ? `${s.class}-${s.section} ${monthLabel}` : `${s.class} ${monthLabel}`;
    if (!classGroups[tabName]) classGroups[tabName] = [];
    classGroups[tabName].push(s);
  });

  const existingSheets = await getSheetsList(spreadsheetId, token);
  const existingMap    = {};
  existingSheets.forEach(s => { existingMap[s.title] = s.sheetId; });

  for (const [tabName, students] of Object.entries(classGroups)) {
    console.log(`[Sheets] Syncing tab: ${tabName} (${students.length} students)`);

    // Ensure sheet tab exists
    if (!existingMap[tabName]) {
      const newId = await createSheet(spreadsheetId, tabName, token);
      existingMap[tabName] = newId;
    }

    await clearSheet(spreadsheetId, tabName, token);

    // ── Build header rows ──
    // Row 1: Fixed cols + date labels + totals
    const fixedCols = ['S NO', 'Gr No', 'Student Name', "Father's Name", 'Roll No#', 'Date of Admission'];
    const dateCols  = monthDates.map(d => d.label);
    const totalCols = ['TOTAL PRESENT', 'TOTAL ABSENT'];

    const headerRow = [...fixedCols, ...dateCols, ...totalCols];

    // ── Build student rows ──
    const dataRows = [];
    students.forEach((s, idx) => {
      const admDate = s.admission_date || ''; // YYYY-MM-DD
      const row = [
        idx + 1,
        s.gr_number  || '',
        s.name       || '',
        s.father_name|| '',
        s.roll_no    || '',
        admDate,
      ];

      let totalPresent = 0;
      let totalAbsent  = 0;

      monthDates.forEach(d => {
        // Student didn't exist yet on this date
        if (admDate && d.dateStr < admDate) {
          row.push('');
          return;
        }

        // Future date (after today)
        if (d.dateStr > todayStr) {
          row.push('');
          return;
        }

        // Sunday or declared holiday → dashes
        if (d.dayOfWeek === 0 || holidaySet.has(d.dateStr)) {
          row.push('------');
          return;
        }

        const present = presenceMap[s.student_uid]?.has(d.dateStr);
        if (present) { row.push('P'); totalPresent++; }
        else         { row.push('A'); totalAbsent++; }
      });

      row.push(totalPresent);
      row.push(totalAbsent);
      dataRows.push(row);
    });

    const allRows = [headerRow, ...dataRows];
    await writeValues(spreadsheetId, tabName, 'A1', allRows, token);

    // ── Formatting ──
    const sheetId = existingMap[tabName];
    const numDataCols = headerRow.length;

    const formatRequests = [
      // Bold header row
      {
        repeatCell: {
          range: { sheetId, startRowIndex: 0, endRowIndex: 1, startColumnIndex: 0, endColumnIndex: numDataCols },
          cell: { userEnteredFormat: { textFormat: { bold: true }, horizontalAlignment: 'CENTER',
            backgroundColor: { red: 0.1, green: 0.1, blue: 0.1 } ,
            textFormat: { bold: true, foregroundColor: { red: 1, green: 0.84, blue: 0 } }
          }},
          fields: 'userEnteredFormat(textFormat,horizontalAlignment,backgroundColor)'
        }
      },
      // Center all data cells
      {
        repeatCell: {
          range: { sheetId, startRowIndex: 1, endRowIndex: dataRows.length + 1, startColumnIndex: 0, endColumnIndex: numDataCols },
          cell: { userEnteredFormat: { horizontalAlignment: 'CENTER' } },
          fields: 'userEnteredFormat.horizontalAlignment'
        }
      },
      // Freeze header row + first 2 cols
      {
        updateSheetProperties: {
          properties: { sheetId, gridProperties: { frozenRowCount: 1, frozenColumnCount: 2 } },
          fields: 'gridProperties.frozenRowCount,gridProperties.frozenColumnCount'
        }
      },
      // Auto-resize all columns
      {
        autoResizeDimensions: {
          dimensions: { sheetId, dimension: 'COLUMNS', startIndex: 0, endIndex: numDataCols }
        }
      }
    ];

    // Color P=green, A=red using two conditional format rules covering the entire
    // date column range — replaces the previous per-cell loop which generated up to
    // 15,000 individual format requests and routinely hit Google Sheets API quota.
    // Two rules per tab = 2 API calls regardless of student count or month length.
    const dateStartCol = fixedCols.length; // 6
    const dateEndCol   = dateStartCol + monthDates.length;
    const dataEndRow   = dataRows.length + 1;

    formatRequests.push(
      // Rule: cell = "P" → green background
      {
        addConditionalFormatRule: {
          rule: {
            ranges: [{ sheetId, startRowIndex: 1, endRowIndex: dataEndRow,
                       startColumnIndex: dateStartCol, endColumnIndex: dateEndCol }],
            booleanRule: {
              condition: { type: 'TEXT_EQ', values: [{ userEnteredValue: 'P' }] },
              format: {
                backgroundColor: { red: 0.56, green: 0.93, blue: 0.56 },
                textFormat: { bold: true, foregroundColor: { red: 0.07, green: 0.45, blue: 0.07 } }
              }
            }
          },
          index: 0
        }
      },
      // Rule: cell = "A" → red background
      {
        addConditionalFormatRule: {
          rule: {
            ranges: [{ sheetId, startRowIndex: 1, endRowIndex: dataEndRow,
                       startColumnIndex: dateStartCol, endColumnIndex: dateEndCol }],
            booleanRule: {
              condition: { type: 'TEXT_EQ', values: [{ userEnteredValue: 'A' }] },
              format: {
                backgroundColor: { red: 1, green: 0.8, blue: 0.8 },
                textFormat: { bold: true, foregroundColor: { red: 0.7, green: 0.07, blue: 0.07 } }
              }
            }
          },
          index: 1
        }
      }
    );

    // Single batch call for all structural + conditional format requests
    await applyFormatting(spreadsheetId, sheetId, formatRequests, token);

    console.log(`[Sheets] ✓ Tab "${tabName}" synced.`);
  }

  console.log('[Sheets] Sync complete.');
  return { success: true, tabs: Object.keys(classGroups).length, date: todayStr };
}

// ── Scheduler: fires once per day at configured PKT time ─────────────────────
function startSheetsScheduler(queryFn, todayPKT) {
  const spreadsheetId     = process.env.GOOGLE_SPREADSHEET_ID;
  const serviceAccountPath = process.env.GOOGLE_SERVICE_ACCOUNT_JSON;

  if (!spreadsheetId || !serviceAccountPath) {
    console.log('[Sheets] GOOGLE_SPREADSHEET_ID or GOOGLE_SERVICE_ACCOUNT_JSON not set. Sync disabled.');
    return;
  }

  if (!fs.existsSync(serviceAccountPath)) {
    console.log(`[Sheets] Service account file not found: ${serviceAccountPath}. Sync disabled.`);
    return;
  }

  const syncTimeStr = process.env.SHEETS_SYNC_TIME || '23:00'; // HH:MM PKT
  const [syncHour, syncMin] = syncTimeStr.split(':').map(Number);

  let lastSyncDate = null;

  function scheduleCheck() {
    // Run every minute to check if it's sync time
    const pktNow     = new Date(Date.now() + 5 * 60 * 60 * 1000);
    const hour       = pktNow.getUTCHours();
    const min        = pktNow.getUTCMinutes();
    const todayStr   = pktNow.toISOString().split('T')[0];

    if (hour === syncHour && min === syncMin && lastSyncDate !== todayStr) {
      lastSyncDate = todayStr;
      console.log(`[Sheets] Daily sync triggered at ${syncTimeStr} PKT`);
      syncToSheets({ query: queryFn, todayPKT, spreadsheetId, serviceAccountPath })
        .then(r => console.log('[Sheets] Done:', r))
        .catch(e => console.error('[Sheets] Sync error:', e.message));
    }
  }

  // Align to next minute boundary for reliable checks
  const msToNextMin = (60 - new Date().getSeconds()) * 1000;
  setTimeout(() => {
    scheduleCheck();
    setInterval(scheduleCheck, 60 * 1000);
  }, msToNextMin);
  console.log(`[Sheets] Scheduler active. Daily sync at ${syncTimeStr} PKT.`);
}

module.exports = { syncToSheets, startSheetsScheduler };