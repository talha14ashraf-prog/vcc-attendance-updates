const { AsyncLocalStorage } = require('async_hooks');
const context = new AsyncLocalStorage();
const { randomBytes } = require('crypto');
const db = require('./database');
function middleware(req, res, next) {
  const p = req.originalUrl || '';
  let category = /\/reports\//.test(p) ? 'pdf' : /send-test-plan-pdf|send-report/.test(p) ? 'pdf' : /send-test-plan/.test(p) ? 'test_plan' : /\/examination\//.test(p) ? 'marks' : /absent\/notify/.test(p) ? 'absent' : 'other';
  // Retries always use their original transport, regardless of current settings.
  const retry = /retry/.test(p);
  context.run({ category, channel: retry ? 'whatsapp' : req.body?.channel }, next);
}
async function channel(category, override) {
  const s = await require('./sms').settings();
  const selected = override || s['message_channel_' + category] || s.attendance_channel || 'whatsapp';
  if (!['sms', 'whatsapp'].includes(selected)) throw new Error('Invalid message channel');
  return selected;
}
async function send(student, message, dbArg, category, override) {
  require('./sender-role').assertSender();
  const ctx = context.getStore() || {};
  const selected = await channel(category || ctx.category || 'other', override || ctx.channel);
  if (selected === 'whatsapp') return require('./whatsapp').smartSendWhatsApp(student, message, dbArg);
  try {
    const id = await require('./sms').enqueue(student, message, category || ctx.category || 'other');
    return { sent:false, queued:true, channel:'sms', phone:student.parent_phone, msgId:'sms:' + id, usedFallback:false, reason:'Queued for SIM SMS' };
  } catch (error) {
    // A failed enqueue must never become a WhatsApp retry job.
    return { sent:false, channel:'sms', phone:student.parent_phone, msgId:'sms:rejected', reason:error.message, usedFallback:false };
  }
}
async function initFiles() {
  await db.run('CREATE TABLE IF NOT EXISTS sms_documents (token TEXT PRIMARY KEY, filename TEXT, content TEXT, expires_at TEXT)');
}
async function sendFile(student, buffer, filename, caption, dbArg) {
  require('./sender-role').assertSender();
  const ctx = context.getStore() || {};
  if (await channel('pdf', ctx.channel) === 'whatsapp') return require('./whatsapp').smartSendFileWhatsApp(student, buffer, filename, caption, dbArg);
  const s = await require('./sms').settings();
  const base = String(s.sms_public_url || '').replace(/\/$/, '');
  if (!/^https:\/\/[^\s]+$/.test(base)) return {sent:false,phone:student.parent_phone,msgId:'sms:rejected',reason:'Set a public HTTPS document URL in Channel Settings before sending PDFs by SMS.'};
  await initFiles();
  const token = randomBytes(24).toString('hex');
  await db.run('INSERT INTO sms_documents (token,filename,content,expires_at) VALUES (?,?,?,?)', [token,filename,buffer.toString('base64'),new Date(Date.now()+7*86400000).toISOString()]);
  return send(student, (caption ? caption+'\n' : 'VCC document: ') + base+'/sms-document/'+token, dbArg, 'pdf', 'sms');
}
async function documentRoute(req,res) {
  try {
    if (!/^[a-f0-9]{48}$/.test(req.params.token)) return res.sendStatus(404);
    await initFiles();
    const rows = await db.query('SELECT * FROM sms_documents WHERE token=? AND expires_at>?',[req.params.token,new Date().toISOString()]);
    if (!rows.length) return res.status(404).send('Document unavailable or expired.');
    res.type('application/pdf').set('Cache-Control','no-store').set('Content-Disposition','inline; filename="document.pdf"').send(Buffer.from(rows[0].content,'base64'));
  } catch (_) { res.sendStatus(503); }
}
module.exports = { middleware, send, sendFile, channel, documentRoute };
