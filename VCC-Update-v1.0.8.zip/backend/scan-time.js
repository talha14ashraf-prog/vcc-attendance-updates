// Receipts are checked before validating a retry's original tap time.
function resolve(value,now=Date.now()) {
  const ms=value===undefined?now:value;
  if(typeof ms!=='number'||!Number.isFinite(ms)||ms>now+30000||ms<now-86400000)throw Error('Tap time is invalid. Check the scanner PC clock; this tap needs administration review.');
  const pkt=new Date(ms+5*3600000).toISOString();
  if(pkt.slice(0,10)!==new Date(now+5*3600000).toISOString().slice(0,10))throw Error('Earlier-day tap needs administration review.');
  return{date:new Date(ms),day:pkt.slice(0,10),timestamp:pkt.replace('T',' ').slice(0,19)};
}
module.exports={resolve};
