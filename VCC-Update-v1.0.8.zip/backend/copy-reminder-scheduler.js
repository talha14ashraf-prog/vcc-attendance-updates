/**
 * Award-list copy reminder scheduler
 *
 * Starting six calendar days after copies are handed to a teacher, sends one
 * numbered WhatsApp reminder per day while either marks are incomplete or the
 * physical copies have not been returned. Seven reminders make the award list
 * critical in the admin UI; reminders continue daily until both jobs are done.
 */

const { query, run } = require('./database');
const { smartSend } = require('./whatsapp');

function pktNow() {
  return new Date(Date.now() + 5 * 60 * 60 * 1000);
}

function normalize(value) {
  return String(value || '').trim().toLowerCase();
}

async function loadTeacherMap() {
  const rows = await query("SELECT value FROM settings WHERE key = 'teacher_subject_map'");
  if (!rows.length || !rows[0].value) return [];
  try {
    const map = JSON.parse(rows[0].value);
    return Array.isArray(map) ? map : [];
  } catch (_) {
    return [];
  }
}

function findTeacherContact(award, map) {
  const matches = map.filter(item =>
    normalize(item.class) === normalize(award.class) &&
    normalize(item.subject) === normalize(award.subject) &&
    normalize(item.teacher) === normalize(award.teacher) &&
    (!item.section || normalize(item.section) === normalize(award.section))
  );
  return matches.find(item => normalize(item.section) === normalize(award.section)) || matches[0] || null;
}

function buildReminder(award, reminderNumber, marksPending, copiesPending) {
  const pending = [];
  if (marksPending) pending.push('marks have not been completed');
  if (copiesPending) pending.push('answer copies have not been returned to the centre');
  return `*REMINDER ${reminderNumber} — AWARD LIST PENDING*\n\n` +
    `Dear ${award.teacher || 'Teacher'},\n` +
    `The following work is still pending: ${pending.join(' and ')}.\n\n` +
    `Class: ${award.class}${award.section ? ' - ' + award.section : ''}\n` +
    `Subject: ${award.subject}\n` +
    `Test Date: ${award.test_date}\n` +
    `Copies Given: ${award.copy_handed_over_at}\n\n` +
    `Please enter the marks and return the copies to the centre as soon as possible.`;
}

async function claimDailyReminder(awardId, today, reminderNumber) {
  try {
    await run(
      `INSERT INTO award_copy_reminders (award_list_id, reminder_date, reminder_number, status)
       VALUES (?, ?, ?, 'pending')`,
      [awardId, today, reminderNumber]
    );
    await run(
      'UPDATE award_lists SET copy_reminder_count = ?, copy_last_reminder_at = ? WHERE id = ?',
      [reminderNumber, today, awardId]
    );
    return true;
  } catch (_) {
    return false;
  }
}

async function deliverReminder(award, reminderNumber, reminderDate, teacherMap) {
  const marksPending = Number(award.completed_count || 0) < Number(award.student_count || 0);
  const copiesPending = !award.copy_received_at && award.copy_received_method !== 'tentative';
  if (!marksPending && !copiesPending) {
    await run(
      `UPDATE award_copy_reminders SET status = 'cancelled', fail_reason = 'Work completed before delivery'
       WHERE award_list_id = ? AND reminder_date = ? AND status = 'pending'`,
      [award.id, reminderDate]
    );
    return;
  }

  const contact = findTeacherContact(award, teacherMap);
  const phone = contact ? String(contact.phone || '').trim() : '';
  if (!phone) {
    console.warn(`[CopyReminder] Award #${award.id}: teacher WhatsApp number is missing in Settings.`);
    return;
  }

  const message = buildReminder(award, reminderNumber, marksPending, copiesPending);
  const db = require('./database');
  const result = await smartSend({
    name: award.teacher || 'Teacher',
    class: award.class,
    section: award.section || '',
    parent_phone: phone,
    parent_phone2: '',
    student_uid: null,
    wa_status: ''
  }, message, db);

  const now = pktNow();
  const sentAt = result.sent ? now.toISOString().replace('T', ' ').split('.')[0] : null;
  await run(
    `UPDATE award_copy_reminders SET status = ?, sent_at = ?, fail_reason = ?
     WHERE award_list_id = ? AND reminder_date = ?`,
    [result.queued ? 'queued' : result.sent ? 'sent' : 'failed', sentAt, result.sent ? null : result.reason, award.id, reminderDate]
  );

  const retryUntil = (result.sent || result.queued) ? null : new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0];
  await run(
    `INSERT INTO whatsapp_log
      (student_name, student_class, phone, message, type, status, retry_until, log_type, msg_id, used_phone2, fail_reason)
     VALUES (?, ?, ?, ?, 'COPY_REMINDER', ?, ?, 'COPY_REMINDER', ?, ?, ?)`,
    [award.teacher || 'Teacher', award.class, result.phone || phone, message,
     result.queued ? 'queued' : result.sent ? 'sent' : 'failed', retryUntil, result.msgId || null,
     result.usedFallback ? 1 : 0, result.sent ? null : result.reason]
  );

  console.log(`[CopyReminder] Award #${award.id}: Reminder ${reminderNumber} ${result.queued ? 'queued' : result.sent ? 'sent' : 'failed'}${reminderNumber >= 7 ? ' — CRITICAL' : ''}`);
}

// The always-online Award Portal can create reminder jobs while this computer
// is off. On startup, send only the newest pending reminder for each award
// list; older queued days are marked superseded so a teacher never receives a
// burst of several stale reminders at once.
async function deliverCloudQueuedReminders(teacherMap) {
  const pending = await query(`
    SELECT r.reminder_date, r.reminder_number, al.*,
      COUNT(ale.id) AS student_count,
      SUM(CASE WHEN ale.marks_obtained IS NOT NULL OR ale.special_status IS NOT NULL THEN 1 ELSE 0 END) AS completed_count
    FROM award_copy_reminders r
    JOIN award_lists al ON al.id = r.award_list_id
    LEFT JOIN award_list_entries ale ON ale.award_list_id = al.id
    WHERE r.status = 'pending'
    GROUP BY r.id
    ORDER BY al.id, r.reminder_number DESC
  `);
  const newestByAward = new Map();
  for (const row of pending) {
    if (!newestByAward.has(Number(row.id))) newestByAward.set(Number(row.id), row);
  }
  for (const award of newestByAward.values()) {
    await run(
      `UPDATE award_copy_reminders SET status = 'superseded', fail_reason = 'A newer reminder was delivered'
       WHERE award_list_id = ? AND status = 'pending' AND reminder_number < ?`,
      [award.id, award.reminder_number]
    );
    await deliverReminder(award, Number(award.reminder_number), award.reminder_date, teacherMap);
  }
}

async function runCopyReminderTick() {
  try {
    const now = pktNow();
    const hour = now.getUTCHours();
    if (hour < 10) return;
    const today = now.toISOString().slice(0, 10);
    const teacherMap = await loadTeacherMap();
    await deliverCloudQueuedReminders(teacherMap);

    const awards = await query(`
      SELECT al.*,
        COUNT(ale.id) AS student_count,
        SUM(CASE WHEN ale.marks_obtained IS NOT NULL OR ale.special_status IS NOT NULL THEN 1 ELSE 0 END) AS completed_count
      FROM award_lists al
      LEFT JOIN award_list_entries ale ON ale.award_list_id = al.id
      WHERE al.copy_handed_over_at IS NOT NULL
        AND date(al.copy_handed_over_at) <= date(?, '-6 days')
        AND (al.copy_last_reminder_at IS NULL OR date(al.copy_last_reminder_at) < date(?))
      GROUP BY al.id
      ORDER BY al.copy_handed_over_at ASC
    `, [today, today]);
    if (!awards.length) return;

    for (const award of awards) {
      const marksPending = Number(award.completed_count || 0) < Number(award.student_count || 0);
      const copiesPending = !award.copy_received_at && award.copy_received_method !== 'tentative';
      if (!marksPending && !copiesPending) continue;

      const reminderNumber = Number(award.copy_reminder_count || 0) + 1;
      const claimed = await claimDailyReminder(award.id, today, reminderNumber);
      if (!claimed) continue;
      await deliverReminder(award, reminderNumber, today, teacherMap);
    }
  } catch (error) {
    console.error('[CopyReminder] Scheduler error:', error.message || error);
  }
}

function startCopyReminderScheduler() {
  runCopyReminderTick();
  setInterval(runCopyReminderTick, 60 * 60 * 1000);
  console.log('[CopyReminder] Active — daily reminders begin six days after handover.');
}

module.exports = { startCopyReminderScheduler, runCopyReminderTick };
