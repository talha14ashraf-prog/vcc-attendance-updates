function requireLogin(req, res, next) {
  // Allow login page and login API through without auth
  if (req.path === '/login' || req.path === '/api/auth/login') {
    return next();
  }
  // Allow static assets through
  if (req.path.startsWith('/assets/')) {
    return next();
  }
  // Check if session is authenticated
  if (req.session && req.session.loggedIn) {
    return next();
  }
  // API requests get 401 JSON response
  if (req.path.startsWith('/api/')) {
    return res.status(401).json({ success: false, error: 'Not authenticated' });
  }
  // Page requests redirect to login
  res.redirect('/login');
}

module.exports = requireLogin;