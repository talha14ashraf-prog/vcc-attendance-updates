// ── print.js ─────────────────────────────────────────────────────────────
// Thermal (ESC/POS) slip printing, isolated from sale logic in
// routes/notes.js so the printer setup can change without touching the
// sale/reprint code at all.
//
// PRINTER: 80mm thermal roll, connected via USB.
// On Windows, node-thermal-printer talks to a USB thermal printer through
// the OS print spooler — NOT a raw USB/serial handle. That means:
//
//   1. Install the printer's Windows driver as you normally would (it will
//      show up in Settings → Printers & Scanners with a name, e.g.
//      "POS-80" or "XP-80C").
//   2. Set THERMAL_PRINTER_NAME in .env to that exact printer name.
//   3. Run: npm install printer
//      This package provides the native Windows spooler binding
//      node-thermal-printer needs for interface: 'printer:<name>'.
//      It compiles a native addon, so on Windows you first need:
//        - Python 3.x on PATH
//        - "Desktop development with C++" workload from Visual Studio
//          Build Tools (https://visualstudio.microsoft.com/downloads/)
//      This is a one-time setup step; once installed, printing itself
//      needs no internet connection.
//
// Until THERMAL_PRINTER_NAME is set (or the "printer" package isn't
// installed), sendToThermalPrinter() below throws and routes/notes.js
// falls back to the browser print modal automatically — nothing breaks.

const PRINTER_WIDTH_CHARS = 48; // 80mm roll, standard 12x24 font ≈ 48 chars/line (58mm ≈ 32)

function getPrinterName() {
  return process.env.THERMAL_PRINTER_NAME || '';
}

// Builds a plain-data representation of a sale slip. Called by
// routes/notes.js for both fresh sales and reprints — same shape either way.
// This is the LONG/detailed layout: full item lines with unit price shown
// separately from qty and line total, cost-centre style spacing, a due
// summary block, and a footer — meant for an 80mm roll, not a compact
// 58mm layout.
function buildSlipData(sale, items, vccName, contact) {
  return {
    vcc_name: vccName || 'Vectors Coaching Centre',
    contact: contact || '',
    sale_id: sale.id,
    date: sale.created_at,
    sale_type: sale.sale_type,
    customer_type: sale.customer_type,
    customer_name: sale.customer_name || '',
    customer_phone: sale.customer_phone || '',
    class: sale.class || '',
    items: items.map(it => ({
      subject: it.subject,
      class: it.class,
      qty: it.qty,
      unit_price: it.unit_price,
      line_total: Number((it.unit_price * it.qty).toFixed(2)),
    })),
    total_amount: sale.total_amount,
    amount_paid: sale.amount_paid,
    amount_due: sale.amount_due,
  };
}

function money(n) { return 'Rs ' + Number(n || 0).toFixed(2); }

// Lays out the LONG (80mm) receipt onto a ThermalPrinter instance using its
// formatting API (alignment, bold, table rows) rather than raw text, so
// column widths adapt to PRINTER_WIDTH_CHARS automatically.
function layoutLongReceipt(printer, slip) {
  printer.alignCenter();
  printer.setTextDoubleHeight();
  printer.bold(true);
  printer.println(slip.vcc_name);
  printer.bold(false);
  printer.setTextNormal();
  if (slip.contact) printer.println(`Contact: ${slip.contact}`);
  printer.drawLine();

  printer.alignLeft();
  printer.println(`Receipt #${slip.sale_id}${slip.sale_type === 'lumpsum' ? '  (LUMPSUM ISSUE)' : ''}`);
  printer.println(`Date: ${slip.date}`);
  printer.newLine();
  printer.println(`Customer : ${slip.customer_name || '-'}  (${slip.customer_type})`);
  if (slip.customer_phone) printer.println(`Phone    : ${slip.customer_phone}`);
  if (slip.class) printer.println(`Class    : ${slip.class}`);
  printer.drawLine();

  // Item table header
  printer.tableCustom([
    { text: 'Item', align: 'LEFT', width: 0.45 },
    { text: 'Qty', align: 'CENTER', width: 0.15 },
    { text: 'Price', align: 'RIGHT', width: 0.2 },
    { text: 'Total', align: 'RIGHT', width: 0.2 },
  ]);
  printer.drawLine();

  slip.items.forEach(it => {
    printer.tableCustom([
      { text: it.subject, align: 'LEFT', width: 0.45 },
      { text: String(it.qty), align: 'CENTER', width: 0.15 },
      { text: money(it.unit_price), align: 'RIGHT', width: 0.2 },
      { text: money(it.line_total), align: 'RIGHT', width: 0.2 },
    ]);
  });
  printer.drawLine();

  printer.alignRight();
  printer.println(`Total: ${money(slip.total_amount)}`);
  printer.println(`Paid:  ${money(slip.amount_paid)}`);
  if (slip.amount_due > 0) {
    printer.bold(true);
    printer.println(`Due:   ${money(slip.amount_due)}`);
    printer.bold(false);
  }
  printer.newLine();

  printer.alignCenter();
  printer.drawLine();
  printer.println('Thank you for visiting!');
  printer.println('Please keep this receipt for your records.');
  printer.newLine();
  printer.cut();
}

// Attempts to print the LONG (80mm) receipt to the configured Windows
// thermal printer via the OS print spooler. Requires:
//   - THERMAL_PRINTER_NAME set in .env to the exact Windows printer name
//   - `npm install printer` (native module, see setup notes above)
// Throws with a clear reason if either prerequisite is missing, which
// routes/notes.js uses to fall back to the browser print modal.
async function sendToThermalPrinter(slipData) {
  const printerName = getPrinterName();
  if (!printerName) {
    throw new Error('THERMAL_PRINTER_NAME is not set in .env — add it (the exact name shown in Windows Printers & Scanners) to enable direct thermal printing.');
  }

  let driver;
  try {
    driver = require('printer'); // native Windows spooler binding — npm install printer
  } catch (e) {
    throw new Error('The "printer" package is not installed. Run: npm install printer (see setup notes at the top of backend/print.js for Windows build prerequisites).');
  }

  const { ThermalPrinter, PrinterTypes } = require('node-thermal-printer');
  const printer = new ThermalPrinter({
    type: PrinterTypes.EPSON,
    interface: `printer:${printerName}`,
    driver,
    width: PRINTER_WIDTH_CHARS,
    options: { timeout: 5000 },
  });

  const isConnected = await printer.isPrinterConnected().catch(() => false);
  if (!isConnected) {
    throw new Error(`Could not reach printer "${printerName}". Check it's powered on, connected via USB, and set as a Windows printer with that exact name.`);
  }

  layoutLongReceipt(printer, slipData);
  await printer.execute();
}

// Single entry point routes/notes.js calls. Tries the real printer first;
// on any failure (not configured, unreachable, etc.) it reports that so the
// frontend falls back to the browser print modal instead of silently doing
// nothing.
async function printSlip(slipData) {
  try {
    await sendToThermalPrinter(slipData);
    return { printed: true, method: 'thermal' };
  } catch (e) {
    return { printed: false, method: 'browser-fallback', reason: e.message };
  }
}

module.exports = { buildSlipData, sendToThermalPrinter, printSlip, PRINTER_WIDTH_CHARS };
