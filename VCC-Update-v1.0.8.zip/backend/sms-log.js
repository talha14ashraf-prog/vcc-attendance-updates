function category(row) {
  if (row.source_log_type) return row.source_log_type;
  return ({ marks:'EXAM_RESULT', test_plan:'TEST_PLAN', pdf:'DOCUMENT', other:'COPY_REMINDER' })[row.type] || 'ATTENDANCE';
}
module.exports = { category };
