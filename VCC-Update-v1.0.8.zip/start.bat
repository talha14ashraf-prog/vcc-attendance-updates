@echo off
title VCC Attendance System
color 0A
cd /d "%~dp0"

echo ============================================
echo   VCC Attendance System - Starting...
echo ============================================
echo.

:: Sanity checks
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not installed on this PC.
    echo Please install it from https://nodejs.org
    echo.
    pause
    exit /b 1
)

if not exist ".env" (
    echo [ERROR] No .env file found in this folder.
    echo Run setup.bat first, or see SETUP.md.
    echo.
    pause
    exit /b 1
)

:: Apply a verified staged update while the database/server are still closed.
if exist "_updates\pending.json" (
    echo Applying verified VCC update...
    node backend\apply-update.js
    if errorlevel 1 (
        echo [WARNING] Update failed and the previous version was restored.
        echo Details are saved in _updates\last-result.json
    ) else (
        echo [OK] Update applied successfully.
    )
    echo.
)

if not exist "node_modules" (
    echo [WARNING] Dependencies not installed yet.
    echo Running setup.bat first...
    echo.
    call setup.bat
)

:: If VCC is already running, do not launch a second database process.
:: Open the existing app instead so double-clicking this file always feels
:: like "open VCC", not like a server failure.
powershell -NoProfile -Command "$ProgressPreference='SilentlyContinue'; try { Invoke-WebRequest -UseBasicParsing -Uri 'http://localhost:3000' -TimeoutSec 2 | Out-Null; exit 0 } catch { if ($_.Exception.Response) { exit 0 }; exit 1 }"
if %errorlevel% equ 0 (
    echo VCC Attendance System is already running.
    echo Opening it in your browser...
    start "" "http://localhost:3000"
    exit /b 0
)

echo Starting server...
echo.
echo Once you see "Server running", open this in your browser:
echo   http://localhost:3000
echo.
echo Keep this window open while using the system.
echo Close this window to stop the server.
echo.
echo ============================================
echo.

call npm start

:: If the server crashes or is stopped, keep window open to show the error
echo.
echo ============================================
echo   Server stopped.
echo ============================================
pause
