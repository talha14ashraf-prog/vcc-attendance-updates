# VCC Attendance System
### Vectors Coaching Centre — Student Attendance & WhatsApp Notification

---

## FIRST TIME SETUP (Do this only once)

1. Make sure Node.js is installed (you already did this)

2. Open Command Prompt inside this folder:
   - Right click the `vcc-attendance` folder
   - Click "Open in Terminal" or "Open Command Prompt here"

3. Install all packages (only first time):
   ```
   npm install
   ```

4. Start the system:
   ```
   npm start
   ```

5. Open your browser and go to:
   ```
   http://localhost:3000
   ```

---

## DAILY USE (Every day after setup)

1. Open Command Prompt in the `vcc-attendance` folder
2. Type: `npm start`
3. Open browser: `http://localhost:3000`
4. Connect WhatsApp (click "Connect" button top right, scan QR once)
5. Start scanning student cards

---

## PAGES

| Page | URL | Purpose |
|------|-----|---------|
| Scanner | http://localhost:3000 | Scan QR cards at entrance/exit |
| Dashboard | http://localhost:3000/dashboard | View today's attendance & absent list |
| Students | http://localhost:3000/students | Add/manage students |
| ID Cards | http://localhost:3000/idcard | Generate & print QR cards |
| Settings | http://localhost:3000/settings | Change messages, upload card template |

---

## HOW TO ADD STUDENTS

1. Go to http://localhost:3000/students
2. Fill in: Name, Class, Parent WhatsApp Number
3. Click "Add Student"
4. System automatically creates a unique QR code

---

## HOW TO PRINT ID CARDS

1. Go to http://localhost:3000/idcard
2. Select students (click their cards)
3. Click "Print Cards"
4. Print from browser (Ctrl+P)

---

## HOW TO CHANGE MESSAGES

1. Go to http://localhost:3000/settings
2. Edit the IN or OUT message
3. Use placeholders: {name} {time} {date} {contact} {class}
4. Click Save — changes apply instantly

---

## HOW TO CONNECT WHATSAPP

1. Click "Connect" button (top right of scanner page)
2. A QR code appears
3. Open WhatsApp on your phone
4. Go to Settings > Linked Devices > Link a Device
5. Scan the QR code
6. Done — messages will send automatically

Note: Keep the laptop running while taking attendance. WhatsApp must stay connected.

---

## DATABASE

All data is stored in `vcc.db` file in this folder.
To backup: just copy the `vcc.db` file somewhere safe.
To restore: replace the `vcc.db` file.

---

## TROUBLESHOOTING

**"npm start" shows error:**
- Make sure you ran `npm install` first

**WhatsApp not sending:**
- Click Connect and scan QR again
- Make sure your phone has internet

**Camera not working for QR scan:**
- Allow camera permission in browser
- Or use the manual UID input box instead

---

Made for Vectors Coaching Centre, Karachi.
