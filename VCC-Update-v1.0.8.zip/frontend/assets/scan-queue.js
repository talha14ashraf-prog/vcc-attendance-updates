(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.VccScanQueue=factory()})(typeof globalThis!=='undefined'?globalThis:this,function(){
  const pause=ms=>new Promise(resolve=>setTimeout(resolve,ms));
  function browserStorage(){try{return globalThis.localStorage}catch(_){return null}}
  function pktDay(value){try{return new Date(value+5*3600000).toISOString().slice(0,10)}catch(_){return ''}}
  class ScanQueue {
    constructor(options){
      this.options=options;this.key=options.key||'vcc_pending_scans_v1';this.jobs=[];this.held=[];this.running=false;this.recent=new Map();this.active=new Set();this.accessRetryAt=0;
      this.concurrency=Math.max(1,Math.min(3,options.concurrency??2));
      if(!options.storage)this.notify('onWarning','Browser storage unavailable. Keep this screen open until pending taps are confirmed.');
      try{const saved=JSON.parse(options.storage?.getItem(this.key)||'[]');if(Array.isArray(saved))for(const j of saved){if(j&&typeof j.uid==='string'&&typeof j.id==='string'&&Number.isFinite(j.createdAt))(j.review?this.held:this.jobs).push(j)}}catch(_){this.notify('onWarning','Scan queue could not be restored. Contact administration.')}
    }
    // Display/storage errors cannot interrupt attendance processing.
    notify(name,...args){try{this.options[name]?.(...args)}catch(error){if(name!=='onWarning')try{this.options.onWarning?.('Display issue; attendance processing continues.')}catch(_){}}}
    persist(){try{this.options.storage?.setItem(this.key,JSON.stringify([...this.held,...this.jobs]))}catch(_){this.notify('onWarning','Keep this screen open: pending scans could not be backed up in this browser.')}}
    report(){this.notify('onQueue',this.jobs.length,this.held.length,{retrying:this.jobs.filter(j=>j.attempts>0).length,accessBlocked:this.accessRetryAt>Date.now()})}
    enqueue(uid){
      uid=String(uid||'').trim();if(!uid)return false;
      const now=Date.now();
      if(this.jobs.some(j=>j.uid===uid)||(this.recent.has(uid)&&now-this.recent.get(uid)<2000))return false;
      this.recent.set(uid,now);for(const [key,time] of this.recent)if(now-time>120000)this.recent.delete(key);
      const id=this.options.idFactory?this.options.idFactory():globalThis.crypto.randomUUID();
      this.jobs.push({uid,id,createdAt:now});this.persist();this.report();this.wake?.();this.drain();return true;
    }
    resume(){this.report();this.wake?.();this.drain()}
    wait(ms){return new Promise(resolve=>{const done=()=>{clearTimeout(timer);if(this.wake===done)this.wake=null;resolve()};const timer=setTimeout(done,ms);this.wake=done})}
    hold(job,reason){this.jobs=this.jobs.filter(j=>j!==job);job.review=true;job.reviewReason=reason;this.held.push(job);this.persist();this.report();this.notify('onWarning',reason)}
    async process(job){
      this.notify('onStart',job);
      try{
        const data=await this.options.send(job);
        if(!data||typeof data.success!=='boolean')throw new Error('Invalid scan response');
        if(data.review_required){this.hold(job,data.error||'Unconfirmed tap needs administration review. New taps can continue.');return}
        this.jobs=this.jobs.filter(j=>j!==job);this.accessRetryAt=0;this.persist();this.report();this.notify('onResult',data,job);
        await pause(this.options.resultDelayMs??350);
      }catch(error){
        job.attempts=(job.attempts||0)+1;
        const base=this.options.retryDelayMs??1800;
        job.retryAt=Date.now()+Math.min(30000,base*Math.pow(2,Math.min(job.attempts-1,4)));
        if(error?.code==='SCAN_ACCESS'){this.accessRetryAt=Date.now()+(this.options.accessRetryMs??10000);job.retryAt=this.accessRetryAt}
        this.persist();this.notify('onWaiting',job,error);this.report();
      }
    }
    async drain(){
      if(this.running)return;this.running=true;
      try{while(this.jobs.length||this.active.size){
        const today=pktDay(Date.now());
        for(const job of [...this.jobs])if(!this.active.has(job.id)&&pktDay(job.createdAt)!==today)this.hold(job,'Earlier-day unconfirmed scans need administration review. New taps can continue.');
        const now=Date.now();
        const ready=this.accessRetryAt>now?[]:this.jobs.filter(j=>!this.active.has(j.id)&&(!j.retryAt||j.retryAt<=now));
        // Other students continue while a card is slow. The same card stays
        // locked until its original request ID resolves.
        for(const job of ready){if(this.active.size>=this.concurrency)break;this.active.add(job.id);this.process(job).finally(()=>{this.active.delete(job.id);this.report();this.wake?.()})}
        if(this.jobs.length||this.active.size)await this.wait(250);
      }}catch(error){this.notify('onWarning','Scanner is recovering; pending taps remain saved.')}finally{
        this.running=false;
        if(this.jobs.length)setTimeout(()=>this.drain(),1000);
      }
    }
  }
  async function sendScan(url,job,timeoutMs=8000){
    const controller=new AbortController();const timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{const response=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({uid:job.uid,request_id:job.id,tapped_at:job.createdAt}),signal:controller.signal});
      if(response.status>=500||response.status===429)throw new Error('Server busy - confirming scan');
      if(response.status===401||response.status===403||response.redirected){const error=new Error('Scanner access unavailable — sign in again or contact administration. Pending taps are saved.');error.code='SCAN_ACCESS';throw error}
      const data=await response.json();if(!response.ok&&typeof data.success!=='boolean')throw new Error('Scan could not be confirmed');return data;
    }finally{clearTimeout(timer)}
  }
  return {ScanQueue,sendScan,browserStorage};
});
