// Run inference off the UI thread, with locally bundled assets only.
self.exports = {};
importScripts('/assets/vendor/mediapipe/vision_bundle.js');
let model;
async function getModel() {
  if (!model) {
    model = (async () => {
      const files = await self.exports.FilesetResolver.forVisionTasks('/assets/vendor/mediapipe/wasm');
      return self.exports.ImageSegmenter.createFromOptions(files, {
        baseOptions: { modelAssetPath:'/assets/portrait-model/selfie_multiclass_256x256.tflite', delegate:'CPU' },
        runningMode:'IMAGE', outputConfidenceMasks:true, outputCategoryMask:false
      });
    })();
  }
  return model;
}
self.onmessage = async ({data:{id, source}}) => {
  let bitmap;
  try {
    const segmenter = await getModel();
    bitmap = await createImageBitmap(await (await fetch(source)).blob());
    const canvas = new OffscreenCanvas(bitmap.width, bitmap.height);
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.drawImage(bitmap, 0, 0);
    const frame = ctx.getImageData(0, 0, bitmap.width, bitmap.height);
    // Class 0 = background; all other classes are hair, skin, clothes or
    // accessories. Never classify foreground by its colour.
    segmenter.segment(bitmap, result => {
      const mask = result.confidenceMasks[0];
      const confidence = mask.getAsFloat32Array();
      const mw = mask.width, mh = mask.height;
      let foreground = 0;
      for (let y = 0; y < bitmap.height; y++) for (let x = 0; x < bitmap.width; x++) {
        const mx = Math.max(0, Math.min(mw-1, (x+0.5)*mw/bitmap.width-0.5));
        const my = Math.max(0, Math.min(mh-1, (y+0.5)*mh/bitmap.height-0.5));
        const x0 = Math.floor(mx), y0 = Math.floor(my);
        const x1 = Math.min(x0+1,mw-1), y1 = Math.min(y0+1,mh-1);
        const dx = mx-x0, dy = my-y0;
        const bg = (confidence[y0*mw+x0]*(1-dx)+confidence[y0*mw+x1]*dx)*(1-dy)
          +(confidence[y1*mw+x0]*(1-dx)+confidence[y1*mw+x1]*dx)*dy;
        // Preserve confident foreground exactly; feather only uncertain edges.
        const t = Math.max(0, Math.min(1, (1-bg-0.15)/0.7));
        const alpha = t*t*(3-2*t);
        if (alpha > 0.5) foreground++;
        const p = (y*bitmap.width+x)*4;
        for (let c=0;c<3;c++) frame.data[p+c] = Math.round(frame.data[p+c]*alpha+255*(1-alpha));
        frame.data[p+3] = 255;
      }
      const ratio = foreground/(bitmap.width*bitmap.height);
      if (ratio < 0.08 || ratio > 0.97) throw new Error('Student could not be separated clearly. Please keep the original photo.');
    });
    ctx.putImageData(frame,0,0);
    const blob = await canvas.convertToBlob({type:'image/jpeg', quality:0.94});
    self.postMessage({id, blob});
  } catch(error) {
    model = null;
    self.postMessage({id,error:error.message || 'Photo processing failed'});
  } finally { bitmap?.close(); }
};
