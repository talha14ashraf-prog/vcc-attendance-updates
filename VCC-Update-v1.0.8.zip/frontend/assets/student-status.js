window.VccStudentStatus = {
  normalize(value) {
    const status = String(value ?? '').trim().toLowerCase();
    return status === 'active' || status === 'inactive' ? status : '';
  },
  label(value) {
    const status = this.normalize(value);
    return status === 'active' ? 'Active' : status === 'inactive' ? 'Inactive' : 'Needs review';
  },
  load(id, value) {
    const input = document.getElementById(id);
    const status = this.normalize(value);
    input.checked = status === 'active';
    input.indeterminate = !status;
    this.describe(input);
  },
  describe(input) {
    document.getElementById(input.id + '-hint').textContent = input.indeterminate
      ? 'Status needs review. Choose Active or Inactive before saving.'
      : input.checked ? 'Active' : 'Inactive';
  },
  value(id) {
    const input = document.getElementById(id);
    return input.indeterminate ? '' : input.checked ? 'active' : 'inactive';
  },
  filter(active, inactive) {
    if (active && inactive) return 'all';
    if (active) return 'active';
    return inactive ? 'inactive' : 'none';
  }
};
