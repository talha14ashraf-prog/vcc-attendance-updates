(() => {
  let worker, nextId=0;
  const pending = new Map();
  function stop(error) {
    worker?.terminate(); worker=null;
    for (const task of pending.values()) { clearTimeout(task.timer); task.reject(error); }
    pending.clear();
  }
  window.PortraitBackground = {
    remove(source) {
      if (!worker) {
        worker = new Worker('/assets/portrait-worker.js?v=1');
        worker.onmessage = ({data}) => {
          const task = pending.get(data.id);
          if (!task) return;
          clearTimeout(task.timer); pending.delete(data.id);
          if (data.error) task.reject(new Error(data.error)); else task.resolve(data.blob);
        };
        worker.onerror = () => stop(new Error('Photo engine could not start. Refresh the page and try again.'));
      }
      return new Promise((resolve,reject) => {
        const id=++nextId;
        const timer=setTimeout(() => stop(new Error('Photo processing timed out. Please try again.')),60000);
        pending.set(id,{resolve,reject,timer}); worker.postMessage({id,source});
      });
    }
  };
})();
