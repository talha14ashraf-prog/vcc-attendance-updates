(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.VccGender=factory()})(typeof globalThis!=='undefined'?globalThis:this,function(){
  function normalize(value){const text=String(value??'').trim();const k=text.toLowerCase();return k==='m'||k==='male'?'Male':k==='f'||k==='female'?'Female':text}
  function key(value){return normalize(value).toLowerCase()}
  function options(csv){const seen=new Set();return String(csv??'Male,Female').split(',').map(v=>v.trim()).filter(v=>{const k=key(v);if(!k||seen.has(k))return false;seen.add(k);return true})}
  return{normalize,key,options};
});
