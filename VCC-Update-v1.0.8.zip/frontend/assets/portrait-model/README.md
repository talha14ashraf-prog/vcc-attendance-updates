# Local portrait segmentation

The enrolment photo editor uses Google's MediaPipe Selfie Multiclass model.
It preserves every non-background category (hair, skin, clothing, accessories).
It does not use pixel colour thresholds to decide which parts of a student to remove.

- Runtime: @mediapipe/tasks-vision 0.10.22-rc.20250304, Apache-2.0.
- Model: https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_multiclass_256x256/float32/1/selfie_multiclass_256x256.tflite
- Documentation: https://ai.google.dev/edge/mediapipe/solutions/vision/image_segmenter
- Model card: https://storage.googleapis.com/mediapipe-assets/Model%20Card%20Multiclass%20Segmentation.pdf

Runtime JS/WASM and the model are bundled locally, so operation does not require
an external photo service or internet connection. Photographs stay in the browser
during segmentation. The selected preview is saved through the existing student
API together with its original backup.

Inference runs on the CPU in a dedicated worker; only one engine is kept per page.
The UI ignores outdated results after Original, Remove, Clear or student changes.
Uncertain detections and engine failures leave the original selected.
