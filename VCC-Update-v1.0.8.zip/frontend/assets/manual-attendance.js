(() => {
  const dialog=document.getElementById('manual-attendance-dialog');
  const form=document.getElementById('ma-form');
  const search=document.getElementById('ma-search');
  const results=document.getElementById('ma-results');
  const selectedBanner=document.getElementById('ma-selected');
  const feedback=document.getElementById('ma-feedback');
  const save=document.getElementById('ma-save');
  let students=[],selected=null,busy=false,loadId=0;
  function message(text,success=false){feedback.textContent=text;feedback.classList.toggle('success',success)}
  function meta(s){return[s.class,s.section,s.gr_number?'GR '+s.gr_number:'',s.father_name].filter(Boolean).join(' · ')}
  window.openManualAttendance=async function(){
    if(dialog.open)return;
    const requestId=++loadId;
    form.reset();selected=null;students=[];selectedBanner.hidden=true;results.replaceChildren();message('Loading students…');save.disabled=true;
    const parts=new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Karachi',year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date());
    const date=Object.fromEntries(parts.map(p=>[p.type,p.value]));document.getElementById('ma-date').value=`${date.year}-${date.month}-${date.day}`;
    dialog.showModal();search.focus();
    try{const response=await fetch('/api/students?status=active',{credentials:'include'});const data=await response.json();if(!response.ok||!data.success)throw new Error(data.error||'Could not load students');if(requestId!==loadId||!dialog.open)return;students=data.students||[];message('');save.disabled=false;renderMatches()}
    catch(error){if(requestId===loadId&&dialog.open)message(error.message)}
  };
  window.closeManualAttendance=function(){if(busy)return;loadId++;dialog.close()};
  dialog.addEventListener('cancel',event=>{if(busy)event.preventDefault();else loadId++});
  function renderMatches(){results.replaceChildren();const q=search.value.trim().toLowerCase();if(!q)return;const matches=students.filter(s=>[s.name,s.gr_number,s.student_uid,s.father_name,s.class,s.section].some(value=>String(value||'').toLowerCase().includes(q))).slice(0,20);if(!matches.length){results.textContent='No matching active students.';return}matches.forEach(student=>{const button=document.createElement('button');button.type='button';button.className='ma-result';const title=document.createElement('strong');title.textContent=student.name;const detail=document.createElement('small');detail.textContent=meta(student)+(Number(student.is_frozen)===1?' · Frozen (manual override)':'');button.append(title,detail);button.onclick=()=>{selected=student;search.value=student.name;selectedBanner.textContent=student.name+' · '+meta(student);selectedBanner.hidden=false;results.replaceChildren();message('')};results.append(button)})}
  search.addEventListener('input',()=>{if(busy)return;selected=null;selectedBanner.hidden=true;renderMatches()});
  search.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();results.querySelector('button')?.focus()}});
  form.addEventListener('submit',async event=>{
    event.preventDefault();if(busy)return;if(!selected){message('Select a student from the search results.');search.focus();return}if(!form.reportValidity())return;
    busy=true;search.readOnly=true;save.disabled=true;save.textContent='Saving…';message('');
    try{const response=await fetch('/api/attendance/manual',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json'},body:JSON.stringify({student_uid:selected.student_uid,type:document.getElementById('ma-type').value,date:document.getElementById('ma-date').value,time:document.getElementById('ma-time').value||null})});const data=await response.json();if(!response.ok||!data.success)throw new Error(data.error||'Attendance could not be saved');message('Attendance saved for '+selected.name+'.',true);selected=null;search.value='';selectedBanner.hidden=true;results.replaceChildren();if(typeof refreshLog==='function')refreshLog();if(typeof refreshStats==='function')refreshStats();search.focus()}
    catch(error){message(error.message)}finally{busy=false;search.readOnly=false;save.disabled=false;save.textContent='Save Attendance'}
  });
})();
