@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0kiosk-launcher.ps1" -InstallShortcut
if errorlevel 1 pause
