const { connect } = require('@tursodatabase/sync');
const path = require('path');
const fs = require('fs');
const syncTransport = require('./sync-transport').createSyncTransport();
let lastScanAt = 0;
function noteScanActivity() { lastScanAt = Date.now(); syncTransport.yieldToScan(); }

// ── WHY THIS FILE LOOKS DIFFERENT FROM BEFORE ───────────────────────────────
// This used to be built on @libsql/client's "Embedded Replicas" feature,
// which required us to hand-roll WAL-conflict recovery (delete the local
// file, reopen, restore salvaged rows...). That approach kept surfacing new
// race conditions every time reconnect happened (EBUSY loops, torn
// db/metadata file states) because embedded replicas were never designed to
// have conflicts resolved automatically — the app is responsible for it.
//
// @tursodatabase/sync is Turso's newer, purpose-built package for exactly
// this offline-first use case: local reads/writes always hit the local file
// instantly (works fully offline), and push()/pull() reconcile with the
// cloud using a built-in "last-push-wins" conflict strategy — no manual
// delete/rebuild code needed at all. It's officially recommended by Turso
// for new local+sync projects. It's newer/beta software, so we also keep a
// daily local .db backup file (see backupDb()) as a safety net.

let db = null;
let isOnline = false;
let lastSyncAt = null;
let syncTimer = null;
let cloudConfigured = false;
const SYNC_INTERVAL_SEC = 30; // background safety-net push/pull
let syncState = 'starting';
let lastSyncError = null;
let consecutiveSyncFailures = 0;
let nextSyncAllowedAt = 0;
let pendingLocalChanges = 0;

// Serialize local writes, checkpoints and push/pull. Previously a route could
// commit another local mutation while pull() was replaying pending mutations,
// which made sleep/resume and unstable-network races much more likely.
let exclusiveDbTail = Promise.resolve();
function withExclusiveDb(task) {
  const operation = exclusiveDbTail.then(task, task);
  exclusiveDbTail = operation.catch(() => {});
  return operation;
}

const LOCAL_DB_PATH = path.join(__dirname, '..', 'local-replica.db');
const BACKUP_DIR = path.join(__dirname, '..', 'backups');

// ── SINGLE-INSTANCE LOCK ─────────────────────────────────────────────────
// A second copy of the server (double-clicked start.bat twice, an old
// terminal left running, a previous crash that never exited) opening the
// SAME local db file can corrupt it. This lock file stops that: on startup
// we check for a PID file next to the DB. If it points at a PID that's
// still alive, we refuse to start. Otherwise (no file, or a dead/stale PID)
// we take the lock.
// Keep the application lock completely outside the replica filename family.
// The native Turso engine owns files derived from `local-replica.db`; using
// `local-replica.db.lock` here can collide with its own cross-process locking
// (this became visible after upgrading the engine).
const LOCK_PATH = path.join(__dirname, '..', 'vcc-attendance-server.lock');

function isPidAlive(pid) {
  if (!pid || Number.isNaN(pid)) return false;
  try {
    process.kill(pid, 0); // signal 0: check existence only, doesn't kill
    return true;
  } catch (e) {
    // On Windows, EPERM means the process exists but this process is not
    // allowed to signal it. The old code treated EPERM as "dead", letting a
    // second server open the same replica and damage its sync/WAL state.
    if (e && e.code === 'ESRCH') return false;
    return true; // EPERM or an unknown check failure: fail closed and stay safe
  }
}

function acquireSingleInstanceLock() {
  try {
    if (fs.existsSync(LOCK_PATH)) {
      const raw = fs.readFileSync(LOCK_PATH, 'utf8').trim();
      const existingPid = parseInt(raw, 10);
      if (isPidAlive(existingPid)) {
        console.error('\n❌ Another instance of this server appears to already be running (PID ' + existingPid + ').');
        console.error('   Running two copies against the same local database file can corrupt it.');
        console.error('   Use the already-open VCC window, or close it normally before restarting.');
        console.error('   No database or lock file needs to be deleted.\n');
        process.exit(1);
      }
      console.warn('⚠️  Found a stale lock file (previous run did not shut down cleanly) — reclaiming it.');
      fs.unlinkSync(LOCK_PATH);
    }
    // `wx` makes lock acquisition atomic. Two launches at the same instant can
    // no longer both pass the exists-check and overwrite each other's PID.
    fs.writeFileSync(LOCK_PATH, String(process.pid), { flag: 'wx' });
  } catch (e) {
    console.error('❌ Could not safely acquire the single-instance database lock:', (e.message || e).toString().slice(0, 160));
    throw e;
  }
}

function releaseSingleInstanceLock() {
  try {
    if (fs.existsSync(LOCK_PATH)) {
      const raw = fs.readFileSync(LOCK_PATH, 'utf8').trim();
      if (parseInt(raw, 10) === process.pid) {
        fs.unlinkSync(LOCK_PATH);
      }
    }
  } catch (e) { /* best-effort cleanup */ }
}

// All CREATE TABLE statements.
const SCHEMA_SQL = `
    CREATE TABLE IF NOT EXISTS students (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT DEFAULT '',
      class TEXT DEFAULT '',
      parent_phone TEXT DEFAULT '',
      student_uid TEXT UNIQUE NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      section TEXT DEFAULT '',
      gr_number TEXT DEFAULT '',
      roll_no TEXT DEFAULT '',
      father_name TEXT DEFAULT '',
      admission_date TEXT DEFAULT '',
      group_name TEXT DEFAULT '',
      parent_phone2 TEXT DEFAULT '',
      status TEXT DEFAULT 'active',
      wa_status TEXT DEFAULT '',
      session TEXT DEFAULT '',
      campus TEXT DEFAULT '',
      gender TEXT DEFAULT '',
      religion TEXT DEFAULT '',
      dob TEXT DEFAULT '',
      admission_class TEXT DEFAULT '',
      address TEXT DEFAULT '',
      last_school TEXT DEFAULT '',
      office_address TEXT DEFAULT '',
      mother_name TEXT DEFAULT '',
      father_cnic TEXT DEFAULT '',
      father_occ TEXT DEFAULT '',
      father_qual TEXT DEFAULT '',
      mother_cnic TEXT DEFAULT '',
      mother_occ TEXT DEFAULT '',
      mother_qual TEXT DEFAULT '',
      pob TEXT DEFAULT '',
      student_photo TEXT DEFAULT NULL,
      student_photo_original TEXT DEFAULT NULL,
      is_frozen INTEGER DEFAULT 0,
      freeze_reason TEXT DEFAULT '',
      card_printed INTEGER DEFAULT 0,
      card_printed_at TEXT DEFAULT NULL,
      card_issued INTEGER DEFAULT 0,
      card_issued_at TEXT DEFAULT NULL,
      wa_dead_dismissed INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS attendance (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_uid TEXT NOT NULL,
      type TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      manual_no_time INTEGER DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS attendance_entry_states (
      student_uid TEXT NOT NULL,
      attendance_date TEXT NOT NULL,
      state TEXT NOT NULL CHECK (state IN ('P', 'A')),
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (student_uid, attendance_date)
    );

    CREATE TABLE IF NOT EXISTS scan_receipts (
      request_id TEXT PRIMARY KEY,
      scanned_uid TEXT NOT NULL,
      response_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS settings (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS whatsapp_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      student_name TEXT NOT NULL,
      student_class TEXT NOT NULL,
      phone TEXT NOT NULL,
      message TEXT NOT NULL,
      type TEXT NOT NULL,
      status TEXT NOT NULL,
      timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
      retry_until DATETIME DEFAULT NULL,
      retry_count INTEGER DEFAULT 0,
      log_type TEXT DEFAULT 'ATTENDANCE',
      report_year INTEGER DEFAULT NULL,
      report_month INTEGER DEFAULT NULL,
      student_uid TEXT DEFAULT NULL,
      caption TEXT DEFAULT NULL,
      msg_id TEXT DEFAULT NULL,
      ack INTEGER DEFAULT 0,
      used_phone2 INTEGER DEFAULT 0,
      fail_reason TEXT DEFAULT NULL
    );

    CREATE TABLE IF NOT EXISTS holidays (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      date TEXT UNIQUE NOT NULL,
      reason TEXT DEFAULT ''
    );

    CREATE TABLE IF NOT EXISTS test_plans (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class TEXT NOT NULL,
      section TEXT DEFAULT '',
      subject TEXT NOT NULL,
      test_date TEXT NOT NULL,
      day TEXT DEFAULT '',
      timing TEXT DEFAULT '',
      month INTEGER,
      year INTEGER,
      grp TEXT NOT NULL DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS award_lists (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class TEXT NOT NULL,
      section TEXT DEFAULT '',
      group_name TEXT DEFAULT '',
      gender TEXT DEFAULT '',
      subject TEXT NOT NULL,
      test_date TEXT NOT NULL,
      total_marks INTEGER NOT NULL,
      teacher TEXT DEFAULT '',
      session TEXT DEFAULT '',
      campus TEXT DEFAULT '',
      locked INTEGER DEFAULT 0,
      unlock_count INTEGER DEFAULT 0,
      qr_token TEXT DEFAULT NULL,
      copy_handed_over_at DATETIME DEFAULT NULL,
      copy_handed_over_method TEXT DEFAULT NULL,
      copy_received_at DATETIME DEFAULT NULL,
      copy_received_method TEXT DEFAULT NULL,
      copy_reminder_count INTEGER DEFAULT 0,
      copy_last_reminder_at DATETIME DEFAULT NULL,
      marks_sent_at DATETIME DEFAULT NULL,
      marks_sent_method TEXT DEFAULT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS award_list_entries (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      award_list_id INTEGER NOT NULL,
      student_uid TEXT,
      name TEXT NOT NULL,
      father_name TEXT DEFAULT '',
      gr_number TEXT DEFAULT '',
      parent_phone TEXT DEFAULT '',
      parent_phone2 TEXT DEFAULT '',
      marks_obtained REAL,
      special_status TEXT DEFAULT NULL,
      sent INTEGER DEFAULT 0,
      sent_at DATETIME
    );

    CREATE TABLE IF NOT EXISTS award_copy_reminders (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      award_list_id INTEGER NOT NULL,
      reminder_date TEXT NOT NULL,
      reminder_number INTEGER NOT NULL,
      status TEXT DEFAULT 'pending',
      sent_at DATETIME DEFAULT NULL,
      fail_reason TEXT DEFAULT NULL,
      UNIQUE(award_list_id, reminder_date)
    );

    CREATE TABLE IF NOT EXISTS notes_catalog (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      class TEXT NOT NULL,
      subject TEXT NOT NULL,
      cost_price REAL NOT NULL DEFAULT 0,
      selling_price REAL NOT NULL DEFAULT 0,
      stock_qty INTEGER NOT NULL DEFAULT 0,
      low_stock_threshold INTEGER NOT NULL DEFAULT 5,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sales (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_type TEXT NOT NULL DEFAULT 'sale',
      customer_type TEXT NOT NULL DEFAULT 'OUTSIDER',
      student_id INTEGER DEFAULT NULL,
      customer_name TEXT DEFAULT '',
      customer_phone TEXT DEFAULT '',
      class TEXT DEFAULT '',
      total_amount REAL NOT NULL DEFAULT 0,
      amount_paid REAL NOT NULL DEFAULT 0,
      amount_due REAL NOT NULL DEFAULT 0,
      voided INTEGER NOT NULL DEFAULT 0,
      voided_at DATETIME DEFAULT NULL,
      void_reason TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sale_items (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      catalog_id INTEGER DEFAULT NULL,
      subject TEXT NOT NULL,
      class TEXT NOT NULL,
      qty INTEGER NOT NULL,
      unit_cost REAL NOT NULL DEFAULT 0,
      unit_price REAL NOT NULL DEFAULT 0
    );

    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sale_id INTEGER NOT NULL,
      amount REAL NOT NULL,
      note TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS demand_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      customer_name TEXT DEFAULT '',
      customer_phone TEXT DEFAULT '',
      class TEXT NOT NULL,
      subject TEXT NOT NULL,
      qty_wanted INTEGER NOT NULL DEFAULT 1,
      status TEXT NOT NULL DEFAULT 'pending',
      requested_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS stock_adjustments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      catalog_id INTEGER NOT NULL,
      class TEXT NOT NULL,
      subject TEXT NOT NULL,
      change_qty INTEGER NOT NULL,
      stock_before INTEGER NOT NULL,
      stock_after INTEGER NOT NULL,
      reason TEXT NOT NULL DEFAULT 'other',
      note TEXT DEFAULT '',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
`;

// ── getDb() — returns the SINGLE sync-capable client ────────────────────────
// Reads/writes always hit the local file instantly, fully offline-capable.
// push()/pull() reconcile with Turso Cloud — call syncNow() for that, never
// automatically inside a query.
async function getDb() {
  if (db) return db;

  const hasCloud = !!(process.env.TURSO_URL && process.env.TURSO_TOKEN);
  cloudConfigured = hasCloud;

  if (hasCloud) {
    db = await connect({
      path: LOCAL_DB_PATH,
      url: process.env.TURSO_URL,
      authToken: process.env.TURSO_TOKEN,
      clientName: 'vcc-attendance-kiosk',
      fetch: syncTransport.fetch,
    });
    console.log('✅ Local-first sync mode (@tursodatabase/sync, local reads/writes + background push/pull with Turso)');
  } else {
    // No cloud configured — plain local database, fully offline.
    const { connect: connectLocal } = require('@tursodatabase/database');
    db = await connectLocal(LOCAL_DB_PATH);
    console.log('✅ Local-only mode (no TURSO_URL/TURSO_TOKEN set — offline only)');
  }

  return db;
}

// ── Sync (push + pull) ───────────────────────────────────────────────────
// Conflicts are resolved automatically by @tursodatabase/sync itself
// (last-push-wins) — no manual recovery code needed. If push()/pull() throws
// (offline, DNS failure, etc.) we simply note we're offline and try again on
// the next tick; local reads/writes are completely unaffected either way.
let syncInFlight = null;
async function syncNow(options = {}) {
  const force = !!options.force;
  if (!cloudConfigured) return;
  if (syncInFlight) return syncInFlight; // piggyback on an in-flight sync rather than stacking another
  if (!force && Date.now() < nextSyncAllowedAt) return;
  if (!force && Date.now() - lastScanAt < 3000) return;

  syncInFlight = withExclusiveDb(() => syncTransport.run(async () => {
    if (!force && Date.now() - lastScanAt < 3000) { syncInFlight = null; return; }
    const previousState = syncState;
    try {
      syncState = 'syncing';
      const client = await getDb();
      const before = await client.stats().catch(() => null);
      pendingLocalChanges = Number(before?.cdcOperations || 0);

      // Critical ordering rule for a writable multi-PC replica:
      // push local CDC first. Pulling remote changes while local CDC is pending
      // forces the engine to replay those local changes over the new remote
      // state — exactly the failure this installation was repeatedly hitting.
      if (pendingLocalChanges > 0) await client.push();
      await client.pull();

      // A write cannot enter while this exclusive section is active, but keep
      // this defensive push for engine-generated/transformed mutations.
      const afterPull = await client.stats().catch(() => null);
      if (Number(afterPull?.cdcOperations || 0) > 0) await client.push();

      // checkpoint() is the sync SDK's own safe WAL checkpoint. It keeps the
      // main WAL bounded and avoids external SQLite tools touching this bundle.
      await client.checkpoint();
      const after = await client.stats().catch(() => null);
      pendingLocalChanges = Number(after?.cdcOperations || 0);
      isOnline = true;
      lastSyncAt = new Date();
      syncState = 'synced';
      lastSyncError = null;
      consecutiveSyncFailures = 0;
      nextSyncAllowedAt = 0;
    } catch (err) {
      const errorText = (err.message || err).toString();
      if (errorText.includes('Cloud sync yielded to local scan')) {
        // A local card interrupted cloud work; this is not a network failure.
        syncState = previousState;
        nextSyncAllowedAt = Date.now() + 3000;
        return;
      }
      isOnline = false;
      consecutiveSyncFailures++;
      const needsAttention = /replay local change|database.*(?:corrupt|malformed)|malformed.*database|invalid.*(?:wal|sync metadata)/i.test(errorText);
      syncState = needsAttention ? 'attention' : consecutiveSyncFailures >= 3 ? 'offline' : 'retrying';
      lastSyncError = errorText.slice(0, 300);
      // Network/sleep failures back off quickly; a deterministic replay error
      // waits longer instead of hammering the same broken operation every 30s.
      const backoffMs = needsAttention
        ? 5 * 60 * 1000
        : Math.min(5 * 60 * 1000, 15000 * Math.pow(2, Math.min(consecutiveSyncFailures - 1, 5)));
      nextSyncAllowedAt = Date.now() + backoffMs;
      if (!syncNow._lastWarn || Date.now() - syncNow._lastWarn > 5 * 60 * 1000) {
        console.log(needsAttention ? '❌ Cloud sync needs attention:' : syncState === 'offline' ? '⚠️  Cloud sync offline; local data saved:' : '⚠️  Cloud sync delayed; retrying:', errorText.slice(0, 180));
        syncNow._lastWarn = Date.now();
      }
      // Local data remains available and untouched. Never delete/reset the
      // replica automatically while it may contain unpushed CDC operations.
    } finally {
      syncInFlight = null;
    }
  }));
  return syncInFlight;
}

function startBackgroundSync() {
  if (syncTimer) return;
  syncTimer = setInterval(() => { syncNow().catch(() => {}); }, SYNC_INTERVAL_SEC * 1000);
  console.log(`🔄 Background sync active (every ${SYNC_INTERVAL_SEC}s)`);
}

// Debounced sync trigger — batches rapid-fire writes (e.g. a settings form
// saving 6 keys in a loop) into a single push() shortly after, instead of
// one push() per write.
let pendingSyncTimer = null;
function scheduleSync() {
  if (pendingSyncTimer) return;
  pendingSyncTimer = setTimeout(() => {
    pendingSyncTimer = null;
    syncNow().catch(() => {});
  }, 2000);
}

function todayPKT() {
  return new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString().split('T')[0];
}

function saveDb() {}
function flushDb() {}

// ── Local backup ─────────────────────────────────────────────────────────
// A synced database is a BUNDLE (main db + WAL + sync metadata/change files),
// not one standalone .db file. Copying only local-replica.db while its WAL is
// active produces an incomplete backup. We checkpoint through the sync SDK,
// pause writes/sync via withExclusiveDb(), then snapshot every bundle member.
function ensureBackupDir() {
  try { fs.mkdirSync(BACKUP_DIR, { recursive: true }); } catch (e) {}
}

async function backupDb() {
  try {
    ensureBackupDir();
    if (!fs.existsSync(LOCAL_DB_PATH)) return 'no-local-file-yet';
    const stamp = todayPKT(); // YYYY-MM-DD
    const snapshotDir = path.join(BACKUP_DIR, `replica-${stamp}`);
    if (fs.existsSync(snapshotDir)) return snapshotDir;

    return await withExclusiveDb(async () => {
      const client = await getDb();
      try { await client.checkpoint(); } catch (e) {
        console.warn('⚠️  Backup checkpoint warning:', (e.message || e).toString().slice(0, 120));
      }

      const root = path.dirname(LOCAL_DB_PATH);
      const prefix = path.basename(LOCAL_DB_PATH);
      const members = fs.readdirSync(root).filter(name =>
        (name === prefix || name.startsWith(prefix + '-')) && name !== prefix + '.lock'
      );
      if (!members.includes(prefix)) throw new Error('Local replica main file is missing');

      const stagingDir = path.join(BACKUP_DIR, `replica-${stamp}.tmp-${process.pid}`);
      if (fs.existsSync(stagingDir)) fs.rmSync(stagingDir, { recursive:true, force:true });
      fs.mkdirSync(stagingDir, { recursive:true });
      const manifest = [];
      for (const name of members) {
        const source = path.join(root, name);
        const target = path.join(stagingDir, name);
        fs.copyFileSync(source, target);
        const stat = fs.statSync(target);
        manifest.push({ name, bytes:stat.size, modifiedAt:stat.mtime.toISOString() });
      }
      fs.writeFileSync(path.join(stagingDir, 'manifest.json'), JSON.stringify({
        createdAt:new Date().toISOString(),
        lastSyncAt:lastSyncAt ? lastSyncAt.toISOString() : null,
        syncState,
        files:manifest
      }, null, 2));
      fs.renameSync(stagingDir, snapshotDir);

      // Keep the latest 14 complete daily snapshot directories. Old legacy
      // single-file backups are left untouched for manual historical recovery.
      const snapshots = fs.readdirSync(BACKUP_DIR, { withFileTypes:true })
        .filter(entry => entry.isDirectory() && /^replica-\d{4}-\d{2}-\d{2}$/.test(entry.name))
        .map(entry => entry.name)
        .sort();
      while (snapshots.length > 14) {
        const oldest = snapshots.shift();
        const target = path.resolve(BACKUP_DIR, oldest);
        if (target.startsWith(path.resolve(BACKUP_DIR) + path.sep)) {
          try { fs.rmSync(target, { recursive:true, force:true }); } catch (e) {}
        }
      }
      return snapshotDir;
    });
  } catch (e) {
    console.warn('⚠️  Daily backup failed (continuing anyway):', (e.message || e).toString().slice(0, 100));
    return 'backup-failed';
  }
}

let backupTimer = null;
function startDailyBackup() {
  if (backupTimer) return;
  backupDb().catch(() => {}); // one at startup
  // Check hourly; once today's complete snapshot exists this becomes a no-op.
  backupTimer = setInterval(() => { backupDb().catch(() => {}); }, 60 * 60 * 1000);
}

// ── query() — returns array of row objects (hits LOCAL db instantly) ───────
async function query(sql, params = []) {
  const client = await getDb();
  return await client.all(sql, ...params);
}

// ── run() — executes INSERT/UPDATE/DELETE (hits LOCAL db, then nudges a sync) ─
async function run(sql, params = []) {
  const client = await getDb();
  const info = await withExclusiveDb(() => client.run(sql, ...params));
  pendingLocalChanges = Math.max(1, pendingLocalChanges + 1);
  scheduleSync();
  // Normalize to the shape callers expect (matches the old @libsql/client
  // ResultSet fields that routes/*.js read: rowsAffected, lastInsertRowid).
  return {
    rowsAffected: info.changes,
    lastInsertRowid: info.lastInsertRowid,
    changes: info.changes,
  };
}

// ── batchRun() — runs many statements as ONE atomic transaction ────────────
async function batchRun(statements) {
  if (!statements.length) return [];
  const client = await getDb();
  const results = await withExclusiveDb(() => client.batch(
      statements.map(s => ({ sql: s.sql, args: s.args || [] })),
      'immediate' // atomic — matches the old client.batch(..., 'write') behavior
    ));
  pendingLocalChanges = Math.max(1, pendingLocalChanges + statements.length);
  scheduleSync();
  return results;
}

// The actual init sequence: create schema + run migrations + seed defaults.
async function attemptInit(client) {
  await client.exec(SCHEMA_SQL);
  await client.exec('CREATE INDEX IF NOT EXISTS idx_attendance_student_time ON attendance(student_uid,timestamp)');
  // Archive historical duplicates and install the guard in one transaction.
  // Do not swallow errors: scans must never start without this protection.
  await require('./attendance-integrity').migrate(client);
  await client.exec(`CREATE INDEX IF NOT EXISTS idx_test_plans_lookup ON test_plans (class, subject, test_date);`);

  const migrations = [
    `ALTER TABLE students ADD COLUMN name TEXT DEFAULT ''`,
    `ALTER TABLE award_list_entries ADD COLUMN special_status TEXT DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN unlock_count INTEGER DEFAULT 0`,
    `ALTER TABLE award_lists ADD COLUMN qr_token TEXT DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN copy_handed_over_at DATETIME DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN copy_handed_over_method TEXT DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN copy_received_at DATETIME DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN copy_received_method TEXT DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN copy_reminder_count INTEGER DEFAULT 0`,
    `ALTER TABLE award_lists ADD COLUMN copy_last_reminder_at DATETIME DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN marks_sent_at DATETIME DEFAULT NULL`,
    `ALTER TABLE award_lists ADD COLUMN marks_sent_method TEXT DEFAULT NULL`,
    `ALTER TABLE test_plans ADD COLUMN grp TEXT NOT NULL DEFAULT ''`,
    `ALTER TABLE students ADD COLUMN rfid_uid TEXT DEFAULT NULL`,
    `ALTER TABLE students ADD COLUMN rfid_linked_at TEXT DEFAULT NULL`,
    `ALTER TABLE students ADD COLUMN is_lumpsum INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE students ADD COLUMN student_photo_original TEXT DEFAULT NULL`,
    `ALTER TABLE students ADD COLUMN card_issued INTEGER DEFAULT 0`,
    `ALTER TABLE students ADD COLUMN card_issued_at TEXT DEFAULT NULL`,
    `ALTER TABLE sales ADD COLUMN voided INTEGER NOT NULL DEFAULT 0`,
    `ALTER TABLE sales ADD COLUMN voided_at DATETIME DEFAULT NULL`,
    `ALTER TABLE sales ADD COLUMN void_reason TEXT DEFAULT ''`,
    `ALTER TABLE notes_catalog ADD COLUMN low_stock_alerted INTEGER NOT NULL DEFAULT 0`,
  ];
  for (const sql of migrations) {
    try { await client.exec(sql); } catch (e) { /* already exists */ }
  }

  // Backfill Award List-level sent dates for older records where every
  // student's result had already been sent through the system.
  await client.exec(`
    UPDATE award_lists
    SET marks_sent_at = (
      SELECT datetime(MAX(ale.sent_at), '+5 hours')
      FROM award_list_entries ale
      WHERE ale.award_list_id = award_lists.id
    ), marks_sent_method = 'system'
    WHERE marks_sent_at IS NULL
      AND EXISTS (SELECT 1 FROM award_list_entries ale WHERE ale.award_list_id = award_lists.id)
      AND NOT EXISTS (
        SELECT 1 FROM award_list_entries ale
        WHERE ale.award_list_id = award_lists.id AND COALESCE(ale.sent, 0) <> 1
      )
  `);

  // The first QR implementation treated its only scan as "received". Move
  // those early records into the correct first custody stage (handed over).
  await client.exec(`
    UPDATE award_lists
    SET copy_handed_over_at = copy_received_at, copy_received_at = NULL
    WHERE copy_handed_over_at IS NULL AND copy_received_at IS NOT NULL
  `);

  // One-time data correction requested for the current student register.
  // The UI historically treated blank/unknown values as Active without
  // actually storing that value, which made the Edit form disagree with the
  // student list. Normalize every existing student once, including records
  // previously marked inactive, then keep future status changes untouched.
  try {
    const markerKey = 'migration_all_students_active_20260930';
    const marker = await client.all('SELECT value FROM settings WHERE key = ?', markerKey);
    if (!marker.length) {
      const result = await client.run("UPDATE students SET status = 'active'");
      await client.run(
        "INSERT INTO settings (key, value) VALUES (?, 'done') ON CONFLICT(key) DO UPDATE SET value = 'done'",
        markerKey
      );
      console.log(`✓ Student status normalization complete: ${result.changes || 0} record(s) set to active.`);
    }
  } catch (e) {
    console.error('⚠ Could not normalize student statuses:', e.message);
  }

  try {
    await client.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_students_rfid_uid ON students (rfid_uid) WHERE rfid_uid IS NOT NULL AND rfid_uid != ''`);
  } catch (e) {
    console.error('⚠ Could not create rfid_uid unique index:', e.message);
  }

  try {
    await client.exec(`CREATE UNIQUE INDEX IF NOT EXISTS idx_notes_catalog_class_subject ON notes_catalog (class, subject)`);
  } catch (e) {
    console.error('⚠ Could not create notes_catalog class+subject unique index:', e.message);
  }

  try {
    await client.exec(`CREATE INDEX IF NOT EXISTS idx_sale_items_sale_id ON sale_items (sale_id)`);
    await client.exec(`CREATE INDEX IF NOT EXISTS idx_payments_sale_id ON payments (sale_id)`);
    await client.exec(`CREATE INDEX IF NOT EXISTS idx_sales_amount_due ON sales (amount_due)`);
    await client.exec(`CREATE INDEX IF NOT EXISTS idx_demand_log_status ON demand_log (class, subject, status)`);
  } catch (e) {
    console.error('⚠ Could not create notes-module indexes:', e.message);
  }

  const defaults = [
    ['in_message', 'Dear Parent, your child {name} has arrived at VCC at {time} on {date}.'],
    ['out_message', 'Dear Parent, your child {name} has left VCC at {time} on {date}. For queries: {contact}'],
    ['absent_message', 'Dear Parent, your child {name} was absent from VCC today ({date}). Please ensure regular attendance. For queries: {contact}'],
    ['contact', '03000000000'],
    ['vcc_name', 'Vectors Coaching Centre'],
    ['qr_x', '20'],
    ['qr_y', '120'],
    ['qr_size', '100'],
    ['classes', 'V,VI,VII,VIII,IX,X,XI,XII'],
    ['sections', 'A,B,C,D'],
    ['roll_no_starts', '{"V":501,"VI":601,"VII":701,"VIII":801,"IX":901,"X":1001,"XI":1101,"XII":1201}'],
  ];
  for (const [key, value] of defaults) {
    await client.run('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)', key, value);
  }
}

async function initDb() {
  const hadExistingReplica = fs.existsSync(LOCAL_DB_PATH);
  acquireSingleInstanceLock();
  try {
    const client = await getDb();

    // Use the same guarded push-before-pull path at startup. On an existing PC
    // this safely uploads any writes left pending by sleep/power loss before
    // applying remote changes. On a fresh PC there are no local changes, so the
    // pull simply restores the complete cloud database before schema setup.
    await syncNow({ force: true });

    // Do not turn a first-time, offline launch into a new empty replica. That
    // would later have to replay locally-created schema/defaults over the real
    // cloud database and can create avoidable conflicts. Existing PCs continue
    // to work locally while offline as normal.
    if (cloudConfigured && !hadExistingReplica && syncState !== 'synced') {
      throw new Error('First-time database setup needs an internet connection to download the cloud data.');
    }

    await attemptInit(client);

    // Push whatever we just created/defaulted, then start recurring sync + backup.
    await syncNow({ force: true });
    startBackgroundSync();
    startDailyBackup();

    console.log('✅ Database ready' + (cloudConfigured ? ' (local-first, synced with Turso)' : ' (local-only — no cloud connection)'));
    console.log('📁 Local DB:', LOCAL_DB_PATH);
    console.log('📁 Backups:', BACKUP_DIR);
  } catch (error) {
    // initDb can fail after the lock and native connection have been acquired.
    // Release both here so a normal retry never requires deleting lock/db files.
    if (db) { try { await db.close(); } catch (_) {} db = null; }
    releaseSingleInstanceLock();
    throw error;
  }
}

// ── GRACEFUL SHUTDOWN ────────────────────────────────────────────────────
let shuttingDown = false;
async function shutdownDb() {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log('\n👋 Shutting down — closing database connections...');
  if (syncTimer) { clearInterval(syncTimer); syncTimer = null; }
  if (pendingSyncTimer) { clearTimeout(pendingSyncTimer); pendingSyncTimer = null; }
  if (backupTimer) { clearInterval(backupTimer); backupTimer = null; }
  // Best-effort final push, but don't hang shutdown forever on a dead network.
  try {
    await Promise.race([
      syncNow({ force:true }),
      new Promise(resolve => setTimeout(resolve, 8000))
    ]);
  } catch (e) { /* ignore — we're shutting down regardless */ }
  try { await exclusiveDbTail; } catch (e) {}
  if (db) { try { await db.checkpoint(); } catch (e) {} }
  if (db) { try { await db.close(); } catch (e) {} db = null; }
  releaseSingleInstanceLock();
}

function registerShutdownHandlers() {
  const handleSignal = (signal) => {
    shutdownDb().finally(() => process.exit(0));
  };
  process.on('SIGINT', handleSignal);
  process.on('SIGTERM', handleSignal);
  process.on('exit', () => { releaseSingleInstanceLock(); });
}

// Status check — for admin dashboard / health endpoint
function getSyncStatus() {
  return {
    isOnline,
    state: cloudConfigured ? syncState : 'local-only',
    lastSyncAt: lastSyncAt ? lastSyncAt.toISOString() : null,
    lastError: lastSyncError,
    consecutiveFailures: consecutiveSyncFailures,
    pendingLocalChanges,
    retryAt: nextSyncAllowedAt ? new Date(nextSyncAllowedAt).toISOString() : null,
    localDbPath: LOCAL_DB_PATH,
    localDbExists: fs.existsSync(LOCAL_DB_PATH),
    localOnlyFallback: !cloudConfigured,
  };
}

// These are kept for compatibility with older callers.
function ensureWhatsappLog() {}
function ensureStudentColumns() {}
function ensureRetryColumns() {}
function ensurePhotoColumn() {}
function ensureHolidaysTable() {}
function ensureFrozenColumn() {}
function ensureWaColumns() {}
function ensureClassSectionSettings() {}

module.exports = {
  getDb, query, run, batchRun, saveDb, flushDb, backupDb, todayPKT, initDb,
  syncNow, getSyncStatus, shutdownDb, registerShutdownHandlers, noteScanActivity,
  syncToCloud: syncNow,
  syncFromCloud: syncNow,
  ensureCloudTables: async () => {},
  ensureWhatsappLog, ensureStudentColumns, ensureRetryColumns,
  ensureClassSectionSettings, ensurePhotoColumn, ensureHolidaysTable,
  ensureFrozenColumn, ensureWaColumns
};
