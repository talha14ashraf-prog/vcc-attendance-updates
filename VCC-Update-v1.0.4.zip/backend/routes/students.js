const express = require('express');
const router = express.Router();

// ── Integer sanitiser: converts "901.0" or 901.0 → "901", keeps "" as ""
function toIntStr(val) {
  if (val === null || val === undefined || val === '') return '';
  const n = Number(val);
  return isNaN(n) ? String(val).trim() : String(Math.round(n));
}

const { query, run, batchRun } = require('../database');
const QRCode = require('qrcode');
const crypto = require('crypto');

function generateUID() {
  return 'VCC-' + crypto.randomBytes(4).toString('hex').toUpperCase();
}

// Max photo size: 500KB as base64 (~683KB string length).
// A typical phone camera photo is 2-5MB — reject anything that large
// to prevent the SQLite database from growing into gigabytes.
const PHOTO_MAX_B64_LEN = 700000; // ~500KB decoded

function validatePhoto(photo) {
  if (!photo) return null;
  if (photo.length > PHOTO_MAX_B64_LEN) {
    throw new Error('Photo is too large (max 500KB). Please resize the image before uploading.');
  }
  return photo;
}


// Columns for list endpoint — student_photo intentionally excluded.
// Photos are base64 strings; 500 students with photos = ~100MB response.
// The single-student GET /:uid returns SELECT * including the photo.
const LIST_COLS = [
  'id','student_uid','name','class','section','parent_phone','parent_phone2',
  'gr_number','roll_no','father_name','admission_date','group_name','status',
  'session','campus','gender','religion','dob','admission_class',
  'address','last_school','office_address',
  'mother_name','father_cnic','father_occ','father_qual',
  'mother_cnic','mother_occ','mother_qual','pob','created_at',
  'is_frozen','freeze_reason','card_printed','card_printed_at','card_issued','card_issued_at',
  'rfid_uid','rfid_linked_at','is_lumpsum'
].join(', ');

// Get all students — supports ?status=active|inactive|all (default: all)
router.get('/', async (req, res) => {
  try {
    const status = req.query.status || 'all';
    let students;
    if (status === 'active') {
      students = await query(`SELECT ${LIST_COLS} FROM students WHERE status = 'active' OR status IS NULL OR status = '' ORDER BY class, name`);
    } else if (status === 'inactive') {
      students = await query(`SELECT ${LIST_COLS} FROM students WHERE status = 'inactive' ORDER BY class, name`);
    } else {
      students = await query(`SELECT ${LIST_COLS} FROM students ORDER BY class, name`);
    }
    res.json({ success: true, students });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Helper — get next roll number for a class
async function getNextRollNo(cls) {
  try {
    const [maxRow] = await query(
      "SELECT MAX(CAST(roll_no AS INTEGER)) as maxRoll FROM students WHERE class = ? AND roll_no IS NOT NULL AND roll_no != ''",
      [cls]
    );
    if (maxRow && maxRow.maxRoll) return String(parseInt(maxRow.maxRoll) + 1);

    const [settingRow] = await query("SELECT value FROM settings WHERE key = 'roll_no_starts'");
    if (settingRow) {
      const starts = JSON.parse(settingRow.value);
      if (starts[cls]) return String(parseInt(starts[cls]));
    }
    return null;
  } catch(e) { return null; }
}

// Add student
router.post('/add', async (req, res) => {
  try {
    const {
      name, class: cls, section, parent_phone, parent_phone2,
      gr_number, roll_no, father_name, admission_date, group_name, status,
      session, campus, gender, religion, dob, admission_class,
      address, last_school, office_address,
      mother_name, father_cnic, father_occ, father_qual, mother_cnic, mother_occ, mother_qual,
      pob, student_photo, student_photo_original, photo,
    } = req.body;
    if (!name || !cls || !parent_phone) {
      return res.status(400).json({ success: false, error: 'Name, class and parent phone are required' });
    }
    // Prevent duplicate GR number
    if (gr_number && gr_number.trim()) {
      const existing = await query('SELECT student_uid, name FROM students WHERE gr_number = ? AND gr_number != \'\'', [gr_number.trim()]);
      if (existing.length) {
        return res.status(400).json({ success: false, error: `GR Number ${gr_number} is already assigned to student: ${existing[0].name}. Duplicate GR numbers are not allowed.` });
      }
    }

    // Auto-assign roll number if not manually provided
    const finalRollNo = (roll_no && roll_no.toString().trim()) ? toIntStr(roll_no) : (await getNextRollNo(cls) || '');

    // Validate photo size before insert
    let finalPhoto;
    try { finalPhoto = validatePhoto((student_photo || photo) || null); }
    catch(e) { return res.status(400).json({ success: false, error: e.message }); }
    let originalPhoto;
    try { originalPhoto = validatePhoto(student_photo_original || null); }
    catch(e) { return res.status(400).json({ success: false, error: e.message }); }

    const uid = generateUID();
    await run(
      `INSERT INTO students 
        (name, class, section, parent_phone, parent_phone2, student_uid,
         gr_number, roll_no, father_name, admission_date, group_name, status,
         session, campus, gender, religion, dob, admission_class,
         address, last_school, office_address,
         mother_name, father_cnic, father_occ, father_qual, mother_cnic, mother_occ, mother_qual,
         pob, student_photo, student_photo_original)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name, cls, section||'', parent_phone, parent_phone2||'', uid,
        toIntStr(gr_number), toIntStr(finalRollNo), father_name||'', admission_date||'', group_name||'', status||'active',
        session||'', campus||'', gender||'', religion||'', dob||'', admission_class||'',
        address||'', last_school||'', office_address||'',
        mother_name||'', father_cnic||'', father_occ||'', father_qual||'', mother_cnic||'', mother_occ||'', mother_qual||'',
        pob||'', finalPhoto, originalPhoto,
      ]
    );
    const qrData = await QRCode.toDataURL(uid, { width: 200, margin: 1 });
    res.json({ success: true, uid, qr: qrData, roll_no: finalRollNo, message: 'Student added successfully' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/students/roll-starts  → get current starting numbers (read-only)
router.get('/roll-starts', async (req, res) => {
  try {
    const defaults = { V:501, VI:601, VII:701, VIII:801, IX:901, X:1001, XI:1101, XII:1201 };
    const [row] = await query("SELECT value FROM settings WHERE key = 'roll_no_starts'");
    let saved = {};
    if (row) { try { saved = JSON.parse(row.value); } catch(e) {} }
    const starts = Object.assign({}, defaults, saved);
    // No write here — GET must be read-only. Defaults are persisted by the POST /roll-starts route.
    res.json({ success: true, starts });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Get single student by UID
// Lookup a student by RFID card UID — used by the RFID-linking UI to warn
// the operator before they even hit "link" if the card is already taken.
// IMPORTANT: this must be registered BEFORE GET /:uid, otherwise Express
// would treat "rfid" as a :uid value and this route would never match.
// GET /api/students/rfid/:rfid_uid
router.get('/rfid/:rfid_uid', async (req, res) => {
  try {
    const students = await query('SELECT student_uid, name, class, gr_number FROM students WHERE rfid_uid = ?', [req.params.rfid_uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'No student linked to this card' });
    res.json({ success: true, student: students[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

router.get('/:uid', async (req, res) => {
  try {
    const students = await query('SELECT * FROM students WHERE student_uid = ?', [req.params.uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    res.json({ success: true, student: students[0] });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Update student
router.put('/:uid', async (req, res) => {
  try {
    const {
      name, class: cls, section, parent_phone, parent_phone2,
      gr_number, roll_no, father_name, admission_date, group_name, status,
      session, campus, gender, religion, dob, admission_class,
      address, last_school, office_address, pob,
      mother_name, father_cnic, father_occ, father_qual, mother_cnic, mother_occ, mother_qual,
      student_photo, student_photo_original, photo, remove_photo,
    } = req.body;
    if (!name || !cls || !parent_phone) {
      return res.status(400).json({ success: false, error: 'Name, class and parent phone are required' });
    }

    // If class changed, auto-assign roll_no from new class (unless manually provided)
    const [existing] = await query('SELECT class, roll_no FROM students WHERE student_uid = ?', [req.params.uid]);
    let finalRollNo = toIntStr(roll_no) || '';
    if (existing && existing.class !== cls && !roll_no) {
      // Class changed and no manual roll_no — assign next in new class
      finalRollNo = await getNextRollNo(cls) || '';
    } else if (!roll_no && existing) {
      // No change — keep existing roll_no
      finalRollNo = existing.roll_no || '';
    }

    // Validate photo size before update
    let updatedPhoto;
    try { updatedPhoto = validatePhoto((student_photo || photo) || null); }
    catch(e) { return res.status(400).json({ success: false, error: e.message }); }
    let updatedOriginalPhoto;
    try { updatedOriginalPhoto = validatePhoto(student_photo_original || null); }
    catch(e) { return res.status(400).json({ success: false, error: e.message }); }

    // COALESCE(?, student_photo) can never clear a photo — passing null/empty
    // just means "no change" and the old photo stays. remove_photo is an
    // explicit signal from the "✕ Remove photo" button to actually clear it.
    const photoSql = remove_photo
      ? "student_photo='', student_photo_original=''"
      : 'student_photo=COALESCE(?, student_photo), student_photo_original=COALESCE(?, student_photo_original)';
    const photoParams = remove_photo ? [] : [updatedPhoto, updatedOriginalPhoto];

    await run(
      `UPDATE students SET
        name=?, class=?, section=?, parent_phone=?, parent_phone2=?,
        gr_number=?, roll_no=?, father_name=?, admission_date=?, group_name=?, status=?,
        session=?, campus=?, gender=?, religion=?, dob=?, admission_class=?,
        address=?, last_school=?, office_address=?, pob=?,
        mother_name=?, father_cnic=?, father_occ=?, father_qual=?, mother_cnic=?, mother_occ=?, mother_qual=?,
        ${photoSql}
       WHERE student_uid=?`,
      [
        name, cls, section||'', parent_phone, parent_phone2||'',
        toIntStr(gr_number), toIntStr(finalRollNo), father_name||'', admission_date||'', group_name||'', status||'active',
        session||'', campus||'', gender||'', religion||'', dob||'', admission_class||'',
        address||'', last_school||'', office_address||'', pob||'',
        mother_name||'', father_cnic||'', father_occ||'', father_qual||'', mother_cnic||'', mother_occ||'', mother_qual||'',
        ...photoParams,
        req.params.uid,
      ]
    );
    res.json({ success: true, message: 'Student updated' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// ── RFID CARD LINK / UNLINK ─────────────────────────────────────────────────

// Link an RFID card to a student
// POST /api/students/:uid/rfid/link   Body: { rfid_uid }
router.post('/:uid/rfid/link', async (req, res) => {
  try {
    let { rfid_uid } = req.body;
    if (!rfid_uid || !String(rfid_uid).trim()) {
      return res.status(400).json({ success: false, error: 'RFID card UID is required' });
    }
    rfid_uid = String(rfid_uid).trim();

    const students = await query('SELECT * FROM students WHERE student_uid = ?', [req.params.uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    const student = students[0];

    // A student's own barcode UID can't also be used as their RFID (keeps the two
    // identifiers distinct so kiosk lookups aren't ambiguous).
    if (rfid_uid === student.student_uid) {
      return res.status(400).json({ success: false, error: 'This card UID matches the student\'s own ID — scan the RFID card instead.' });
    }

    // Check the card isn't already linked to a different (or the same) student
    const clash = await query(
      'SELECT student_uid, name, class FROM students WHERE rfid_uid = ? AND student_uid != ?',
      [rfid_uid, req.params.uid]
    );
    if (clash.length) {
      return res.status(409).json({
        success: false,
        error: `This card is already linked to ${clash[0].name} (Class ${clash[0].class}). Unlink it there first.`
      });
    }

    const now = new Date(Date.now() + 5 * 60 * 60 * 1000).toISOString().replace('T', ' ').split('.')[0];
    await run('UPDATE students SET rfid_uid = ?, rfid_linked_at = ? WHERE student_uid = ?', [rfid_uid, now, req.params.uid]);
    res.json({ success: true, message: 'RFID card linked', rfid_uid, rfid_linked_at: now });
  } catch (err) {
    // UNIQUE constraint race (two requests linking the same card at once)
    if (String(err.message || '').toLowerCase().includes('unique')) {
      return res.status(409).json({ success: false, error: 'This card is already linked to another student.' });
    }
    res.status(500).json({ success: false, error: err.message });
  }
});

// Unlink the RFID card from a student
// POST /api/students/:uid/rfid/unlink
router.post('/:uid/rfid/unlink', async (req, res) => {
  try {
    const students = await query('SELECT * FROM students WHERE student_uid = ?', [req.params.uid]);
    if (!students.length) return res.status(404).json({ success: false, error: 'Student not found' });
    await run('UPDATE students SET rfid_uid = NULL, rfid_linked_at = NULL WHERE student_uid = ?', [req.params.uid]);
    res.json({ success: true, message: 'RFID card unlinked' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Delete student
router.delete('/:uid', async (req, res) => {
  try {
    const uid = req.params.uid;
    const existing = await query('SELECT * FROM students WHERE student_uid = ?', [uid]);
    if (!existing.length) return res.status(404).json({ success: false, error: 'Student not found' });
    await run('DELETE FROM attendance WHERE student_uid = ?', [uid]);
    await run('DELETE FROM whatsapp_log WHERE student_uid = ?', [uid]);
    await run('DELETE FROM students WHERE student_uid = ?', [uid]);
    res.json({ success: true, message: 'Student and all associated records deleted' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});


// Generate QR code
router.get('/:uid/qr', async (req, res) => {
  try {
    const qrData = await QRCode.toDataURL(req.params.uid, { width: 300, margin: 2 });
    res.json({ success: true, qr: qrData });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// Bulk import students from parsed Excel data
// POST /api/students/bulk-import
// Body: { students: [ { name, gr_number, class, parent_phone, ... }, ... ] }
router.post('/bulk-import', async (req, res) => {
  try {
    const { students: incoming } = req.body;
    if (!Array.isArray(incoming) || !incoming.length) {
      return res.status(400).json({ success: false, error: 'No student data provided.' });
    }

    // Load all existing GRs to check duplicates efficiently. GR is the stable
    // identity used by imports: matching rows are updated in place.
    const existingGRRows = await query("SELECT * FROM students WHERE gr_number != '' AND gr_number IS NOT NULL");
    const existingGRMap = {}; // gr -> full row object
    existingGRRows.forEach(r => { if (r.gr_number) existingGRMap[toIntStr(r.gr_number)] = r; });

    // Fields an import may correct on a matching GR. Blank imported cells are
    // ignored so a partial spreadsheet cannot erase information already saved.
    // Identity/system fields remain protected.
    const IMPORTABLE_FIELDS = [
      'name', 'class', 'section', 'roll_no', 'parent_phone', 'parent_phone2',
      'father_name', 'admission_date', 'group_name', 'status', 'session',
      'campus', 'gender', 'religion', 'dob', 'admission_class', 'address',
      'last_school', 'office_address', 'mother_name', 'father_cnic',
      'father_occ', 'father_qual', 'mother_cnic', 'mother_occ', 'mother_qual', 'pob',
    ];

    const results = { added: 0, updated: 0, skipped: 0, errors: [] };
    const addedUIDs = [];
    const addedGRSet = new Set(); // track GRs added within this import batch

    for (let i = 0; i < incoming.length; i++) {
      const row = incoming[i];
      const rowNum = i + 2; // Excel row number (1-indexed header + 1)

      // Validate required fields
      // Supports: VCC custom format AND ExportDATA format (GRNO, NAME, F_NAME, FATHER_CELL, etc.)
      const name  = (row.name || row.Name || row.NAME || '').toString().trim();
      // ExportDATA uses ADMISSION_CLASS for the student class (IX, X, etc.)
      const cls   = (row.class || row.Class || row.CLASS || row.ADMISSION_CLASS || row['Admission Class'] || '').toString().trim();
      // ExportDATA uses FATHER_CELL as primary phone
      const phone = (row.parent_phone || row.Phone || row.phone || row.PHONE || row['Parent Phone'] || row.FATHER_CELL || row.MOTHER_CELL || '').toString().trim();
      const grRaw = (row.gr_number || row.GR || row['GR No'] || row['GR Number'] || row.gr || row.GRNO || '').toString().trim();
      const gr    = toIntStr(grRaw);

      if (!name) { results.errors.push(`Row ${rowNum}: Name is required`); results.skipped++; continue; }
      if (!gr)   { results.errors.push(`Row ${rowNum} (${name}): GR number is required`); results.skipped++; continue; }
      // class, phone are optional

      // Build the incoming field values once — reused by both the INSERT
      // (new student) and UPDATE (fill-missing-fields) paths below.
      const incomingValues = {
        name, class: cls,
        section: (row.section || row.Section || row.SECTION || '').toString().trim(),
        roll_no: toIntStr(row.roll_no || row['Roll No'] || row.ROLL_NO || ''),
        parent_phone: phone,
        parent_phone2: (row.parent_phone2 || row['Parent Phone 2'] || (row.FATHER_CELL ? row.MOTHER_CELL : '') || '').toString().trim(),
        father_name: (row.father_name || row['Father Name'] || row.F_NAME || '').toString().trim(),
        admission_date: (() => {
          const d = row.admission_date || row['Admission Date'] || row.ADMISSION_DATE || '';
          if (!d) return '';
          const s = d.toString().trim();
          if (/^\d{5}$/.test(s)) { const ms = (parseInt(s) - 25569) * 86400000; return new Date(ms).toISOString().split('T')[0]; }
          return s;
        })(),
        group_name: (row.group_name || row.group || row.Group || row.STUDY_GROUP || '').toString().trim(),
        status: (row.status || row.Status || row.STATUS || '').toString().trim(),
        session: (row.session || row.Session || row.CATEGORY || '').toString().trim(),
        campus: (row.campus || row.Campus || row.CAMPUS || '').toString().trim(),
        gender: (row.gender || row.Gender || row.GENDER || '').toString().trim(),
        religion: (row.religion || row.Religion || row.RELIGION || '').toString().trim(),
        dob: (() => {
          const d = row.dob || row.DOB || row['Date of Birth'] || '';
          if (!d) return '';
          const s = d.toString().trim();
          if (/^\d{5}$/.test(s)) { const ms = (parseInt(s) - 25569) * 86400000; return new Date(ms).toISOString().split('T')[0]; }
          return s;
        })(),
        admission_class: (row.admission_class || row['Admission Class'] || row.ADMISSION_CLASS || cls).toString().trim(),
        address: (row.address || row.Address || row.PRESENT_ADDRESS || '').toString().trim(),
        last_school: (row.last_school || row['Last School'] || row.LAST_SCHOOL || '').toString().trim(),
        office_address: (row.office_address || row['Office Address'] || '').toString().trim(),
        mother_name: (row.mother_name || row['Mother Name'] || row.M_NAME || '').toString().trim(),
        father_cnic: (row.father_cnic || row['Father CNIC'] || row.F_CNIC || '').toString().trim(),
        father_occ: (row.father_occ || row['Father Occupation'] || row.F_OCCUPATIONS || '').toString().trim(),
        father_qual: (row.father_qual || row['Father Qualification'] || '').toString().trim(),
        mother_cnic: (row.mother_cnic || row['Mother CNIC'] || row.M_CNIC || '').toString().trim(),
        mother_occ: (row.mother_occ || row['Mother Occupation'] || row.M_OCCUPATIONS || '').toString().trim(),
        mother_qual: (row.mother_qual || row['Mother Qualification'] || '').toString().trim(),
        pob: (row.pob || row['Place of Birth'] || '').toString().trim(),
      };

      // Matching GR: overwrite changed values supplied by the spreadsheet.
      // Empty imported cells are deliberately ignored.
      const existing = existingGRMap[gr];
      if (existing) {
        const setClauses = [];
        const setArgs = [];
        const changedFields = [];
        for (const field of IMPORTABLE_FIELDS) {
          const currentVal = (existing[field] || '').toString().trim();
          const newVal = incomingValues[field];
          if (newVal && currentVal !== newVal) {
            setClauses.push(`${field} = ?`);
            setArgs.push(newVal);
            changedFields.push(field);
          }
        }
        if (setClauses.length) {
          try {
            setArgs.push(existing.student_uid);
            await run(`UPDATE students SET ${setClauses.join(', ')} WHERE student_uid = ?`, setArgs);
            changedFields.forEach((field, index) => { existing[field] = setArgs[index]; });
            results.updated++;
            results.errors.push(`Row ${rowNum} (${name}): GR ${gr} updated — changed ${changedFields.join(', ')}`);
          } catch (updateErr) {
            results.errors.push(`Row ${rowNum} (${name}): GR ${gr} update failed: ${updateErr.message}`);
            results.skipped++;
          }
        } else {
          results.errors.push(`Row ${rowNum} (${name}): GR ${gr} is already identical — skipped`);
          results.skipped++;
        }
        continue;
      }
      // Also check within this import batch
      if (addedGRSet.has(gr)) {
        results.errors.push(`Row ${rowNum} (${name}): GR ${gr} is duplicated within the import file`);
        results.skipped++;
        continue;
      }

      const uid = generateUID();
      try {
        await run(
          `INSERT INTO students
            (name, class, section, parent_phone, parent_phone2, student_uid,
             gr_number, roll_no, father_name, admission_date, group_name, status,
             session, campus, gender, religion, dob, admission_class,
             address, last_school, office_address,
             mother_name, father_cnic, father_occ, father_qual,
             mother_cnic, mother_occ, mother_qual, pob)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            incomingValues.name, incomingValues.class, incomingValues.section,
            incomingValues.parent_phone, incomingValues.parent_phone2, uid,
            toIntStr(gr),
            incomingValues.roll_no,
            incomingValues.father_name, incomingValues.admission_date, incomingValues.group_name,
            incomingValues.status || 'active', incomingValues.session, incomingValues.campus,
            incomingValues.gender, incomingValues.religion, incomingValues.dob,
            incomingValues.admission_class, incomingValues.address, incomingValues.last_school,
            incomingValues.office_address, incomingValues.mother_name, incomingValues.father_cnic,
            incomingValues.father_occ, incomingValues.father_qual, incomingValues.mother_cnic,
            incomingValues.mother_occ, incomingValues.mother_qual, incomingValues.pob,
          ]
        );
        if (gr) { existingGRMap[gr] = { ...incomingValues, gr_number: gr, student_uid: uid }; addedGRSet.add(gr); } // prevent duplicates later in same batch
        results.added++;
        addedUIDs.push(uid);
      } catch (insertErr) {
        results.errors.push(`Row ${rowNum} (${name}): ${insertErr.message}`);
        results.skipped++;
      }
    }

    res.json({ success: true, ...results, message: `Import complete: ${results.added} added, ${results.updated} updated, ${results.skipped} unchanged/skipped.` });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/students/roll-starts  body: { starts: { IX: 901, X: 1001, ... } }
router.post('/roll-starts', async (req, res) => {
  try {
    const { starts } = req.body;
    if (!starts || typeof starts !== 'object') return res.status(400).json({ success: false, error: 'Invalid data' });
    // Merge with existing so partial saves don't wipe other classes
    const [existing] = await query("SELECT value FROM settings WHERE key = 'roll_no_starts'");
    let current = {};
    if (existing) { try { current = JSON.parse(existing.value); } catch(e) {} }
    const merged = Object.assign({}, current, starts);
    await run("INSERT OR REPLACE INTO settings (key, value) VALUES ('roll_no_starts', ?)", [JSON.stringify(merged)]);
    res.json({ success: true, starts: merged });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/students/assign-roll-numbers  body: { class: 'IX' } or {} for all classes
router.post('/assign-roll-numbers', async (req, res) => {
  try {
    const [row] = await query("SELECT value FROM settings WHERE key = 'roll_no_starts'");
    const starts = row ? JSON.parse(row.value) : {};
    const targetClass = req.body.class || null;

    // Get distinct classes to process
    let classes;
    if (targetClass) {
      classes = [targetClass];
    } else {
      const classRows = await query("SELECT DISTINCT class FROM students WHERE status = 'active' ORDER BY class");
      classes = classRows.map(r => r.class);
    }

    let totalUpdated = 0;
    const summary = [];

    for (const cls of classes) {
      const startNum = parseInt(starts[cls]);
      if (!startNum || isNaN(startNum)) {
        summary.push({ class: cls, status: 'skipped', reason: 'No start number configured' });
        continue;
      }

      // All students (active + inactive) get sequential roll numbers.
      // Inactive students are included so the sequence stays contiguous —
      // e.g. if Sara is inactive at GR#2, she still gets roll 902,
      // and Ahmed at GR#3 gets 903 (not 902).
      const students = await query(
        "SELECT student_uid, gr_number FROM students WHERE class = ? ORDER BY CAST(gr_number AS INTEGER) ASC, gr_number ASC",
        [cls]
      );

      // One round-trip for the whole class instead of N separate writes
      // (sequential was slow; parallel was WORSE because SQLite only allows
      // one writer at a time, so parallel calls just queued up and fought
      // each other for the write lock). batch() sends them all together.
      const statements = students.map((s, i) => ({
        sql: "UPDATE students SET roll_no = ? WHERE student_uid = ?",
        args: [String(startNum + i), s.student_uid]
      }));
      await batchRun(statements);

      totalUpdated += students.length;
      summary.push({ class: cls, start: startNum, assigned: students.length });
    }

    res.json({ success: true, totalUpdated, summary });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/students/photos — returns { uid: base64photo } for a list of UIDs
// Used by the detail report view to load photos without fetching full student records one-by-one.
router.post('/photos', async (req, res) => {
  try {
    const { uids } = req.body;
    if (!Array.isArray(uids) || !uids.length) {
      return res.json({ success: true, photos: {} });
    }
    const placeholders = uids.map(() => '?').join(', ');
    const rows = await query(
      `SELECT student_uid, student_photo FROM students WHERE student_uid IN (${placeholders}) AND student_photo IS NOT NULL AND student_photo != ''`,
      uids
    );
    const photos = {};
    rows.forEach(r => { photos[r.student_uid] = r.student_photo; });
    res.json({ success: true, photos });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
