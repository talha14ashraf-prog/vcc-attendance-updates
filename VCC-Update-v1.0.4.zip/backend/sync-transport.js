// Abort the real HTTP request INCLUDING its body. Never release the database
// lock using Promise.race while the native sync operation is still running.
function createSyncTransport({fetchImpl=(...args)=>fetch(...args),requestTimeoutMs=4000,operationTimeoutMs=6000}={}) {
  let operationSignal=null,operationController=null;
  async function boundedFetch(input,options={}) {
    const signals=[AbortSignal.timeout(requestTimeoutMs),operationSignal,options.signal].filter(Boolean);
    const response=await fetchImpl(input,{...options,signal:AbortSignal.any(signals)});
    const body=await response.arrayBuffer();
    return new Response([204,205,304].includes(response.status)?null:body,{status:response.status,statusText:response.statusText,headers:response.headers});
  }
  async function run(task) {
    const previous=operationSignal,previousController=operationController;
    operationController=new AbortController();
    operationSignal=AbortSignal.any([operationController.signal,AbortSignal.timeout(operationTimeoutMs)]);
    try{return await task()}finally{operationSignal=previous;operationController=previousController}
  }
  function yieldToScan(){operationController?.abort(new Error('Cloud sync yielded to local scan'))}
  return {fetch:boundedFetch,run,yieldToScan};
}
module.exports={createSyncTransport};
